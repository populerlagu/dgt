<?php 
include '../setting.php';
$sign	= fopen("../config/$domain.signup.json", "r");
$signup = json_decode(fgets($sign), true);
$boleh = $signup['first_name'].' '.$signup['last_name'];

if(isset($_GET['file'])){
$filename = $_GET['file'];
$themename = $_GET['theme'];
//get
$datafile = '../contents/themes/'.$themename.'/'.$filename;
$current = file_get_contents($datafile);

//put
if(isset($_POST['saveit'])){
$current = $_POST['filetheme'];
file_put_contents($datafile, $current);	
}

$title = 'Edit Themes ('.$filename.') on '.$themename.' Theme';
$robot = 'noindex, nofollow';
include '../contents/themes/fasthink/header.php';
?> 
<style>
#wrapmusik{max-width:950px}
.asu{ color: #555;  background-color: #fff;border-bottom:  3px solid red;margin:5px;padding:5px; 
} .lis{padding:10px 0;border-bottom:  1px solid #ddd;}
ul.asus{    margin-left: -3.2em;}
</style>
<div class="container-fluid" style="max-width:950px;margin:0 auto;">
<div class="row">
<h1><center>THEME EDITOR</center></h1>
<hr/>
<ul class="nav nav-tabs">
<li><a rel="nofollow" href="/">HOME</a></li>
<li><a href="/Aamiin/">DASHBORD</a></li>
<?php 
$dir = "../contents/themes/*"; //scan thema list
foreach(glob($dir) as $val){
	$tlist =  str_replace('../contents/themes/', '', $val);
?>
	<li <?php if($_GET['theme'] == $tlist){ ?>class="active"<?php } ?>><a href="/themes/edit.php?file=minify.css&theme=<?php echo $tlist;?>"><?php echo strtoupper($tlist);?></a></li>
<?php } ?>
<li><a href="/Aamiin/logout.php?return=http<?php echo urlencode($fullpatch);?>">Logout</a></li>
</ul>
	<div class="col-sm-9">	
<?php if(!preg_match('/putri|mjt/i', $boleh)){ ?>
<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
Hy <b><?php echo $boleh;?></b>...!!! Kamu Belum diperbolehkan untuk mengedit / menggunakan fitur edit thema, Silahkan Contact Admin
</div>
<?php } else { ?>
<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
Hy <b><?php echo $boleh;?></b>...!!! Fitur ini Hanya untuk dilihat .... mohon tidak menghapus file / isi didalam textarea..
</div>
<?php } ?>
	<form  method="POST">
		<div class="form-group">
		  <label style="margin:10px" for="comment">Edit <span style="color:red"><u><?php echo $themename;?></u></span> Theme : <?php echo $filename;?></label>
		  <?php if(isset($_POST['saveit'])){ ?>
		  
			<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
				<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
				<strong>Success!</strong> Your File saved Succesfully.
			</div>
		 
	  <?php }?>
		  <textarea class="form-control" rows="31" id="comment" name="filetheme"><?php echo htmlentities($current);?></textarea>
		</div>
			<button class="btn btn-danger" type="submit" name="saveit">Save</button>
	  </form>
	 
	</div>
	<div class="col-sm-3">
			<h4 style="margin:10px 0;border-bottom:2px solid #ddd">Files</h4>
				<ul class="asus">
					<?php 
					$file = "../contents/themes/$_GET[theme]/*"; //scan thema list
					foreach(glob($file) as $val){	
						if(!preg_match('/lirik|bootst/i', $val)){	
							$files = str_ireplace('../contents/themes/'.$themename.'/','', $val); ?>
							 <li <?php if($_GET['file'] == $files){ ?>class="asu"<?php } else { ?> style="border-bottom:1px dotted black;margin:5px;padding:5px"<?php } ?>><a href="/themes/edit.php?file=<?php echo $files;?>&theme=<?php echo $themename;?>"><?php echo strtoupper($files);?></a></li>
						<?php }
					} ?>
				</ul>
	</div>

</div>
</div>
<div class="footer" style="margin:10px 0;text-align:center">
<span>© 2017 STMJ</span></div>
<?php } // end get 
else {
	echo '<a href="/themes/">BACK TO MAIN</a>';
} ?>