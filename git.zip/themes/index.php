<?php 
include '../setting.php';
$title = 'Themes';
$robot = 'noindex, nofollow';
include '../contents/themes/fasthink/header.php'; 
?>

<div class="container-fluid" style="max-width:750px;margin:0 auto;">
<div class="row">
<h1><center>THEME EDITOR</center></h1>
<ul class="nav nav-tabs">
	<li><a href="/">HOME</a></li>
<?php 
// print_r($_GET);
if(!empty($_GET)){ 
$themelist = array('fasthink','simplev1','simplev2','simplev3');
foreach($themelist as $val){ ?>
	<li <?php if($_GET['theme'] == $val){ ?>class="active"<?php } ?>><a href="?theme=<?php echo $val;?>"><?php echo strtoupper($val);?></a></li>
<?php } // print_r($_GET);  ?>
</ul>
<div class="contents">
<h3><center>SCREENSHOT <?php echo strtoupper($_GET['theme']);?><center></h3>
<?php if($_GET['theme'] == 'fasthink') { ?>
	<p class="center">
	<a href="/themes/edit.php?file=minify.css&theme=fasthink"><button class="btn-md btn-default">Edit Tema</button></a>
	</p>
	<p>
		<img src="https://image.prntscr.com/image/AA__QvadQzCMGABOfsKukA.jpeg" width="400" height="auto" style="width:100%;height:auto">
	</p>
<?php } elseif($_GET['theme'] == 'simplev1') { ?>	
<p class="center">
	<a href="/themes/edit.php?file=minify.css&theme=simplev1"><button class="btn-md btn-default">Edit Tema</button></a>
	</p>
	<p>
		<img src="https://image.prntscr.com/image/1d-Hi69JRV_wjW4FssEUAQ.jpeg" width="400" height="auto" style="width:100%;height:auto">
	</p>
	
<?php } elseif($_GET['theme'] == 'simplev2') { ?>	
	<p class="center">
	<a href="/themes/edit.php?file=minify.css&theme=simplev2"><button class="btn-md btn-default">Edit Tema</button></a>
	</p>
	<p>
		<img src="https://image.prntscr.com/image/bBEvS4zDQ9OTqoFegCcG9Q.jpeg" width="400" height="auto" style="width:100%;height:auto">
	</p>
<?php } elseif($_GET['theme'] == 'simplev3') { ?>	
	<p class="center">
	<a href="/themes/edit.php?file=minify.css&theme=simplev3"><button class="btn-md btn-default">Edit Tema</button></a>
	</p>	
	<p>
		<img src="https://image.prntscr.com/image/y5hgBpZYRzSPPuWppyWEpg.jpeg" width="400" height="auto" style="width:100%;height:auto">
	</p>
<?php } else { ?>

<?php }

} else { ?>
	<p class="center">
	<a href="/themes/edit.php?file=minify.css&theme=fasthink"><button class="btn-md btn-default">Edit Tema</button></a>
	</p>
	<p>
		<img src="https://image.prntscr.com/image/AA__QvadQzCMGABOfsKukA.jpeg" width="400" height="auto" style="width:100%;height:auto">
	</p>

<?php } ?>	
	
</div>


</div>
</div>
