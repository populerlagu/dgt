<?php 
$title = 'Copyright - '.$sitetitle;
$robot = 'noindex, follow';
$description = 'copyright aturan penggunaan situs '.$domain; 
include 'header.php';?>
<div id="sebar_lagu_contents">
<div class="entry-body">
<ol>
<li><b>Tanggung jawab terhadap konten</b>
<p>
Konten di website : <?php echo $domain;?> diposting untuk pengguna, oleh karena itu tanggung jawab tentang konten di situs ini adalah orang yang memposting ke dalam sistem. Pihak moderator web akan selalu memeriksa isi-isi konten di halaman web dan menghapus konten-konten yang tidak memenuhi peraturan seperti konten iklan, spam, clip spam, isi konten yang melecehkan, +18 atau isi-isi konten yang tidak sesuai dengan adat dan kebiasaan, bertentangan dengan ketentuan hukum.</p></li>

<li><b>Hak cipta</b>
<p>
Sebagai sebuah halaman web musik dan hiburan, kami menyadari dengan jelas tentang Hak cipta, karya-karya musik. website: <?php echo $domain;?> selalu berusaha untuk menjamin bahwa isi konten di halaman web atau terkait dengan nama <?php echo $domain;?> semuanya legal, namun kami tidak berkomitmen dengan pasti untuk bisa mengontrol semua informasi di halaman web. Setiap pelanggaran terhadap hak cipta jika dilaporkan akan dihilangkan dari halaman web oleh pihak moderator dalam waktu singkat.</p></li>

<li><b>Kekayaan intelektual</b>
<p>
Setiap konten yang diposting ke website: <?php echo $domain;?> meliputi desain, logo, software-software, fungsi teknik, gambar-gambar, struktur halaman dan semuanya merupakan hak cipta milik <?php echo $domain;?>. Melarang setiap penyalinan, perubahan, pameran, distribusi, pemindahan, penggunaan kembali, menerbitkan, menjual, mengizinkan, menciptakan kembali atau menggunakan konten apapun dari halaman web untuk tujuan apapu tanpa adanya penegasan secara tertulis dari pihak penguru <?php echo $domain;?>.</p></li>

<li><b>Proses pelaporan melanggar hak cipta</b>
<p>
Jika anda yakin bahwa ada konten yang dirilis melalui website: <?php echo $domain;?> melanggar hak kekayaan intelektual anda, silahkan melaporkan ke kami tentang hal pelanggaran hak cipta tersebut dengan cara mengirim email ke <?php echo $domain;?> email: <?php echo $jsonconfig['email'];?> (Perhatikan: di dalam email harus ada informasi kontak dan link koten yang melanggar hak cipta tersebut pada website: <?php echo $domain;?>). Kami akan menangani setiap laporan pelanggaran hak cipta yang kami terima berdasarkan ketentuan dari persyaratan pemakaian <?php echo $domain;?> dan peraturan dari hukum kekayaan intelektual.</p></li>
</ol>
</div>
</div><hr />
<?php include 'footer.php';