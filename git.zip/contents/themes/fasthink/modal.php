 <!-- Modal -->
  <div class="modal fade" id="copyright" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Download Mp3 &amp Video <?php echo $judul;?></h4>
        </div>
        <div class="modal-body">
		<p>
		<strong>WARNING:</strong> Lagu Mp3 / Video dengan Judul <strong><?php echo $judul;?></strong> bisa saja memiliki hak cipta !!! Kami di sini hanya menggunakan layanan api resmi dari youtube (https://developers.google.com/youtube/), Jika Anda merupakan produser / management artis yang bersangkutan dan jika lagu ini telah melanggar dari hak cipta saudara, anda bisa menghubungi author youtube yang bersangkutan di sini => <a rel="nofollow" target="_blank" href="//www.youtube.com/channel/<?php echo $channel;?>"><?php echo strtoupper($authorname);?> ON YOUTUBE</a>
		</p>
          <p style="text-align:center">
		<?php if(!bot()){ ?>
			<?php if(isset($configads['adrFastDownload']) && !empty($configads['adrFastDownload'])){ ?>
			<a href="http://adserver.adreactor.com/servlet/view/window/url/zone?zid=40&pid=3975" ><button class="btn btn-danger dl"><i class="fa fa-arrow-circle-o-down"></i> FAST DOWNLOAD</button></a>
			<?php } 
		}?>

<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>http://www.youtubeinmp3.com/download/?video=https://youtu.be/<?php echo $id;?>');><button style="padding:8px;margin: 4px;background:green"><i class="fa fa-arrow-circle-o-down"></i> Download Mp3</button></a>

			<a href="javascript:void(0);" onclick=window.open('/<?php echo $streamPermalink;?>/<?php echo url_slug($judul);?>.<?php echo strrev($id);?><?php echo $ext;?>');><button style="margin: 4px;padding:8px;"><i class="fa fa-play"></i> Play Video</button></a>
			<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>http://keepvid.com/?url=https%3A%2F%2Fyoutu.be%2F<?php echo $id;?>');><button style="margin: 4px;padding:8px;background: #1abc9c;"><i class="fa fa-arrow-circle-o-down"></i> Download Video</button></a><br />
			<small>Link Download Provided By www.youtubeinmp3.com &amp; www.keepvid.com</small>
			

		  </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>