<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Latest Searches</h3>
<?php 
$data = fopen("contents/datasearch/$domain.lastsearch.dat","r");
$json = json_decode(fgets($data), true);

// print_r($json);

if(!empty($json)){
	foreach(array_slice($json, 1, $jsonconfig['maxrecent']) as $k => $v){
		$judul = $v;
		?>
		<div class="box-post" style="margin:0">
		<a title="<?php echo htmlspecialchars($judul);?>" href="/<?php echo $searchPermalink;?>/<?php echo url_slug($judul);?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
		</div>
	<?php }
} else { 
	echo '<div class="box-post" style="margin:0"> No Available Data </div>';
}