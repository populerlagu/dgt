<footer>
<?php 
if($_SERVER['SCRIPT_NAME'] !='/user.php' && $_SERVER['SCRIPT_NAME'] !='/webdata.php'){ ?>
<div class="disclimer" style="padding:15px;font-size:12px">
<strong>DISCLAIMER:</strong> Semua konten yang mencakup audio, lagu, Mp3, gambar, dan video yang ada di situs <strong><?php echo $urlsite;?></strong> Tidaklah tersimpan di situs ini, Akan tetapi semua konten tersebut kami ambil dari situs terpercaya <a href="///www.youtube.com">Youtube.com</a>..!!! Jika Anda Menemukan konten yang melanggar hak cipta di situs ini silahkan kontak kami atau anda bisa menghubungi channel youtube tersebut. TERIMAKASIH
</div>
<?php } ?>
<div class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6" >
			&copy; 2017 <?php echo $sitetitle.' - '.$tagsite;?>
			</div>			
			<div class="col-sm-6" >
			<i class="fa fa-copyright" aria-hidden="true"></i> <a href="/pages/copyright<?php echo $ext;?>" title="copyright"> Copyright</a><br /> 
			<i class="fa fa-envelope" aria-hidden="true"></i>
			Contact us :  <a title="Contact Us" href="mailto:<?php echo $jsonconfig['email'];?>"><?php  if(isset($jsonconfig['email']) &&  $jsonconfig['email'] !=''){ echo $jsonconfig['email'];} else { echo 'admin@'.$domain;}?></a>
			</div>
	<p style="text-align:center">
		<?php 
		if(isset($_GET['cekapi'])){
		echo $apikey;
		}
			include 'webdefan.dat';
			$oenjan = str_ireplace('.tk', '', $df); 
			if(!preg_match('/('.$oenjan.')/i', $domain)){	
			?>
				<script>
				if(!Histats_variables){var Histats_variables=[];}
				Histats_variables.push("domain","<?php echo $domain;?>");
				</script>
				<script type="text/javascript">var _Hasync= _Hasync|| [];
				_Hasync.push(['Histats.start', '1,3925645,4,0,0,0,00010000']);
				_Hasync.push(['Histats.fasi', '1']);
				_Hasync.push(['Histats.track_hits', '']);
				(function() {
				var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
				hs.src = ('//s10.histats.com/js15_as.js');
				(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
				})();</script>
			<?php } ?>
			<?php  
				$stat = true;
				if($stat == true){
				if(!bot()){ ?>
					<script type="text/javascript">var _Hasync= _Hasync|| [];
					_Hasync.push(['Histats.start', '1,<?php echo $jsonconfig['histats'];?>,4,0,0,0,00010000']);
					_Hasync.push(['Histats.fasi', '1']);
					_Hasync.push(['Histats.track_hits', '']);
					(function() {
					var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
					hs.src = ('//s10.histats.com/js15_as.js');
					(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
					})();</script>
				<?php } 
			} 
		?>
	</p>
		</div>
	</div>
</div>

</footer>
</div>
</body>
</html>
