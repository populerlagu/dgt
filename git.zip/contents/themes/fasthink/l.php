<?php 
if(is_file("sementara/oUbpGmR1-QM.json")){
echo file_get_contents('sementara/oUbpGmR1-QM.json');

}
// if(is_file(oUbpGmR1-QM.json)