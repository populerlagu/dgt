<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Trending Music</h3>
<?php 
$datas = 'https://www.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&regionCode=ID&videoCategoryId=10&key='.$apikey.'&maxResults='.$jsonconfig['trends'];
$jsons = json_decode(get_contents($datas));
if(!empty($jsons->items)){
	foreach($jsons->items as $value){
		$judul = $value->snippet->title;
		$videoid = strrev($value->id);
		$image 		= 'https://i.ytimg.com/vi/'.$value->id.'/default.jpg';
	?>
		<div class="box-post" style="margin:0">
		<a title="<?php echo htmlspecialchars($judul);?>" href="/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
		</div>
	<?php }
}