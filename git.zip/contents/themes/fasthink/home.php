<?php
include 'function/token.php'; 
$page = isset($match[1]) ? $match[1] : 1;
if($homedisplay == 'playlist'){
	$playid = isset($playlistid) ? $playlistid : 'PLcgx1G1K3NpigvqGIbb0E_ZHSxIzVPfz4';	
	if(!empty($match[1])){
	$_GET['page'] = $pageToken[$match[1]];
		$data ='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId='.$playid.'&pageToken='.$_GET['page'].'&maxResults=10&key='.$apikey;
	} else {
		$data ='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId='.$playid.'&maxResults=10&key='.$apikey;
	}

} elseif($homedisplay == 'search') {
	$term = isset($searchterm) ? $searchterm : 'ungu';
	if(!empty($match[1])){
	$_GET['page'] = $pageToken[$match[1]];
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&order=date&pageToken='.$_GET['page'].'&maxResults=10&key='.$apikey;
	} else {
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&order=date&maxResults=10&key='.$apikey;
	} 
	// echo $data;
} else{
	// Do Something Here :v wkwkwkkwkwkwk
}
$json = json_decode(get_contents($data));

if(!empty($json->items)) {
	$vidlist = array();
	foreach($json->items as $item){
		if($homedisplay == 'playlist'){
			$idr = $item->snippet->resourceId->videoId;
		} elseif($homedisplay == 'search') {
			$idr = $item->id->videoId;
		}
		$vidlist[] = $idr;
		}
	$source2 = get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
	$json2 = json_decode($source2);
	foreach($json2->items as $k=>$item) {
		$json->items[$k]->contentDetails = $item->contentDetails;
		$json->items[$k]->statistics = $item->statistics;
	}
}
// echo $data;
if($page > 1){
$title 		 = $sitetitle.' - Page #'.$page.' - '.$tagsite ;
$description = ' # Page '.$page.' '.$jsonconfig['description'];

} else {
$title 		 = $sitetitle.' - '.$tagsite ;
$description = $jsonconfig['description'];
$robot 		 = 'index, follow';
}
include 'header.php';
?>
<div id="sebar_lagu_contents">
<div class="main">
<div class="col-sm-9" style="    padding: 10px 5px 0 5px;">
<section>
<?php 
if(!empty($json->items)){
	foreach($json->items as $k => $v){
		$judul  	= $v->snippet->title;
		if($homedisplay == 'playlist'){
			$videoid 	= strrev($v->snippet->resourceId->videoId);
			$vid		= $v->snippet->resourceId->videoId;
		} elseif($homedisplay == 'search'){
			$videoid 	= strrev($v->id->videoId);
			$vid 		= $v->id->videoId;
		}
		$tanggal 	= $v->snippet->publishedAt;
		$author 	= $v->snippet->channelTitle;
		$duration 	= durationYT($v->contentDetails->duration);
		$size 	 	= size($v->contentDetails->duration);
		$views 		= $v->statistics->viewCount;
		$image 		= 'https://i.ytimg.com/vi/'.$vid.'/default.jpg';
		// $play = 'https://www.youtube.com/embed/'.$videoid;
		if($judul !='Private video' && $judul !='Deleted video' && $duration !='00:00'){
		?>
<article class="box-post"> 
<div class="entry"><img width="100" src="<?php echo $image;?>" height="80" alt="<?php echo htmlspecialchars($judul);?>" title="<?php echo htmlspecialchars($judul);?>" style="margin:0 10px 0 0;float:left"> 
<h2 class="roolitems"><i class="fa fa-music" aria-hidden="true"></i> 
<a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
</h2> 
<p style="margin:0 10px 0 0"><i class="fa fa-hdd-o" aria-hidden="true"></i> Size: <?php echo $size;?> </p> 
<p style="margin:0 10px 0 0"><i class="fa fa-clock-o" aria-hidden="true"></i> Duration: <?php echo $duration;?></p> 
<p style="margin:0 10px 0 0"><i class="fa fa-calendar" aria-hidden="true"></i> Diupload: <?php echo dateYT($tanggal);?></p> 
<p style="margin:0 10px 0 0"><i class="fa fa-file-text-o" aria-hidden="true"></i> <?php echo $jsonconfig['fsinglepage'];?> <?php echo htmlspecialchars($judul);?> Gratis mp3 dan mp4</p> 
<div class="details"><a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>">
<button class="btn-sm btn-default pull-right" ><i class="fa fa-arrow-circle-o-down black"></i> View Detail</button></a> <div style="clear:both"></div> </div></div> 

</article>		
	<?php 
		}
	}	//end foreach
} else {
	echo 'oooooops Something Wrong.....';
}
?>
</section>


<div class="paging-ppage" id="paging-ppage">
<?php 
	$pagingtparam = array(
		'totalitem' => $json->pageInfo->totalResults,
		'itemperpage' => 10,
		'firstpageurl' => $urlsite,
		'urlpattern' =>  $urlsite.'/page/%d'.$ext,
		//'linkperpage' => 5,
	);
	$paging = pager($page, $pagingtparam);
	echo join(' ', $paging);
?>
</div> <!--end paging-->
<div style="clear:both"></div>
</div>

</div>
<div class="col-sm-3"  style="padding: 0;">
<?php include 'sidebar.php';?>
</div><!--end kanan--><div style="clear:both"></div>
</div> <!--end main-->
<?php include 'footer.php';?>