<?php 
include 'function/token.php';
$term = $searchresult;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'relevance';
$page = isset($terme[0]) ? $terme[0] : 1;
// $color = array('red', 'green', 'purple','#a94442','#31708f','#3c763','#7f6ad2','#3c7653','red', 'green');
// echo $term;
if($terme[0] > 1){
$_GET['page'] = $pageToken[$terme[0]];
	$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.$term.'&pageToken='.$_GET['page'].'&order='.$sort.'&maxResults=10&key='.$apikey;
} else {
	$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode(fixed($term)).'&order='.$sort.'&maxResults=10&key='.$apikey;
}

$json 	= json_decode(get_contents($data));
if(!empty($json->items)) {
	$vidlist = array();
	foreach($json->items as $item) $vidlist[] = $item->id->videoId;
	$source2 = get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
	$json2 = json_decode($source2);
	foreach($json2->items as $k=>$item) {
		$json->items[$k]->contentDetails = $item->contentDetails;
		$json->items[$k]->statistics = $item->statistics;
	}
}

//custom 
$conf['title']	 = fixed($term);
$conf['author']  = fixed($json->items[0]->snippet->channelTitle);
$conf['size'] 	 = size($json->items[0]->contentDetails->duration);
$conf['duration']= durationYT($json->items[0]->contentDetails->duration);
$conf['view']    = $json->items[0]->statistics->viewCount;
$conf['like']    = $json->items[0]->statistics->likeCount;
$conf['date']    = dateYT($json->items[0]->snippet->publishedAt);

if(preg_match('/lagu|mp3/i', Replace($configcustom['customSearchTitle']))){
	$conf['customSearchTitle'] = str_ireplace(array('lagu lagu','mp3 mp3'), array('lagu','mp3'), Replace($configcustom['customSearchTitle']));
} else {
	$conf['customSearchTitle'] = Replace($configcustom['customSearchTitle']);
}
$conf['customSearch'] = Replace($configcustom['customSearch']); 
//end custom

foreach($json->items as $block){
	$bloked [] = $block->snippet->title.' '.$block->snippet->description;
}

$blokedkeyword = join(' ', $bloked);

// echo $blokedkeyword;

if($terme[0] > 1){
$title 		 = fixed($conf['customSearchTitle']).' #Page '.$terme[0].' - '.$sitetitle;
$h1title 	 = fixed($conf['customSearchTitle']);	
$description = 'Page '.$terme[0].' - '.htmlspecialchars($conf['customSearch']);
$robot = 'noindex, follow';
} elseif(blocked(fixed($term))){
$title           = fixed($term).' - '.$sitetitle;
$h1title 		 = fixed($conf['customSearchTitle']);	
$robot 			= 'noindex, nofollow';	
} else {
$title 		     = fixed($conf['customSearchTitle']).' - '.$sitetitle;	
$h1title 		 = fixed($conf['customSearchTitle']);	

$description = htmlspecialchars($conf['customSearch']);
$robot 		 = $jsonconfig['robotsearch'];
}

if(!bot()){
	if(isset($term) && $term !='' && strlen($term) > 5){
		$filename = "contents/datasearch/$domain.lastsearch.dat";
			$max = 100;
			$recent [$term] = fixed($term);
			$recentlawas = @json_decode(@file_get_contents($filename), true);
			if(is_array($recentlawas)) {
				$recentlawas = array_slice($recentlawas, 0, $max, true);
				$recent = $recent + $recentlawas;
				
			}
			
			file_put_contents($filename, json_encode($recent));
	}
}

include 'header.php';
?>
<?php ///pengaman 
if(blocked(fixed($term))){
	// include 'notinclude.php';
} ?>
<div id="sebar_lagu_contents">
<div class="main">
<div class="col-sm-9" style="padding-left:0">
<h1 class="mainh1_sebar_lagu"><?php echo strtoupper(htmlspecialchars($h1title));?></h1>
<?php if(isset($configads['adGlobal']) && $configads['adGlobal'] =='on'){ 
if(!blocked(fixed($term.' '.$blokedkeyword))){ ?>
<p>
<?php include 'adCode/adatas.php'; //adcode bawah?>
</p>
<?php }
} ?>
<section>
<?php 
if(!empty($json->items)){ ?>
<div class="panel-group">
<div style="border-radius: 0;" class="panel panel-default">
  <div class="panel-heading" style="background-color: #d9edf7;">
	<h4 class="panel-title">
	  <a data-toggle="collapse" href="#collapse1">Sort By : <span class="glyphicon glyphicon-arrow-down"></span></a>
	</h4>
  </div>
  <div id="collapse1" class="panel-collapse collapse">
	<div class="panel-body"><a href="?sort=date">Terbaru </a></div>
	<div class="panel-footer"><a href="?sort=rating">Berbintang </a></div>
	<div class="panel-body"><a href="?sort=title">Urut By Alfabhet </a></div>
	<div class="panel-footer"><a href="?sort=viewCount">Paling Populer </a></div>
  </div>
</div>
</div>

<?php

foreach($json->items as $k => $v){
	$judul  	= $v->snippet->title;
	$videoid 	= strrev($v->id->videoId);
	// $encryptyId = encryptYT($videoid, $data['shufflekey']);
	$tanggal 	= $v->snippet->publishedAt;
	$author 	= $v->snippet->channelTitle;
	$duration 	= durationYT($v->contentDetails->duration);
	$size 	 	= size($v->contentDetails->duration);
	$views 		= $v->statistics->viewCount;
	$image 		= 'https://i.ytimg.com/vi/'.$v->id->videoId.'/default.jpg';
	?>
<article class="box-post"> 
<div class="entry"><img width="100" src="<?php echo $image;?>" height="80" alt="<?php echo htmlspecialchars($judul);?>" title="<?php echo htmlspecialchars($judul);?>" style="margin:0 10px 0 0;float:left"> 
<h2 class="roolitems"><i class="fa fa-music" aria-hidden="true"></i> 
<a href="/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
</h2> 
<p style="margin:0 10px 0 0"><i class="fa fa-hdd-o" aria-hidden="true"></i> Size: <?php echo $size;?> </p> 
<p style="margin:0 10px 0 0"><i class="fa fa-clock-o" aria-hidden="true"></i> Duration: <?php echo $duration;?></p>
<p style="margin:0 10px 0 0"><i class="fa fa-calendar" aria-hidden="true"></i> Diupload: <?php echo dateYT($tanggal);?></p> 
<p style="margin:0 10px 0 0"><i class="fa fa-file-text-o" aria-hidden="true"></i> <?php echo htmlspecialchars($judul);?> Gratis mp3 dan mp4</p> 
<div class="details"><a href="/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><button class="btn-sm btn-default pull-right" ><i class="fa fa-arrow-circle-o-down black"></i> View Detail</button></a> <div style="clear:both"></div> </div></div> 
</article>		
<?php 
	}
} else {
	echo 'sorry no result';
} ?>

<?php if(isset($configads['adGlobal']) && $configads['adGlobal'] =='on'){ 
if(!blocked(fixed($term.' '.$blokedkeyword))){ ?>
<p>
<?php include 'adCode/adbawah.php'; //adcode bawah?>
</p>
<?php }
} ?>
<div class="paging-ppage" id="paging-ppage">
<?php 
	$pagingtparam = array(
		'totalitem' => $json->pageInfo->totalResults,
		'itemperpage' => 10,
		'firstpageurl' => $urlsite.'/'.$searchPermalink.'/'.$term.$ext,
		'urlpattern' =>  $urlsite.'/'.$searchPermalink.'/%d/'.$term.$ext,
		//'linkperpage' => 5,
	);
	$paging = pager($page, $pagingtparam);
	echo join(' ', $paging);
?>
</div> <!--end paging-->
<div style="clear:both"></div>
</section>
</div>
<div class="col-sm-3" style="padding: 0;">
<?php include 'sidebar.php';?>
</div><!--end kanan-->
<div style="clear:both"></div>
</div> <!--end main-->
<?php include 'footer.php';