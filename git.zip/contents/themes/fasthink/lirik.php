<?php 
$folderSementara = 'sementara/';
$fileTemp = $folderSementara.$id.'.json';
if (!is_dir($folderSementara)) { //jika folder sementara tidak ditemukan otomatis membuat
  mkdir($folderSementara);//buat folder
}
			
if(file_exists($fileTemp)){
echo '<h3 id="lirik"><u>Lirik Lagu '.fixed($judul).'</u></h3>';
echo '<div class="lirik">'. file_get_contents('sementara/'.$id.'.json').'</div>';
} else {
function cut($content,$start,$end){
  if($content && $start && $end) {
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $r[0];
    }
    return '';
  }
}

function graber($url) {
	if(function_exists('curl_exec')) {
		$header[0] = "Accept-Language: en";
		$header[] = "User-Agent: Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Googlebot/2.1; +http://www.google.com/bot.html) Safari/537.36";
		$header[] = "Pragma: no-cache";
		$header[] = "Cache-Control: no-cache";
		$header[] = "Accept-Encoding: gzip,deflate";
		$header[] = "Content-Encoding: gzip";
		$header[] = "Content-Encoding: deflate";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_REFERER, $url);
		$data = curl_exec($ch);
		curl_close($ch);
	}
	else {
		$data = @file_get_contents($url);
	}
	return $data;
}

// $query = $_GET['q'];
if(isset($_GET['lirik'])){
	$query = $_GET['lirik'];
} else {
	$query = $judul;
}
	
include 'lirikreplace.php';
	echo $query;

$cgi = array(
	'https://webproxy.to/browse.php?u=https%3A%2F%2Fwww.smule.com%2Fsearch%2Fby_type%3Fq%3D'.urlencode($query).'%26type%3Dsong%26sort%3Dpopular%26offset%3D0%26size%3D0%26type%3Dsong&b=29&f=facebook.com',
	'https://www.websurf.in/browse.php?u=https%3A%2F%2Fwww.smule.com%2Fsearch%2Fby_type%3Fq%3D'.urlencode($query).'%26type%3Dsong%26sort%3Dpopular%26offset%3D0%26size%3D0%26type%3Dsong&b=29&f=google.com',
	'http://buka.link/browse.php?u=https%3A%2F%2Fwww.smule.com%2Fsearch%2Fby_type%3Fq%3D'.urlencode($query).'%26type%3Dsong%26sort%3Dpopular%26offset%3D0%26size%3D0%26type%3Dsong&b=24&f=norefer',
	);
	
$smule  = $cgi[array_rand($cgi)];
$jsonlirik = json_decode(graber($smule),true);
if(isset($jsonlirik['list'][0]['web_url'])){
    $weburls = $jsonlirik['list'][0]['web_url'];
} else {
	 $weburls = $jsonlirik['list'][1]['web_url'];
}

$hasile = 'https://www.smule.com'.$weburls.'';
$lirika= graber ('https://www.websurf.in/browse.php?u='.urlencode($hasile)).'&b=28&f=norefer';
$explode = explode('<div class="lyrics content ">', $lirika);
	array_shift($explode);
	$lirik = cut($explode[0],'<p>','</p>');		
	$lirik = str_replace(".", "", $lirik);
	// $lirik		= preg_replace('/\r|\n/', ' ', $lirik).'';
	$lirik		= preg_replace('/[[:^print:]]/', '', $lirik);
	$lirik = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $lirik); 
	$lirik = str_replace("<br><br><br>", "", $lirik);

	 $li ['lirik'] = $lirik;
	  if($li['lirik'] !=''){
		  // echo ;
			
			// if(!){
				$fp = fopen($fileTemp, 'w');  //buat file
				fwrite($fp, $lirik); //tulis konten dari output buffer  di file sementara
				fclose($fp); //close file
			// }
	  ?>
  
<h3 id="lirik"><u>LIRIK LAGU <?php echo strtoupper($judul);?></u></h3>
	  <div class="lirik"><?php echo $lirik;?></div>
	<?php } else { ?>	
<h3 id="description">Description:</h3>
<?php echo nl2br($des)!='' ? nl2br($des) : $judul; ?>
	<?php } 
	
} //end cek file
	
?>
</p>
