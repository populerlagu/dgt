<p class="center">
<?php
include 'webdefan.dat';

// echo $df;
if(!bot()){
	$safe = 'http://smarturl.it/linkweb?links=';
} else { 
    $safe = '';
}
if(substr_count($duration, ':') == 2){
	// echo 'panjang';
}
// print_r($matches[1]);
// echo $hasil;
if($act == 'Single Page'){ 
	if(preg_match('/perdana|mega|dd|aglies|chgb|aini|sm-pro/i', $authorname.' '.$judul)){ ?>
	<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>https://youtu.be/<?php echo $id;?>');><button style="padding:8px;background:green"><i class="fa fa-arrow-circle-o-down"></i> Preview Music</button></a>
	<?php } else { ?>
		<?php if(!bot()){
		if(!preg_match('/'.$df.'|uyeshare.bglweb/', $domain)){	
		?>
			<a href="http://adserver.adreactor.com/servlet/view/window/url/zone?zid=40&pid=3975" ><button class="btn btn-danger dl" style="background:red"><i class="fa fa-arrow-circle-o-down"></i> FAST DOWNLOAD</button></a>
		<?php } ?>
			<?php if(isset($configads['adrFastDownload']) && !empty($configads['adrFastDownload'])){ ?>
			<a href="http://adserver.adreactor.com/servlet/view/window/url/zone?zid=40&pid=3975" ><button class="btn btn-danger dl"><i class="fa fa-arrow-circle-o-down"></i> FAST DOWNLOAD</button></a>
			<?php } ?>
		<?php } //hanya tampil saat orang yg visite ?>
	<button data-toggle="modal" data-target="#copyright" class="btn btn-default dl"><i class="fa fa-arrow-circle-o-down"></i> Download / Listening</button>

	 <?php } //end pengaman label perdana dkk
} else { ?>
 <a rel="nofollow" href="javascript:void(0);" onclick=window.open('/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo strrev($id);?><?php echo $ext;?>');><button style="padding:8px;"><i class="fa fa-arrow-circle-o-down"></i> Download </button></a>

 <?php } ?>
 </p>
 <?php include 'modal.php';?>
