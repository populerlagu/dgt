<?php
$yt = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.strrev($videoid).'&key='.$apikey;
// echo $yt;
$json  = json_decode(get_contents($yt));
if(!empty($json->items)){
	$id 		= $json->items[0]->id;
	$judul		= $json->items[0]->snippet->title;
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = $json->items[0]->snippet->description;
	$channel 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= $json->items[0]->snippet->channelTitle;
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= 'https://img.youtube.com/vi/'.$id.'/mqdefault.jpg';
	$tag 		= $json->items[0]->snippet->tags;
	// print_r($tag);
} else {
$data = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q='.urlencode(fixed($altname)).'&maxResults=1&key='.$apikey;
$json = json_decode(get_contents($data));
	if(!empty($json->items)) {
		$vidlist = array();
		foreach($json->items as $item) $vidlist[] = $item->id->videoId;
		$source2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
		$json2 = json_decode($source2);
		foreach($json2->items as $k=>$item) {
			$json->items[$k]->contentDetails = $item->contentDetails;
			$json->items[$k]->statistics = $item->statistics;
		}
	}
// echo $data;
	$id 		= $json->items[0]->id->videoId;
	$judul		= fixed($json->items[0]->snippet->title);
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = fixed($json->items[0]->snippet->description);
	$authorid 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= fixed($json->items[0]->snippet->channelTitle);
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= '//img.youtube.com/vi/'.$id.'/mqdefault.jpg';
}

//custom 
$conf['title']	 = $judul;
$conf['author']  = $authorname;
$conf['size'] 	 = $size;
$conf['duration']= $duration;
$conf['view']    = $play;
$conf['like']    = $like;
$conf['date']    = dateYT($pub);

$conf['customStreamingTitle'] = Replace($configcustom['customStreamingTitle']);
$conf['customStreaming'] = Replace($configcustom['customStreaming']); 
//end custom

//meta
$title 		 = htmlspecialchars($conf['customStreamingTitle']).' - '.$sitetitle;
$description = htmlspecialchars($conf['customStreaming']);
$robot 		 = $jsonconfig['streamrobot'];
// include 'dl.php';
// include 'z.php';
include 'header.php';
?>
<div class="breadcrumb-wrap" xmlns:v="http://rdf.data-vocabulary.org/#"><ol class="breadcrumb btn-box"> <li><span typeof="v:Breadcrumb"><a href="<?php echo $urlsite;?>" rel="v:url" property="v:title">Home</a></span></li> <li><span typeof="v:Breadcrumb"><a href="/<?php echo $authorPermalink;?>/<?php echo url_slug($authorname);?><?php echo $ext;?>" rel="v:url" property="v:title"><?php echo htmlspecialchars($authorname);?></a></span></li> <li><span property="v:title"><?php echo htmlspecialchars($judul);?></span></li> </ol> </div>
<div id="sebar_lagu_contents">
<div class="entry-body">
<div class="col-sm-9" style="padding-left:0">
<h1 class="mainh1_sebar_lagu entry-title clearfix"><?php echo strtoupper(htmlspecialchars($jsonconfig['fstreampage'].' '.$judul));?></h1>
<div class="meta-lagu">	<span class="author"><i class="fa fa-street-view"></i>
 By <a class="url fn" rel="author"  href="/<?php echo $authorPermalink;?>/<?php echo url_slug($authorname);?><?php echo $ext;?>" title="posts by <?php echo $authorname;?>" rel="author"><?php echo $authorname;?></a></span>
	<span class="entry-date updated"><i class="fa fa-calendar" aria-hidden="true"></i> On <?php echo dateYT($pub);?></span> 
</div>

<div class="entry-content">
<?php if($configads['adGlobal']=='on'){ ?>
<p>
<?php include 'adCode/adatas.php';?>
</p>
<?php } ?>

<p class="center">
<iframe width="100%" height="230" src="//www.youtube.com/embed/<?php echo $id;?>?feature=player_embedded&amp;autoplay=0&amp;rel=0&amp;fs=0&amp;theme=light&amp;showinfo=0&amp;hd=0&amp;autohide=0&amp;color=white" frameborder="0" allowfullscreen="0"></iframe>
</p>

<p>
<table style="margin:0 auto;width:100%;"> 
<tbody>
<tr><td>Title</td><td>: <a href="/<?php echo $searchPermalink;?>/<?php echo url_slug($judul);?><?php echo $ext;?>"><?php echo $judul;?></a></td></tr>
<tr><td>Size</td><td>: <?php echo $size;?></td></tr>
<tr><td>Duration</td><td>: <?php echo $duration;?></td></tr>
<tr><td>Views</td><td>: <?php echo $play;?></td></tr>
<tr><td>Type </td><td>: Audio / Mpeg</td></tr>
<tr><td>Bitrate </td><td>: 192 KBPS</td></tr>
<tr><td>Author</td><td>: <?php echo htmlspecialchars($authorname);?></td></tr>
<tr><td>Source</td><td>: https://www.youtube.com/watch?v=<?php echo $id;?></td></tr>
</tbody>
</table>
</p>
<p>
<?php echo nl2br($des);?>
</p>

<p>
<?php 
include 'safelink.php';
?>
</p>

<?php if($configads['adGlobal']=='on'){ ?>
<p>
<?php include 'adCode/adbawah.php'; //adcode bawah?>
</p>
<?php } ?>
<p>
<strong>Tags: </strong> <?php if(!empty($tag)){ echo join(', ', $tag); } else { echo 'Download, Mp3 vide, flv, 3GP, mp4';}?> 
</p>

<p>
<div id="share-button-templatoid">
<p>Share on:</p>
<a class="facebook" href="http://www.facebook.com/sharer.php?u=<?php echo urlencode($fullpatch);?>&amp;title=<?php echo urlencode($title);?>" rel="nofollow" style="background:#3b5998;" target="_blank" title="Facebook"><i class="fa fa-facebook"></i> Facebook</a>
<a class="facebook" href="https://plus.google.com/share?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#c0361a;" target="_blank" title="Google+"><i class="fa fa-google-plus"></i> Google+</a>
<a class="twitter" href="https://twitter.com/intent/tweet?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#4099ff;" target="_blank" title="Twitter"><i class="fa fa-twitter"></i> Twitter</a>
<div class="clear"></div>
</div>
</p>

<div id="related">
	<?php include 'related.php';?>
</div>
</div><?php //end entry content ?>
</div>
<div class="col-sm-3" style="padding:0">
<?php include 'sidebar.php';?>
</div>
<div style="clear:both">

</div>

</div>

<?php include 'footer.php';?>

