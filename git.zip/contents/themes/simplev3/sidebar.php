<?php if(isset($_SESSION["username"])){ ?>
<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Dashbord</h3>
<div class="box-post" style="margin:0">
<a href="/Aamiin/" title="Home">Admin</a>
</div>

<div class="box-post" style="margin:0">
<a rel="nofollow" href="/suntik/" title="Home">Suntik Keyword</a>
</div>

<div class="box-post" style="margin:0">
<a rel="nofollow" href="/themes/edit.php?file=minify.css&theme=<?php echo $configcustom['themes'];?>" title="Edit Tema">Edit Thema</a>
</div>
<div class="box-post" style="margin:0">
<a rel="nofollow" href="/webdatas/" title="Home">Web Data</a>
</div>
<div class="box-post" style="margin:0">
<a rel="nofollow" href="/Aamiin/logout.php?return=<?php echo urlencode($fullpatch);?>" title="Home">Logout</a>
</div>
<?php } ?>
<?php 
if($jsonconfig['latestDownload'] == 'on'){
	include 'zlatest.php';
}

if($jsonconfig['popular'] == 'on'){
	include 'populer.php';
}