<?php 
$related = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&relatedToVideoId='.$id.'&maxResults=9&key='.$apikey;
$jsonR 	 = json_decode(file_get_contents($related)); 
// echo $related;
if(!empty($jsonR->items)) {
	$vidlist = array();
	foreach($jsonR->items as $item) $vidlist[] = $item->id->videoId;
	$sing2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
	$json2 = json_decode($sing2);
	foreach($json2->items as $k=>$item) {
		$jsonR->items[$k]->contentDetails = $item->contentDetails;
		$jsonR->items[$k]->statistics = $item->statistics;
	}
}

if(!empty($jsonR->items)){?>
<h4>Related Music:</h4> 
<?php
foreach (array_slice($jsonR->items,0,8,true) as $key => $value) { 
// $sort = isset($_GET['sort']) ? $_GET['sort'] : 'relevance';
if($act == 'Single Page') {
	$linker = $singlePermalink;
} else {
	$linker = $streamPermalink;
}
?>
<div class="responsive">
  <div class="gallery">
    <a href="/<?php echo $linker;?>/<?php echo url_slug($value->snippet->title);?>.<?php echo strrev($value->id->videoId);?><?php echo $ext;?>">
      <img src="https://i.ytimg.com/vi/<?php echo $value->id->videoId;?>/default.jpg" alt="<?php echo $value->snippet->title;?>" width="100" height="100">
    </a>
    <div class="desc" STYLE="overflow: hidden;
    text-overflow: ellipsis;">
	<a title="<?php echo htmlspecialchars(ucwords(strtolower($value->snippet->title)));?>" <?php echo htmlspecialchars($judul);?> href="/<?php echo $linker;?>/<?php echo url_slug($value->snippet->title);?>.<?php echo strrev($value->id->videoId);?><?php echo $ext;?>"><?php echo htmlspecialchars(ucwords(strtolower($value->snippet->title)));?></a>
	</div>
  </div>
</div>

<?php }
} ?>
<div style="clear:both"></div>





