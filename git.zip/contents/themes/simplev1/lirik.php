<?php 
function cut($content,$start,$end){
  if($content && $start && $end) {
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $r[0];
    }
    return '';
  }
}


$query = $judul;	
include 'lirikreplace.php';
$smule = 'https://www.smule.com/search/by_type?q='.rawurlencode($query).'&type=song&sort=popular&offset=0&size=0&type=song';
$jsonlirik = json_decode(file_get_contents($smule));
$weburl= $jsonlirik->list[0]->web_url;
$hasil = 'http://www.smule.com'.$weburl;
// echo $hasil;
$lirik = file_get_contents($hasil);
	$explode = explode('<div class="lyrics content ">', $lirik);	
	array_shift($explode);
	$lirik = cut($explode[0],'<p>','</p>');	
	$lirik = str_replace(".", "", $lirik);
	// $lirik		= preg_replace('/\r|\n/', ' ', $lirik).'';
	$lirik		= preg_replace('/[[:^print:]]/', '', $lirik);
	$lirik = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $lirik); 
	$lirik = str_replace("<br><br><br>", "", $lirik);

	 $li [lirik] = $lirik;
	  if($li['lirik'] !=''){		
	  ?>
  
<h3 id="lirik"><u>LIRIK LAGU <?php echo strtoupper($judul);?></u></h3>
	  <div style="border-left:1px solid #333;padding-left:8px"><?php echo $lirik;?></div>
	<?php } else { ?>	
<h3 id="description">Description:</h3>
<?php echo nl2br($des)!='' ? nl2br($des) : $judul; ?>
	<?php } ?>
</p>
