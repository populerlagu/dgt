<p class="center">
<?php
if($configads['safelink'] =='on'){
	$safe = 'http://smarturl.it/directOm?v=';
} else {
	$safe ='';
}
if(substr_count($duration, ':') == 2){
	// echo 'panjang';
}

if($act == 'Single Page'){ 
	if(preg_match('/nagaswara|samudra|perdana|mega|dd|aglies|chgb|aini/i', $authorname)){ ?>
	<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>https://youtu.be/<?php echo $id;?>');><button style="padding:8px;background:green"><i class="fa fa-arrow-circle-o-down"></i> Preview Music</button></a>
	<?php } else { ?>
	<button data-toggle="modal" data-target="#copyright" class="btn btn-default links" ><i class="fa fa-arrow-circle-o-down"></i> Download / Listening</button>

	 <?php } //end pengaman label perdana dkk
} else { ?>
 <a rel="nofollow" href="javascript:void(0);" onclick=window.open('/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo strrev($id);?><?php echo $ext;?>');><button style="padding:8px;"><i class="fa fa-arrow-circle-o-down"></i> Download </button></a>

 <?php } ?>
 </p>
 <?php include 'modal.php';?>
