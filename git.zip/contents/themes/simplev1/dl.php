<?php 
$json = json_decode(file_get_contents('http://www.youtubeinmp3.com/fetch/?format=JSON&video=http://www.youtube.com/watch?v='.$videoid),true);
$e = $json['link'];
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0");  
curl_exec($ch); 
curl_setopt($ch, CURLOPT_URL, $e); 
curl_setopt($ch, CURLOPT_REFERER, "http://www.youtubeinmp3.com"); 
curl_setopt($ch, CURLOPT_HEADER, true); 
$link = curl_exec($ch); 

preg_match_all('/^Location:(.*)$/mi', $link, $matches); 
$hasil = preg_replace("/(\r\n|\r|\n)+/","", $matches[1][0]); 
$hasil = str_replace(" ","", $hasil);

	// if($matches[1][0]){ 
		// echo '<a rel="nofollow" style="color:white" href="'.$hasil.'+[bursamusik.putrikipas.com]">Download Mp3 - ['.size($data->items[0]->contentDetails->duration).']</a>'; 
	// } else {
		// echo 'mp3 Not AVailable';
	// }
// highlight_file(__FILE__); 
?> 