<?php if(isset($_SESSION["username"])){ ?>
<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Dashbord</h3>
<?php 
$sid = array(
	'/Aamiin/'  => 'Admin',
	'/tugas.php'  => 'Tugas',
	'/kirim.php' => 'Share Keyword',
	'/suntik/' => 'Suntik Keyword',
	'/gas.php'  => 'Bat Generator',
	'/on.php'   => 'View Online User',
	'/myweb.php'=> 'List Web Member',
	'/themes/edit.php?file=minify.css&theme='.$configcustom['themes'] => 'Theme Editor <span style="color:red">(Vip Member)</span>',
	'/Aamiin/logout.php?return='.urlencode($fullpatch) => 'logout',
);
		foreach($sid as $k => $v){ ?>
			<div class="box-post" style="margin:0">
			 <span class="glyphicon glyphicon-ok" style="color:#969696"></span> <a target="_blank" rel="nofollow" href="<?php echo $k;?>" title="Home"><?php echo $v;?></a>
			</div>
		<?php } ?>

<?php } ?>
<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Random Musik</h3>

<?php 
$r = file_get_contents('http://www.populerlagu.men');
$e = preg_match_all('/<div class="box-post" style="margin:0"> <a title="([^>]+)" href="/i', $r, $match);
$list = $match[1];
if($list){
	foreach(array_slice($list,0,10) as $k => $value){
		$value = htmlspecialchars_decode($value);
		echo '<div class="box-post" style="margin:0"><a href="/'.$searchPermalink.'/'.url_slug($value).$ext.'">'.$value.'</a></div>';
	}
} else {
		echo '<div class="box-post" style="margin:0">Refreshing Data.......</div>';
}
?>

<?php 
if($jsonconfig['latestDownload'] == 'on'){
	include 'zlatest.php';
}

if($jsonconfig['popular'] == 'on'){
	// include 'populer.php';
}
if($jsonconfig['robotsearch']){
	include 'zlatestsearch.php';
}