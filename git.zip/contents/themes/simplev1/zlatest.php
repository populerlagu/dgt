<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Latest Download</h3>
<?php 
$data = fopen("contents/data/$domain.lastdownload.dat","r");
$json = json_decode(fgets($data), true);
if(!empty($json)){
	foreach(array_slice($json, 1, $jsonconfig['maxrecent']) as $k => $v){
		$judul = $v['title'];
		$durasi = $v['durasi'];
		$size 	= $v['size'];
		$views 	= $v['views'];
		$videoid = strrev($k);
		?>
		<div class="list" style="margin:0">
		<a title="<?php echo htmlspecialchars($judul);?>" href="/<?php echo $singlePermalink;?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
		</div>
	<?php }
} else { 
	echo '<div class="box-post" style="margin:0"> No Available Data </div>';
}