<?php 
include 'minify/html-minify.php';
include 'minify/absolute-to-relative-urls.php';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta name="theme-color" content="#0a8631">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo ($title);?></title> 
<meta name="description" content="<?php echo ($description);?>">
<meta charset="utf-8"> 
<meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" name="viewport">
<meta name="revisit-after" content="1 days" />
<meta content="<?php echo $robot;?>" name="robots" />
<meta content="<?php echo $robot;?>" name="googlebot"/>
<meta content="<?php echo $robot;?>" name="msnbot"/>
<link rel="icon" href="/favicon/<?php echo $domain;?>.favicon.ico" type="image/x-icon">
<link rel="canonical" href="<?php echo $fullpatch;?>" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<style>
<?php 
if(isset($configcss['css']) && $configcss['css'] !=''){
echo $css;
} else {
 include 'minify.css'; 
}
?>
</style>
<?php if(isset($jsonconfig['suggestSearch']) && $jsonconfig['suggestSearch'] =='on' ){ ?>
<link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){$('input[name="cari"]').autocomplete({source:function(query,response){$.getJSON("https://suggestqueries.google.com/complete/search?callback=?",{"hl":"id","jsonp":"suggestCallBack","q":query.term,"ds":"yt","client":"youtube",});suggestCallBack=function(data){var suggestions=[];$.each(data[1],function(key,val){suggestions.push(val[0]);});suggestions.length=10;response(suggestions);};},delay:0,});});
</script>
<?php } ?>
<?php if(isset($configads['adreactor']) && $configads['adreactor'] =='on'){ ?>
<?php echo $configads['adrheadCode'];?>
<?php } ?>
</head>
<body>
<div id="wrapper">
<div class="header">
<?php if($act == 'home' || $act == 'homepage'){ ?>
<h1 style="font-size: 25px;"><a href="<?php echo $urlsite;?>" class="go"><?php echo strtoupper($sitetitle);?></a></h1>
<h2 class="hide" style="font-size: 14px;"><?php echo $tagsite;?></a></h2>
<?php } else { ?>
<h2 style="font-size: 25px;"><a href="<?php echo $urlsite;?>" class="go"><?php echo strtoupper($sitetitle);?></a></h2>
<h3 class="hide" style="font-size: 14px;font-weight:500"><?php echo $tagsite;?></a></h3>
<?php } ?>
</div>
<?php if($_SERVER['SCRIPT_NAME'] != '/function/install.php' && $_SERVER['SCRIPT_NAME'] != '/Aamiin/index.php' && $_SERVER['SCRIPT_NAME'] != '/Aamiin/login.php' && $_SERVER['SCRIPT_NAME'] != '/Aamiin/signup.php'){?>

<nav id="mymenu"><input type="checkbox"> <label><i class="fa fa-bars white"></i></label>
<ul>
	<li> <a href="<?php echo $urlsite;?>" title="Home"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
	<?php 
	$menu = explode(',', $jsonconfig['menu']);
	// print_r($menu);
	foreach($menu as $nav){ 
	if(!preg_match('/more|More/i', $nav)){ ?>
	<li><a href="<?php echo $urlsite;?>/<?php echo $searchPermalink;?>/<?php echo url_slug($nav);?><?php echo $ext;?>"><?php echo fixed($nav);?></a></li>
	<?php } } ?>
	<?php if(isset($menu[5]) && $menu[5] !=''){ ?>
	<li><a href="javascript:void(0)" title="More">More</a>
	<?php } ?>
		<ul>
		<?php foreach($menu as $nav){ 
		// echo $nav;
		if(preg_match('/more|More/i', $nav)){
		$more = str_ireplace('more','', $nav);
		?>
		<li><a href="<?php echo $urlsite;?>/<?php echo $searchPermalink;?>/<?php echo url_slug($more);?><?php echo $ext;?>" title=""><?php echo $more;?></a></li>
		<?php } 
		} ?>
		</ul>
	</li>
</ul> 
</nav>
<div id="search-box" class="top"> 
<form action="/" id="search-form" method="GET" target="_top"> 
<span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
<input id="search-text" placeholder="Search" type="text" name="cari" class="ui-autocomplete-input" autocomplete="off"> 
<button id="search-button" type="submit"> </button>
</form>
 </div>
<?php } ?>