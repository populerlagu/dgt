<?php 
die ('<div id="sebar_lagu_contents">
<h1 class="mainh1_sebar_lagu">'.htmlspecialchars($h1title).'</h1>
<div class="main">Oooops.... No Result About Your Query, Please Using another Query<br/><p class="center"><strong>NGAJI YUK </strong><br/> <img style="width:100%;height:auto" scr="http://cintakata.com/wp-content/uploads/2013/05/Kaligrafi-Islam-Allah-HD-Wallpaper.jpg"/><iframe style="display:none" width="100%" height="230" src="//www.youtube.com/embed/GOGIEc7s_6k?feature=player_embedded&amp;autoplay=1&amp;rel=0&amp;fs=0&amp;theme=light&amp;showinfo=0&amp;hd=0&amp;autohide=0&amp;color=white" frameborder="0" allowfullscreen="0"></iframe><p class="center"><a href="'.$urlsite.'">Back To HOME</a></div></div>
<div class="footer">
<span>© 2017 '.$sitetitle.'</span></div>');
?>