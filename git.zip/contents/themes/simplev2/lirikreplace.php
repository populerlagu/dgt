<?php 
$query = str_ireplace(array(
'LYRICS','hq','hd','with Lyric','lirik','VC Trinity','OFFICIAL','nagaswara','UnOfficial',
'music','video','audio','clip','official','original','youtube','live','todanan','blora','karaoke','soundtrack','ost','centini manis','LYRIC','High Quality',
'(',')','[',']','&amp;','|','.','#','quot;','ft',
'flv','-','mp4','3gp','WMV','avi','webm','mp3',
'sinetron','sctv','rcti','mnctv','antv',
'Spot Interview','mv','TERBARU','hq','hd','quality','Raja Dangdut'
),
'', $query);
// $query = preg_replace('/[^A-Za-z0-9]/','', $query);
?>