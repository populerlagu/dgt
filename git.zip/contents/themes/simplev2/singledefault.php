<?php
// highlight_string(print_r($_SERVER,true));
// echo $videoid;
$yt = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.strrev($videoid).'&key='.$apikey;
// echo $yt;
$json  = json_decode(get_contents($yt));
if(!empty($json->items)){
	$id 		= $json->items[0]->id;
	$judul		= $json->items[0]->snippet->title;
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = $json->items[0]->snippet->description;
	$channel 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= $json->items[0]->snippet->channelTitle;
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= 'https://i.ytimg.com/vi/'.$id.'/mqdefault.jpg';
	if(!empty($json->items[0]->snippet->tags)){
	$tag 		= $json->items[0]->snippet->tags;
	}

} else {
$data = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q='.urlencode(fixed($altname)).'&maxResults=1&key='.$apikey;
$json = json_decode(get_contents($data));
	if(!empty($json->items)) {
		$vidlist = array();
		foreach($json->items as $item) $vidlist[] = $item->id->videoId;
		$source2 = get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
		$json2 = json_decode($source2);
		foreach($json2->items as $k=>$item) {
			$json->items[$k]->contentDetails = $item->contentDetails;
			$json->items[$k]->statistics = $item->statistics;
		}
	}
// echo $data;
	$id 		= $json->items[0]->id->videoId;
	$judul		= $json->items[0]->snippet->title;
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = $json->items[0]->snippet->description;
	$authorid 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= $json->items[0]->snippet->channelTitle;
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= 'https://i.ytimg.com/vi/'.$id.'/mqdefault.jpg';
}

//custom 
$conf['title']	 = $judul;
$conf['author']  = $authorname;
$conf['size'] 	 = $size;
$conf['duration']= $duration;
$conf['view']    = $play;
$conf['like']    = $like;
$conf['date']    = dateYT($pub);

$conf['customSingleTitle'] = $configcustom['customSingleTitle'];
$conf['customdesc'] = $configcustom['customDes']; 
//end custom


if(blocked(fixed($judul)) || empty($json->items[0])){ 
	$title 		 = '['.$size.'] '.fixed($jsonconfig['fsinglepage']).' '.htmlspecialchars(fixed($judul)).' - '.$sitetitle;
	$description = fixed($jsonconfig['fsinglepage']).' '.htmlspecialchars(fixed($judul)).' Gratis, Lagu ini diupload oleh '.htmlspecialchars($authorname).' Pada '.dateYT($pub);
	$robot 		 = 'noindex, nofollow';
} else {
	$title 		 = htmlspecialchars(Replace($conf['customSingleTitle'])).' - '.$sitetitle;
	$hltitle 	 = Replace($conf['customSingleTitle']);
	$description = htmlspecialchars(Replace($conf['customdesc']));
	$robot 		 = $jsonconfig['singlerobot'];	
}

if(!bot()){	
	if($id && !blocked($judul)){
		$filename = "contents/data/$domain.lastdownload.dat";
			$max = 100;
			$recent[$id] = array('title' => $judul, 'durasi' => $duration, 'size' => $size,'views' => $play);
							// print_r($recent);

			$recentlawas = @json_decode(@file_get_contents($filename), true);
			if(is_array($recentlawas)) {
				$recentlawas = array_slice($recentlawas, 0, $max, true);
				$recent = $recent + $recentlawas;
				
			}
							// print_r($recent);

			file_put_contents($filename, json_encode($recent));
	} 
}
//end latest view
include 'header.php';
?>
<div class="breadcrumb-wrap" xmlns:v="http://rdf.data-vocabulary.org/#"> <ol class="breadcrumb btn-box" style="border-radius:0"> <li><span typeof="v:Breadcrumb"><a href="<?php echo $urlsite;?>" rel="v:url" property="v:title">Home</a></span></li> <li><span typeof="v:Breadcrumb"><a href="/<?php echo $authorPermalink;?>/<?php echo url_slug($authorname);?><?php echo $ext;?>" rel="v:url" property="v:title"><?php echo htmlspecialchars($authorname);?></a></span></li> <li><span property="v:title"><?php echo htmlspecialchars($judul);?></span></li> </ol> </div>
<div id="sebar_lagu_contents">
<div class="entry-body">
<div style="padding-left:0">
<h1 class="mainh1_sebar_lagu entry-title clearfix"><?php echo strtoupper(htmlspecialchars($hltitle));?></h1>
<div class="meta-lagu">
	<a class="url fn" rel="author"  href="/<?php echo $authorPermalink;?>/<?php echo url_slug($authorname);?><?php echo $ext;?>" title="posts by <?php echo $authorname;?>" rel="author"><i class="fa fa-users" aria-hidden="true"></i> <?php echo $authorname;?></a></span>
	<span class="entry-date updated"><i class="fa fa-calendar" aria-hidden="true"></i> On <?php echo dateYT($pub);?></span> 
</div>

<div class="entry-content">
<p>
<img alt="<?php echo htmlspecialchars($judul);?>" class="img-circle" src="<?php echo $image;?>" width="80" height="80" title="<?php echo htmlspecialchars($judul);?>"/>
<i><?php echo htmlspecialchars(fixed(Replace($conf['customdesc'])));?></i> Hanyalah Untuk Review, Jangan Lupa Untuk Membeli Vcd Original Di Toko Musik Terdekat di Kota Anda Sebagai bentuk penghargaan kita kepada penyanyi/pecinta lagu tersebut, dan agar mereka bisa terus berkarya.
</p>

<?php if(isset($configads['adGlobal']) && $configads['adGlobal'] =='on'){
if(!blocked(fixed($judul.' - '.$des))){?>
<p>
<?php //include 'adCode/adatas.php';?>
</p>
<?php 
} //pengaman bokep
} ?>

<p>
<table style="margin:0 auto;width:100%;"> 
<tbody>
<tr><td>Title</td><td><?php if($jsonconfig['robotsearch'] == 'index, follow'){ ?><a href="/<?php echo $searchPermalink;?>/<?php echo url_slug($judul);?><?php echo $ext;?>"><?php echo $judul;?></a><?php } else { ?><?php echo $judul;?><?php } ?></td></tr>
<tr><td>Size</td><td><?php echo $size;?></td></tr>
<tr><td>Duration</td><td><?php echo $duration;?></td></tr>
<tr><td>Views</td><td><?php echo $play;?></td></tr>
<tr><td>Type </td><td>Audio / Mpeg</td></tr>
<tr><td>Bitrate </td><td>192 KBPS</td></tr>
<tr><td>Author</td><td><?php echo htmlspecialchars($authorname);?></td></tr>
<tr><td>Source</td><td>https://www.youtube.com/watch?v=<?php echo $id;?></td></tr>
</tbody>
</table>
</p>
<p>
<?php
if(isset($jsonconfig['lyric']) && $jsonconfig['lyric'] == 'on'){
//include 'lirik.php';
} else {
 echo nl2br($des);
}
?>
</p>

<p>
<?php 
include 'safelink.php';
?>
</p>

<?php if(isset($configads['adGlobal']) && $configads['adGlobal']=='on'){ 
if(!blocked(fixed($judul.' - '.$des))){ ?>
<p>
<?php include 'adCode/adbawah.php'; //adcode bawah?>
</p>
<?php }
} ?>
<p>
<strong>Tags: </strong> <?php if(!empty($tag)){ echo join(', ', $tag); } else { echo 'Download, Mp3 vide, flv, 3GP, mp4';}?> 
</p>

<p>
<div id="share-button-templatoid">
<p>Share on:</p>
<a class="facebook" href="http://www.facebook.com/sharer.php?u=<?php echo urlencode($fullpatch);?>&amp;title=<?php echo urlencode($title);?>" rel="nofollow" style="background:#3b5998;" target="_blank" title="Facebook"><i class="fa fa-facebook"></i> Facebook</a>
<a class="facebook" href="https://plus.google.com/share?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#c0361a;" target="_blank" title="Google+"><i class="fa fa-google-plus"></i> Google+</a>
<a class="twitter" href="https://twitter.com/intent/tweet?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#4099ff;" target="_blank" title="Twitter"><i class="fa fa-twitter"></i> Twitter</a>
<div class="clear"></div>
</div>
</p>

<div id="related">
	<?php include 'related.php';?>
</div>
</div><?php //end entry content ?>
</div>
<div style="padding:0">
<?php include 'sidebar.php';?>

</div>
<div style="clear:both"></div>

</div>

</div>

<?php include 'footer.php';?>