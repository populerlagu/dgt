<?php 
include '../setting.php';
include '../token.php';
$page = isset($terme[0]) ? $terme[0] : 1;
$source ='https://www.googleapis.com/youtube/v3/search?part=snippet&q='.$match[1].'&maxResults=2&key='.$apikey;
$json = json_decode(get_contents($source));
$channelid = str_ireplace('UC','UU', $json->items[0]->snippet->channelId);
//about
$about = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=snippet&id='.$json->items[0]->snippet->channelId.'&key='.$apikey));

//2nd process
if(!empty($term[0])){
$_GET['page'] = $pageToken[$_GET['page']];
	$json = json_decode(get_contents('https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=10&playlistId='.$channelid.'&pageToken='.$_GET['page'].'&key='.$apikey));
} else {
	$json = json_decode(get_contents('https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=10&playlistId='.$channelid.'&key='.$apikey));
}
if(!empty($json->items)) {
	$vidlist = array();
	foreach($json->items as $item) $vidlist[] = $item->snippet->resourceId->videoId;
	$source2 = get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
	$json2 = json_decode($source2);
	foreach($json2->items as $k=>$item) {
		$json->items[$k]->contentDetails = $item->contentDetails;
		$json->items[$k]->statistics = $item->statistics;
	}
}

//custom 
$conf['title']	 = $judul;
$conf['author']  = $match[1];
$conf['size'] 	 = $size;
$conf['duration']= $duration;
$conf['view']    = $play;
$conf['like']    = $like;
$conf['date']    = dateYT($pub);

$conf['customAuthorTitle'] = Replace($configcustom['customAuthorTitle']); 
$conf['customAuthor'] = Replace($configcustom['customAuthor']); 
//end custom
// print_r($_GET);
if($term[0] > 1) {
	$title = fixed($conf['customAuthorTitle']).' - Page '.$page.' - '.$sitetitle;
} else {
	$title = fixed($conf['customAuthorTitle']).' - '.$sitetitle;

}
if($about->items[0]->snippet->description){
	$description = preg_replace('/[^A-Za-z0-9]/', ' ', $about->items[0]->snippet->description);
	$description = htmlspecialchars(substr($description,0,147)).'...';
} else {
	$description = $conf['customAuthor'];
}

$robot = 'noindex, follow';
$imgog = $about->items[0]->snippet->thumbnails->medium->url;
include 'header.php';
?>
<div id="sebar_lagu_contents">
<div class="main">
<h1 class="mainh1_sebar_lagu"><?php echo $title;?></h1>
<div class="info" style="text-align:left;margin:0;padding:0 0 10px 0">
<img src="<?php echo $about->items[0]->snippet->thumbnails->default->url;?>" alt="<?php echo $title;?>" style="float:left;margin:0 10px 0 0"/>
<?php if($about->items[0]->snippet->description){ ?>
	<?php echo nl2br(str_ireplace('=','', ucwords(strtolower($about->items[0]->snippet->description))));?>
<?php } else {
	echo 'Di bawah ini merupakan List Video Lagu Mp3 yang diungahh oleh '.fixed($_GET['author']);
}?>
<div id="share-button-templatoid">
<p>Share on:</p>
<a class="facebook" href="http://www.facebook.com/sharer.php?u=<?php echo urlencode($fullpatch);?>&amp;title=<?php echo urlencode($title);?>" rel="nofollow" style="background:#3b5998;" target="_blank" title="Facebook"><i class="fa fa-facebook"></i> Facebook</a>
<a class="facebook" href="https://plus.google.com/share?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#c0361a;" target="_blank" title="Google+"><i class="fa fa-google-plus"></i> Google+</a>
<a class="twitter" href="https://twitter.com/intent/tweet?url=<?php echo urlencode($fullpatch);?>&text=<?php echo urlencode($title);?>" rel="nofollow" style="background:#4099ff;" target="_blank" title="Twitter"><i class="fa fa-twitter"></i> Twitter</a>
<div class="clear"></div>
</div>
<div style="clear:both"></div>

</div> 
<div style="clear:both"></div>
<?php 
if(!empty($json->items)){
	foreach ($json->items as $key => $value) {
		$judul = $value->snippet->title;
		$videoid = strrev($value->snippet->resourceId->videoId);
		$size = size($value->contentDetails->duration);
		$duration = durationYT($value->contentDetails->duration);
		$tanggal 	= $value->snippet->publishedAt;
		$image 		= 'https://i.ytimg.com/vi/'.$value->snippet->resourceId->videoId.'/default.jpg';

	?>
	
<article class="box-post"> 
<div class="entry"><img width="100" src="<?php echo $image;?>" height="80" alt="<?php echo htmlspecialchars($judul);?>" title="<?php echo htmlspecialchars($judul);?>" class="thumbs img-circle"> 
<h2 class="roolitems"><i class="fa fa-music" aria-hidden="true"></i> 
<a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>"><?php echo htmlspecialchars($judul);?></a>
</h2> 
<p style="margin:0 10px 0 0"><i class="fa fa-hdd-o" aria-hidden="true"></i> Size: <?php echo $size;?> <i class="fa fa-clock-o" aria-hidden="true"></i> Duration: <?php echo $duration;?></p> 
<p style="margin:0 10px 0 0"><i class="fa fa-calendar" aria-hidden="true"></i> Diupload: <?php echo dateYT($tanggal);?></p> 
<div class="details"><a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>">
<button class="btn-sm btn-default pull-right hide" ><i class="fa fa-arrow-circle-o-down black"></i> View Detail</button></a> <div style="clear:both"></div> </div></div> 
</article>				
<?php 	}
}
?>

</section>
<div style="clear:both"></div>
</div><!-- end main -->
</div><!--end sebar lagu contents-->
<?php 
include 'footer.php';