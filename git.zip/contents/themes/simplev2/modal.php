<div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Download Mp3 &amp Video <?php echo $judul;?></h4>
        </div>
        <div class="modal-body">
		<p>
		<strong>WARNING:</strong> Lagu Mp3 / Video dengan Judul <strong><?php echo $judul;?></strong> bisa saja memiliki hak cipta !!! Kami di sini hanya menggunakan layanan api resmi dari youtube (https://developers.google.com/youtube/), Jika Anda merupakan produser / management artis yang bersangkutan dan jika lagu ini telah melanggar dari hak cipta saudara, anda bisa menghubungi author youtube yang bersangkutan di sini => <a rel="nofollow" target="_blank" href="//www.youtube.com/channel/<?php echo $channel;?>"><?php echo strtoupper($authorname);?> ON YOUTUBE</a>
		</p>
          <p style="text-align:center">
			<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>http://www.youtubeinmp3.com/download/?video=https://youtu.be/<?php echo $id;?>');><button class="dmp3"><i class="fa fa-arrow-circle-o-down"></i> Download Mp3</button></a>
			<a href="javascript:void(0);" onclick=window.open('/<?php echo $streamPermalink;?>/<?php echo url_slug($judul);?>.<?php echo strrev($id);?><?php echo $ext;?>');><button class="dplay"><i class="fa fa-play"></i> Play Video</button></a>
			<a rel="nofollow" href="javascript:void(0);"  onclick=window.open('<?php echo $safe;?>http://keepvid.com/?url=https%3A%2F%2Fyoutu.be%2F<?php echo $id;?>');><button class="dmp4"><i class="fa fa-arrow-circle-o-down"></i> Download Video</button></a><br />
			<small>Link Download Provided By www.youtubeinmp3.com &amp; www.keepvid.com</small>		

		  </p>
        </div>
</div>
