<?php if(isset($_SESSION["username"])){ ?>
<h3 class="mainh1_sebar_lagu" style="border-bottom:3px solid #ddd">Dashbord</h3>
<?php 
$sid = array(
	'/Aamiin/'  => 'Admin',
	'/tugas.php'  => 'Tugas',
	'/suntik/' => 'Suntik Keyword',
	'/gas.php'  => 'Bat Generator',
	'/on.php'   => 'View Online User',
	'/myweb.php'=> 'List Web Member',
	'/themes/edit.php?file=minify.css&theme='.$configcustom['themes'] => 'Theme Editor <span style="color:red">(Vip Member)</span>',
	'/Aamiin/logout.php?return='.urlencode($fullpatch) => 'logout',
);
		foreach($sid as $k => $v){ ?>
			<div class="box-post" style="margin:0">
			 <span class="glyphicon glyphicon-ok" style="color:#969696"></span> <a target="_blank" rel="nofollow" href="<?php echo $k;?>" title="Home"><?php echo $v;?></a>
			</div>
		<?php } ?>

<?php } ?>
<?php 
if($jsonconfig['latestDownload'] == 'on'){
	include 'zlatest.php';
}

if($jsonconfig['popular'] == 'on'){
	// include 'populer.php';
}
if($jsonconfig['robotsearch']){
	include 'zlatestsearch.php';
}