<?php 
	$related = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&relatedToVideoId='.$id.'&maxResults=9&key='.$apikey;
		$jsonR 	 = json_decode(file_get_contents($related)); 
			if(!empty($jsonR->items)) {
				$vidlist = array();
				foreach($jsonR->items as $item) $vidlist[] = $item->id->videoId;
				$sing2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
				$json2 = json_decode($sing2);
				foreach($json2->items as $k=>$item) {
					$jsonR->items[$k]->contentDetails = $item->contentDetails;
					$jsonR->items[$k]->statistics = $item->statistics;
				}
			}

if(!empty($jsonR->items)){ ?>
<h4 class="title">
			<span>Related Songs</span>
		</h4>
		<?php foreach($jsonR->items as $values) {
			// highlight_string(print_r($jsonR, true));
		?>
			<article id="post" class="post-excerpt">
			<div class="box-image">
			<img src="https://i.ytimg.com/vi/<?php echo $values->id->videoId;?>/default.jpg" alt="<?php echo $value->snippet->title;?>" title="<?php echo $value->snippet->title;?>">
			</div>
			<div class="box-data">
			<div class="data-label">
			<span><?php echo $values->snippet->publishedAt;?></span>
			</div>
			<a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($values->snippet->title);?>.<?php echo $value->id->videoId;?><?php echo $ext;?>">
			<h4 class="data-title">
				<?php echo $values->snippet->title;?>
			</h4>
			</a>
			<span onclick="location.href='/<?php echo ($singlePermalink);?>/<?php echo url_slug($values->snippet->title);?>.<?php echo $value->id->videoId;?><?php echo $ext;?>#download';" style="color:green;cursor:pointer">
			<i class="fa fa-download"></i> Download
			</span>
			</div>
			</article>
		<?php } 
		
} ?>		
</div>