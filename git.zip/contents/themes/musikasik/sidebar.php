    <div class="widget popular-widget">
        <h4 class="title">
            <span>Last Search</span>
        </h4>
        <ol class="widget-list">
        	            	<li><a href="/kabur-kanginan/q.html?ref=sidebar"><i> </i>Kabur Kanginan</a></li>
                        	<li><a href="/payung-teduh-akad/q.html?ref=sidebar"><i> </i>Payung Teduh Akad</a></li>
                        	<li><a href="/despacito/q.html?ref=sidebar"><i> </i>Despacito</a></li>
                    </ol>
    </div>
	
    <div class="widget lastview-widget clearfix">
        <h4 class="title">
            <span>Last View</span>
        </h4>
        <div class="row">
				<?php 
				$data = fopen("contents/data/$domain.lastdownload.dat","r");
				$json = json_decode(fgets($data), true);
				if(!empty($json)){
				foreach(array_slice($json, 1, $jsonconfig['maxrecent']) as $k => $v){
				$judul = $v['title'];
				$durasi = $v['durasi'];
				$size 	= $v['size'];
				$views 	= $v['views'];
				$videoid = strrev($k);
				?>
			<div class="col-xs-6 col-sm-6 col-md-6">
                <article class="post-widget">
                    <a class="widget-image" onclick="location.href='';">
                        <div class="image-here">
                        	<div align="center">
                            	<img src="https://i.ytimg.com/vi/<?php echo $k;?>/default.jpg">
                            </div>
                        </div>
                    </a>
                    <div class="post-widget-data">
                        <a href="/<?php echo $singlePermalink;?>/<?php echo url_slug($values->snippet->title);?>.<?php echo $value->id->videoId;?><?php echo $ext;?>?ref=sidebar">
                            <p><?php echo $judul;?></p>
                        </a>
                    </div>
                </article>
            </div>
			 <?php } 
				}?>
                            
        </div>
    </div>