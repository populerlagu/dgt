<?php
$yt = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.strrev($videoid).'&key='.$apikey;
$json  = json_decode(get_contents($yt));
if(!empty($json->items)){
	$id 		= $json->items[0]->id;
	$judul		= $json->items[0]->snippet->title;
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = $json->items[0]->snippet->description;
	$channel 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= $json->items[0]->snippet->channelTitle;
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= 'https://i.ytimg.com/vi/'.$id.'/mqdefault.jpg';
	$tag 		= $json->items[0]->snippet->tags;
	// print_r($tag);
} else {
$data = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q='.urlencode(fixed($altname)).'&maxResults=1&key='.$apikey;
$json = json_decode(get_contents($data));
	if(!empty($json->items)) {
		$vidlist = array();
		foreach($json->items as $item) $vidlist[] = $item->id->videoId;
		$source2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
		$json2 = json_decode($source2);
		foreach($json2->items as $k=>$item) {
			$json->items[$k]->contentDetails = $item->contentDetails;
			$json->items[$k]->statistics = $item->statistics;
		}
	}
	
// echo $data;
	$id 		= $json->items[0]->id->videoId;
	$judul		= $json->items[0]->snippet->title;
	$pub 		= $json->items[0]->snippet->publishedAt;
	$des        = $json->items[0]->snippet->description;
	$authorid 	= $json->items[0]->snippet->channelId;
	$duration	= durationYT($json->items[0]->contentDetails->duration);
	$size 		= size($json->items[0]->contentDetails->duration);
	$authorname	= $json->items[0]->snippet->channelTitle;
	$like 		= $json->items[0]->statistics->likeCount;
	$play 		= $json->items[0]->statistics->viewCount;
	$image 		= 'https://i.ytimg.com/vi/'.$id.'/hqdefault.jpg';
}

// echo $id;
//custom 
$conf['title']	 = $judul;
$conf['author']  = $authorname;
$conf['size'] 	 = $size;
$conf['duration']= $duration;
$conf['view']    = $play;
$conf['like']    = $like;
$conf['date']    = dateYT($pub);

$conf['customSingleTitle'] = $configcustom['customSingleTitle'];
$conf['customdesc'] = $configcustom['customDes']; 
//end custom


if(blocked(fixed($judul)) || empty($json->items[0])){ 
	$title 		 = '['.$size.'] '.htmlspecialchars(fixed($judul)).' - '.$sitetitle;
	$description = fixed($jsonconfig['fsinglepage']).' '.htmlspecialchars(fixed($judul)).' Gratis, Lagu ini diupload oleh '.htmlspecialchars($authorname).' Pada '.dateYT($pub);
	$robot 		 = 'noindex, nofollow';
} else {
	$title 		 = htmlspecialchars(Replace($conf['customSingleTitle'])).' - '.$sitetitle;
	$description = htmlspecialchars(Replace($conf['customdesc']));
	$robot 		 = $jsonconfig['singlerobot'];	
}

if(!bot()){	
	if(isset($id) && !blocked($judul)){
		$filename = "contents/data/$domain.lastdownload.dat";
			$max = 100;
			$recent[$id] = array('title' => $judul, 'durasi' => $duration, 'size' => $size,'views' => $play);
							// print_r($recent);

			$recentlawas = @json_decode(@file_get_contents($filename), true);
			if(is_array($recentlawas)) {
				$recentlawas = array_slice($recentlawas, 0, $max, true);
				$recent = $recent + $recentlawas;
				
			}
							// print_r($recent);

			file_put_contents($filename, json_encode($recent));
	} 
}
//end latest view
include 'header.php';
?>
		<div class="grid">
				<div class="column content-area">
					<ol class="breadcrumb">
						<li><a href="<?php echo $urlsite;?>/">Home</a></li>
						<li class="active"><?php echo htmlspecialchars($judul);?></li>
					</ol>
					<article class="single-post">
						<div class="single-head">
							<div class="head-meta">
								<span><?php echo $authorname;?></span>
								<span><?php echo dateYT($pub);?></span>
								<span class="align-right"><a href="#download"><i class="fa fa-download"></i></a></span>
							</div>
							<h1><?php echo strtoupper(htmlspecialchars($judul));?></h1>
						</div>
							
						<div class="single-body" id="artikel">
						<div id="player">
							<img class="img-responsive " src="http://i.ytimg.com/vi/<?php echo $id;?>/hqdefault.jpg" alt="<?php echo htmlspecialchars($judul);?>" title="<?php echo htmlspecialchars($judul);?>" style="width:100%"/>
						</div>
						
						<h3>Description</h3>
						<p>
							<?php echo nl2br($des);?>
						</p>
						
						<table class="table table-striped">
							<tbody>
								<tr>
									<td><i class="fa fa-tag"></i> Title</td>
									<td><?php echo $judul;?></td>
								</tr>
								<tr>
									<td><i class="fa fa-user"></i> Author</td>
									<td><?php echo $authorname;?></td>
								</tr>
								<tr>
									<td><i class="fa fa-book"></i> Albume</td>
									<td><?php echo $judul;?> - Single</td>
								</tr>
								<tr>
									<td><i class="fa fa-calendar"></i> Year</td>
									<td>2017</td>
								</tr>
								<tr>
									<td><i class="fa fa-inbox"></i> Size</td>
									<td>4.7 MB</td>
								</tr>
								<tr>
									<td><i class="fa fa-tachometer"></i> Duration</td>
									<td>04:42</td>
								</tr>
								<tr>
									<td><i class="fa fa-download"></i> Download</td>
									<td>3,788.6M</td>
								</tr>
							</tbody>
							</table>
					        <br>
								<div class="align-center" id="download">
									<span><a href="#artikel" onClick="playmp3()" class="btn btn-success">Listen</a></span>
									<span><a href="#artikel" onClick="playmv()" class="btn btn-success">View MV</a></span>
									<span><a href="" class="btn btn-success" rel="nofollow">Download Here</a></span>
								</div>
								
								<blockquote>
								All images, musics and videos copyright are belong to their respective owners. We just put embed contents from Youtube.com and do not host any content in our server. This content may be protected by copyright law or other laws regarding intellectual property of the United States or other countries. Downloading Dua Lipa - New Rules (Official Music Video) music/video on this site is just for review purpose. If you love the song, please support the artists by buying the original CD/Cassette or buying the song from iTunes.
								</blockquote>
						</div>	
						<div class="single-share">
							<ul>
								<li><a href="http://www.facebook.com/sharer.php?u=http://musicasik.tk/luis-fonsi-despacito-ft-daddy-yankee/282/p.html" target="_blank" title="Share this on Facebook" class="btn facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://twitter.com/share?url=http://musicasik.tk/luis-fonsi-despacito-ft-daddy-yankee/282/p.html&amp;text=<?php echo $judul;?>&amp;hashtags=musicasik.tk" target="_blank" title="Share this on Twitter" class="btn twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://plus.google.com/share?url=http://musicasik.tk/luis-fonsi-despacito-ft-daddy-yankee/282/p.html" target="_blank" title="Share this on Google Plus" class="btn google"><i class="fa fa-google"></i></a></li>
							</ul>
						</div>						
					</article>
					<?php include 'related.php'; ?>
					
				</div>
				
<script>
<?php include 'yt.js'; ?>

function playmp3(){
	$('#player').html('<div data-type="youtube" data-video-id="<?php echo $id;?>" data-view="mp3" id="ytmp3"></div>');
	$('.single-body').css('padding-top','70px');
	plyr.setup({ autoplay: true });
}
function playmv(){
	$('#player').html('<div data-type="youtube" data-video-id="<?php echo $id;?>" data-view="video" ></div>');
	$('.single-body').css('padding-top','10px');
	plyr.setup({ autoplay: true });
}
</script>
				
				<div class="column widget-area">

					<?php include 'sidebar.php';?>

				</div>
		</div>
		<?php include 'footer.php';?>
