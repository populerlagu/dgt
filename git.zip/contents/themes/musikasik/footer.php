			</main>
        </div>
    </div>
<!-- End Page Content -->
            <!-- Start Page Bottom -->
            <div class="page-bottom">
                <div class="main-container">
                    <footer class="footer">
                        <div class="row">
                            <div class="col-xs-12 col-md-6">
                                <h3>Disclaimer</h3>
                                <p>
                                    All images, musics and videos copyright are belong to their respective owners. We just put embed contents from Youtube.com and do not host any content in our server. These content(s) may be protected by copyright law or other laws regarding intellectual property of the United States or other countries. Downloading file(s) on this site is just for review purpose. If you love the song, please support the artists by buying the original CD/Cassette or buying the song from iTunes.
                                </p>
                            </div>
                            <div class="col-xs-12 col-md-6 footer-right">
                                <h3><?php echo $urlsite;?></h3>
                                <ul class="copyright-list">
                                    <li><a href="mailto:admin@<?php echo $urlsite;?>">admin@<?php echo $urlsite;?></a></li>
                                    <li><a href="/privacy.html">Privacy police</a></li>
                                    <li><a href="/dmca.html">DCMA Copyright</a></li>
                                    <li><a href="/">Sitemap</a></li>
                                    <li><a href="/feed.xml"><i class="fa fa-rss"></i> Feed</a></li>
                                </ul>
                                <p>
                                    &copy; 2017 <?php echo $urlsite;?>
                                </p>
								<!-- Start of StatCounter Code for Dreamweaver -->
								
                                <!-- End of StatCounter Code for Dreamweaver -->

                                
                                                            </div>
                        </div>
                    </footer>
                </div>
            </div>
            <!-- End Page Bottom -->

    	</div>
        
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body>
</html>