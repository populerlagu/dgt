<?php 
include 'function/token.php'; 
$page = isset($match[1]) ? $match[1] : 1;
if($homedisplay == 'playlist'){
	$playid = isset($playlistid) ? $playlistid : 'PLcgx1G1K3NpigvqGIbb0E_ZHSxIzVPfz4';	
	if(!empty($match[1])){
	$_GET['page'] = $pageToken[$match[1]];
		$data ='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId='.$playid.'&pageToken='.$_GET['page'].'&maxResults=10&key='.$apikey;
	} else {
		$data ='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId='.$playid.'&maxResults=10&key='.$apikey;
	}

} elseif($homedisplay == 'search') {
	$term = isset($searchterm) ? $searchterm : 'ungu';
	if(!empty($match[1])){
	$_GET['page'] = $pageToken[$match[1]];
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&order=date&pageToken='.$_GET['page'].'&maxResults=10&key='.$apikey;
	} else {
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&order=date&maxResults=10&key='.$apikey;
	} 
	// echo $data;
} else {
	// Do Something Here :v wkwkwkkwkwkwk
}
$json = json_decode(get_contents($data));

if(!empty($json->items)) {
	$vidlist = array();
	foreach($json->items as $item){
		if($homedisplay == 'playlist'){
			$idr = $item->snippet->resourceId->videoId;
		} elseif($homedisplay == 'search') {
			$idr = $item->id->videoId;
		}
		$vidlist[] = $idr;
		}
	$source2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id='.join(',', $vidlist).'&key='.$apikey);
	$json2 = json_decode($source2);
	foreach($json2->items as $k=>$item) {
		$json->items[$k]->contentDetails = $item->contentDetails;
		$json->items[$k]->statistics = $item->statistics;
	}
}
// echo $data;
if($page > 1){
	$title 		 = $sitetitle.' - Page #'.$page.' - '.$tagsite ;
} else {
	$title 		 = $sitetitle.' - '.$tagsite ;
	$description = $jsonconfig['description'];
	$robot 		 = 'index, follow';
}
include 'header.php';
?>
		<div class="grid">
				<div class="column content-area">
				<?php 
				if(!empty($json->items)){
				foreach($json->items as $k => $v){
				$judul  	= $v->snippet->title;
				if($homedisplay == 'playlist'){
				$videoid 	= strrev($v->snippet->resourceId->videoId);
				$vid		= $v->snippet->resourceId->videoId;
				} elseif($homedisplay == 'search'){
				$videoid 	= strrev($v->id->videoId);
				$vid 		= $v->id->videoId;
				}
				$tanggal 	= $v->snippet->publishedAt;
				$author 	= $v->snippet->channelTitle;
				$duration 	= durationYT($v->contentDetails->duration);
				$size 	 	= size($v->contentDetails->duration);
				$views 		= $v->statistics->viewCount;
				$image 		= 'https://i.ytimg.com/vi/'.$vid.'/default.jpg';
				// $play = 'https://www.youtube.com/embed/'.$videoid;
					if($judul !='Private video' && $judul !='Deleted video' && $duration !='00:00'){
					?>
							<article id="post" class="post-excerpt">
								<div class="box-image">
									 <img src="<?php echo $image;?>" alt="<?php echo $judul;?>" title="<?php echo $judul;?>">
								</div>
								<div class="box-data">
									<div class="data-label">
										<span><?php echo $author;?></span>
										<span><?php echo $tanggal;?></span>
									</div>
									<a href="/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>">
										<h4 class="data-title">
											<?php echo $judul;?>
										</h4>
									</a>
									
									<span onclick="location.href='/<?php echo ($singlePermalink);?>/<?php echo url_slug($judul);?>.<?php echo $videoid;?><?php echo $ext;?>#download';" style="color:green;cursor:pointer">
										<i class="fa fa-download"></i> Download
									</span>                                
								</div><div class="cboth"></div>
							</article>
							
					<?php } 
				
					}

				} ?>

                     <ul class="pagination"><li class="active"><span class="page-numbers current">1</span></li><li><a class="page-numbers" href="/page/2.html">2</a></li><li><a class="page-numbers" href="/page/3.html">3</a></li><li><a class="next page-numbers" href="/page/2.html">></a></li></ul>
					 
				 </div>
				 
				<div class="column widget-area">

					<?php include 'sidebar.php';?>

				</div>
				
		</div>
		
		
<?php include 'footer.php';?>
				 
				 
			
			
		