<!doctype html>
<html class="no-js" lang="en-US">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo $title;?></title>
        <meta name="description" content="download mp3 new release and populer music video">
        <meta name="keywords" content="download mp3,new release,populer music video,mp3,video,2017,free download">
        <meta name="author" content="<?php echo $sitetitle;?>">
        <meta name="robots" content="index, follow">
        <meta name="viewport" content="width=device-width, initial-scale=1">
                <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=PT+Sans">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		<style>
			<?php 
			if(isset($configcss['css']) && $configcss['css'] !=''){
			echo $css;
			} else {
			include 'minify.css'; 
			}
			?>
		</style>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    </head>
    <body>
	<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    	<div id="page" class="home-site">    		
            <!-- Start Page Top -->
    		<div class="page-top">

                <!-- Start Mobile Nav --> 
                <div class="mobile-wrapper">
                    <nav class="navbar navbar-default">
                        <div class="main-container">

                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                              <a class="navbar-brand" href="#"><?php echo $sitetitle;?></a>
                            </div>

                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                   
                                </ul>
                            </div>

                        </div>
                    </nav>
                    <div class="main-container">
                        <div class="mobile-search">
                            <form method="post">
                                <div class="form-group">
                                    <input type="text" name="q" class="form-control" placeholder="Search Artist, Songs, Album or etc">
                                    <button type="submit" class="btn black"><i class="fa fa-search"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Mobile Nav -->
                
    			<nav class="nav-menu clearfix">
    				<div class="main-container">
    					<div class="nav-header">
                        	<a href="/" class="brand">
                            	<!-- <img src="" alt=""> -->
                            	<?php echo $sitetitle;?>
                        	</a>
                    	</div>
                        <div class="nav-form">
                            <form class="navbar-right" method="post" id="frmSearch">
                                <input type="text" name="q" placeholder="Search Artist, Songs, Album or etc" class="searh-form">
                                <a href="javascript:document.getElementById('frmSearch').submit();" class="search-icon"><i class="fa fa-search"></i></a>
                            </form>
                        </div>
    				</div>
    			</nav>
                <div class="sub-menu clearfix">
                    <div class="main-container sub-nav">
                        <ul class="sub-nav-list">
                            
                        </ul>
                    </div>
                </div>
    		</div>
            <!-- End Page Top -->
			 <link rel="stylesheet" href="/contents/themes/musikasik/yt.css">          
			<!-- Start Page Content -->
			<div class="page-content">
				<div class="main-container">
					<main id="main" class="main-content clearfix">