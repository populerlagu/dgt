<?php 
include 'setting.php';
$api = $_GET['api'];
$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=ungu&maxResults=2&key='.$api;
$json = json_decode(get_contents($data));
?>
<h3><?php echo $json->title;?></h3>
<?php 
if(!empty($json->items)){ ?>
<h1>API IS OK</h1>	
		
	<?php } else { ?>
<h1>"UNAUTHENTICATED"</h1>
<?php }

echo (__DIR__ ).'<br>'; 
echo (__DIR__ ).'/config/'.$domain.'.config.json'; 





?>