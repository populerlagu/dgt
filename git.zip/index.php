<?php
require 'setting.php';
if(isset($_GET['cari'])){
	if(!empty($_GET['cari'])){
		if(preg_match('/https?:\/\/(?:www\.)?youtu(?:\.be|be\.com)\/watch(?:\?(.*?)&|\?)v=([a-zA-Z0-9_\-]+)(\S*)/i', $_GET['cari'], $match)) {
			$videoid = $match[2];
			$yt = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.($videoid).'&key='.$apikey));
				header('Location: '.$urlsite.'/'.$singlePermalink.'/'.url_slug($yt->items[0]->snippet->title).'.'.strrev($videoid).$ext);
				exit;

		} elseif(preg_match('/https?:\/\/(?:www\.)?youtu(?:\.be|be\.com)\/([a-zA-Z0-9_\-]+)(\S*)/i', $_GET['cari'], $match)) {
			$videoid = $match[1];
			$yt = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.($videoid).'&key='.$apikey));
				header('Location: '.$urlsite.'/'.$singlePermalink.'/'.url_slug($yt->items[0]->snippet->title).'.'.strrev($videoid).$ext);
				exit;
		} elseif($_GET['cari']){
			header('Location: /'.$searchPermalink.'/'.url_slug($_GET['cari']).$ext.'');
				exit;
		} 	
	} else { ?>
	<script>
		alert('Masukno Keyword Coeg :d');
		location.href='/';
	</script>
	<?php }
} 

$clean_url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if($clean_url == '/' || $clean_url == 'index.php') { 	//start tampilkan home
	$act = 'home';
	if(!empty($sitetitle)){
	include 'contents/themes/'.$theme.'/home.php';
	} else {
		if(isset($domain) && $domain == $_SERVER['SERVER_ADDR'] || $domain == '1for1.us'){
			header('Location: https://www.facebook.com/profile');
		} else {
			die('Please Configure Your Website First => <a href="/Aamiin/login.php">Goto Config Webpage Now</a>');
		}
	}

} elseif (preg_match('#^/page/(.*)'.$ext.'$#', $clean_url, $match)) { // untuk home paging
	$act = 'homepage';
	include 'contents/themes/'.$theme.'/home.php';
} elseif (preg_match('#^/'.$searchPermalink.'/(.*)'.$ext.'$#', $clean_url, $match)) { //untuk pencarian
	$act = 'search';
	$terme = explode('/', $match[1]);
	$searchresult = end($terme);
	include 'contents/themes/'.$theme.'/items.php';
} elseif (preg_match('#^/'.$singlePermalink.'/(.*)'.$ext.'$#', $clean_url, $match)) { 	//start tampilkan single page
	$act = 'Single Page';
	$single = $match[1];
	$datavid= explode('.', $single);
	$videoid= $datavid[1];
	$altname= $datavid[0];
	include 'contents/themes/'.$theme.'/singledefault.php';
} elseif (preg_match('#^/'.$streamPermalink.'/(.*)'.$ext.'$#', $clean_url, $match)) { 	//start tampilkan paly streaming
	$act = 'Streaming';
	$single = $match[1];
	$datavid= explode('.', $single);
	$videoid= $datavid[1];
	$altname= $datavid[0];
	include 'contents/themes/'.$theme.'/play.php';	
}  elseif (preg_match('#^/'.$topmenu.'/(.*)'.$ext.'$#', $clean_url, $match)) { 	//start tampilkan channel author
	$act = 'topmenu';
	$terme = explode('/', $match[1]);
	$menuterm = end($terme);
	$pagemenu = $terme[0];
	include 'contents/themes/'.$theme.'/menus.php';	
	
} elseif (preg_match('#^/'.$authorPermalink.'/(.*)'.$ext.'$#', $clean_url, $match)) { 	//start tampilkan channel author
	$act = 'author chanel';
	$authorn = $match[1];
	include 'contents/themes/'.$theme.'/channel.php';
}  elseif (preg_match('#^/pages/(.*)'.$ext.'$#', $clean_url, $match)) { 	//start tampilkan channel author
	$act = 'copyright';
	include 'contents/themes/'.$theme.'/copyright.php';
} else {
	header('Location: '.$urlsite);
	exit;
}

//startDEBUG
if(isset($_GET['print']) && $_GET['print'] =='1'){ // DEBUG FUNCTION
echo '<h1>'.$act.'</h1>';
?>
$configads <br>
<?php highlight_string(print_r($configads,true)); ?><hr>
$configcustom <br>
<?php highlight_string(print_r($configcustom,true)); ?><hr>
$jsonconfig <br>
<?php highlight_string(print_r($jsonconfig,true)); ?><hr>
$json <br>
<?php highlight_string(print_r($json->items, true)); 
} elseif(isset($_GET['debug']) && $_GET['debug'] == '1'){

highlight_string(print_r($configcss,true));
highlight_string(print_r($configads,true));
highlight_string(print_r($configcustom,true));
highlight_string(print_r($jsonconfig,true));

} elseif(isset($_GET['server'])){
	highlight_string(print_r($_SERVER, true));
}

?>