<?php 
if(isset($configads['adsense']) && $configads['adsense'] =='on'){
	if($configads['adresponsive'] == 'on' && $configads['adreactor'] !='on'){ ?>
		<div class="banner">
			<?php echo $configads['adsResponsiveCode'];?>
		</div>
		<?php } else { // end responsive ?>
		<div class="banner">
			<?php 
			if(isMobile()){
				echo $configads['adsMobileCode'];
			} else {
				echo $configads['adsDesktopCode'];
			} ?>
		</div>
<?php }

} elseif($configads['adreactor'] =='on' && $configads['adsense']  == ''){ //adsense wajib off ?>
	<?php 
	if(!bot()){
		if(isMobile()){
			echo $configads['adr1HpCode'];
		} else {
			echo $configads['adr1pcCode'];
		} 
	} ?>
<?php } ?>