<?php 
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$b = time();
$jam = date("G", time());

$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
if(is_file((__DIR__ ).'/config/'.$domain.'.config.json')){
	$config 	= (__DIR__ ).'/config/'.$domain.'.config.json';
	$jsonconfig = json_decode(file_get_contents($config),true);
}

// print_r($jsonconfig);
if(is_file("config/$domain.configads.json")){
	$configs 	= fopen("config/$domain.configads.json","r");
	$configads  = json_decode(fgets($configs), true);
}

if(is_file("config/$domain.custom.json")){
	$customdata 	= fopen("config/$domain.custom.json","r");
	$configcustom  = json_decode(fgets($customdata), true);
} 

if(is_file("config/$domain.customcss.json")){
	$customcss 	= fopen("config/$domain.customcss.json","r");
	$configcss  = json_decode(fgets($customcss), true);
}

// echo $configs;
function get_contents($url) {
	if(function_exists('curl_exec')) {
		$header[0] = "Accept-Language: en";
		$header[] = "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3";
		$header[] = "Pragma: no-cache";
		$header[] = "Cache-Control: no-cache";
		$header[] = "Accept-Encoding: gzip,deflate";
		$header[] = "Content-Encoding: gzip";
		$header[] = "Content-Encoding: deflate";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		// curl_setopt($ch, CURLOPT_REFERER, "https://www.youtube.com");
		$data = curl_exec($ch);
		curl_close($ch);
	}
	else {
		$data = @file_get_contents($url);
	}
	return $data;
}

function asd($content,$start,$end){
  if($content && $start && $end) {
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $r[0];
    }
    return '';
  }
}
function fixed($str){
	$str = ucwords(strtolower(rawurldecode(str_replace('-',' ', $str))));
	$str = str_ireplace('_',' ', $str);
	$str = str_ireplace('~',' ', $str);
	// $str = ucwords(strtolwer($str));
	return $str;	
}

function durationYT($str) {
	preg_match('#PT(([0-9]{1,2})H)?(([0-9]{1,2})M)?(([0-9]{1,2})S)?#i', $str, $match);
	return join(':', array_filter(array((isset($match[2])?$match[2]:null), substr('00'.(isset($match[4])?$match[4]:''), -2), substr('00'.(isset($match[6])?$match[6]:''), -2))));
}

function nganu($match) {  
    Global $conf;
    if(isset($conf[$match[1]])) return $conf[$match[1]];
    else return $match[0]; //string asli: %title%
} 

function Replace($str) {
    return    preg_replace_callback('/%([a-z]+)%/s', 'nganu', $str); 
}

function size($str) {
	preg_match('#PT(([0-9]{1,2})H)?(([0-9]{1,2})M)?(([0-9]{1,2})S)?#i', $str, $match);
	$byte['s'] = 1024*1024*(isset($match[6])?(int)$match[6]:0)/60;
	$byte['m'] = 1024*1024*(isset($match[4])?(int)$match[4]:0);
	$byte['h'] = 1024*1024*60*(isset($match[2])?(int)$match[2]:0);
	$size = array_sum($byte);
	$base = log($size, 1024);
	$suffixes = array('', ' KB', ' MB', ' GB', ' TB');   
	return round(pow(1024, $base - floor($base)), 2).$suffixes[floor($base)];
}


function dateYT($date){
	$date=substr($date,0,10);
	$date=explode('-',$date);
	$mn=date('F',mktime(0,0,0,$date[1])); 
	$dates=''.$date[2].' '.$mn.' '.$date[0].''; 
	return $dates;
}

function pager($page, $param = array()) {
	$defaultparam = array(
		'totalitem' => 500,
		'itemperpage' => 10,
		'firstpageurl' => '/',
		'urlpattern' => '/%d/',
		'linkperpage' => 5,
	);
	
	foreach($defaultparam as $k=>$v) {
		if(!isset($param[$k])) $param[$k] = $v;
	}

  if($param['totalitem'] > 500) $param['totalitem'] = 500;
  $param['linkperpage'] = $param['linkperpage']-1;
  $totalpage = ceil($param['totalitem']/$param['itemperpage']);
  if($page < 1) $page = 1;
  if($page > $totalpage && $page != 1) $page = $totalpage;
  $middle = floor($param['linkperpage']/2);
  $start = $page-$middle;
  if($start < 1) $start = 1;
  if($start > $totalpage-$param['linkperpage']) $start = $totalpage-$param['linkperpage'];
  if($totalpage <= $param['linkperpage']) $start = 1;
  $end = $start+$param['linkperpage'];
  if($end > $totalpage) $end = $totalpage;

	$paging = array();

  //first page
  if($page > 1 && $totalpage > 1 && $start > 1) $paging['first'] = '<a href="'.$param['firstpageurl'].'" title="First Page">&laquo;</a>';

  //prev page
  if($page > 1 && $totalpage != 1 && $start > 1) $paging['prev'] = '<a  href="'.sprintf($param['urlpattern'], $page-1).'" title="Previous Page">&lsaquo;</a>';

  //num page
  for($i=$start; $i<=$end; $i++) {
    if($i == $page) $paging[$i] = '<span class="ppage active" title="Page #'.$i.'">'.$i.'</span>';
    elseif($i == 1) $paging[$i] = '<a class="ppage" href="'.$param['firstpageurl'].'" title="Page #'.$i.'">'.$i.'</a>'; //tambahan, pengaman page/1
    else $paging[$i] = '<a  href="'.sprintf($param['urlpattern'], $i).'" title="Page #'.$i.'">'.$i.'</a>';
  }

  //next page
  if($page < $totalpage && $end != $totalpage) $paging['next'] = '<a href="'.sprintf($param['urlpattern'], $page+1).'" title="Next Page">&rsaquo;</a>';

  //last page
  if($page != $totalpage && $end != $totalpage) $paging['last'] = '<a class="ppage" href="'.sprintf($param['urlpattern'], $totalpage).'" title="Last Page">&raquo;</a>';

  return $paging;
}

$delimiter = $jsonconfig['delimiter'];


function url_slug($str, $options = array()) {
	Global $delimiter;
	// Make sure string is in UTF-8 and strip invalid UTF-8 characters
	$str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
	$defaults = array(
		'delimiter' => $delimiter,
		'limit' => null,
		'lowercase' => true,
		'replacements' => array(),
		'transliterate' => false,
	);
	
	// Merge options
	$options = array_merge($defaults, $options);
	
	$char_map = array(
		// Latin
		'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C', 
		'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 
		'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'O' => 'O', 
		'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'U' => 'U', 'Ý' => 'Y', 'Þ' => 'TH', 
		'ß' => 'ss', 
		'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c', 
		'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 
		'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'o' => 'o', 
		'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'u' => 'u', 'ý' => 'y', 'þ' => 'th', 
		'ÿ' => 'y',

		// Latin symbols
		'©' => '(c)',

		// Greek
		'?' => 'A', '?' => 'B', 'G' => 'G', '?' => 'D', '?' => 'E', '?' => 'Z', '?' => 'H', 'T' => '8',
		'?' => 'I', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => '3', '?' => 'O', '?' => 'P',
		'?' => 'R', 'S' => 'S', '?' => 'T', '?' => 'Y', 'F' => 'F', '?' => 'X', '?' => 'PS', 'O' => 'W',
		'?' => 'A', '?' => 'E', '?' => 'I', '?' => 'O', '?' => 'Y', '?' => 'H', '?' => 'W', '?' => 'I',
		'?' => 'Y',
		'a' => 'a', 'ß' => 'b', '?' => 'g', 'd' => 'd', 'e' => 'e', '?' => 'z', '?' => 'h', '?' => '8',
		'?' => 'i', '?' => 'k', '?' => 'l', 'µ' => 'm', '?' => 'n', '?' => '3', '?' => 'o', 'p' => 'p',
		'?' => 'r', 's' => 's', 't' => 't', '?' => 'y', 'f' => 'f', '?' => 'x', '?' => 'ps', '?' => 'w',
		'?' => 'a', '?' => 'e', '?' => 'i', '?' => 'o', '?' => 'y', '?' => 'h', '?' => 'w', '?' => 's',
		'?' => 'i', '?' => 'y', '?' => 'y', '?' => 'i',

		// Turkish
		'S' => 'S', 'I' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'G' => 'G',
		's' => 's', 'i' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'g' => 'g', 

		// Russian
		'?' => 'A', '?' => 'B', '?' => 'V', '?' => 'G', '?' => 'D', '?' => 'E', '?' => 'Yo', '?' => 'Zh',
		'?' => 'Z', '?' => 'I', '?' => 'J', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => 'O',
		'?' => 'P', '?' => 'R', '?' => 'S', '?' => 'T', '?' => 'U', '?' => 'F', '?' => 'H', '?' => 'C',
		'?' => 'Ch', '?' => 'Sh', '?' => 'Sh', '?' => '', '?' => 'Y', '?' => '', '?' => 'E', '?' => 'Yu',
		'?' => 'Ya',
		'?' => 'a', '?' => 'b', '?' => 'v', '?' => 'g', '?' => 'd', '?' => 'e', '?' => 'yo', '?' => 'zh',
		'?' => 'z', '?' => 'i', '?' => 'j', '?' => 'k', '?' => 'l', '?' => 'm', '?' => 'n', '?' => 'o',
		'?' => 'p', '?' => 'r', '?' => 's', '?' => 't', '?' => 'u', '?' => 'f', '?' => 'h', '?' => 'c',
		'?' => 'ch', '?' => 'sh', '?' => 'sh', '?' => '', '?' => 'y', '?' => '', '?' => 'e', '?' => 'yu',
		'?' => 'ya',

		// Ukrainian
		'?' => 'Ye', '?' => 'I', '?' => 'Yi', '?' => 'G',
		'?' => 'ye', '?' => 'i', '?' => 'yi', '?' => 'g',

		// Czech
		'C' => 'C', 'D' => 'D', 'E' => 'E', 'N' => 'N', 'R' => 'R', 'Š' => 'S', 'T' => 'T', 'U' => 'U', 
		'Ž' => 'Z', 
		'c' => 'c', 'd' => 'd', 'e' => 'e', 'n' => 'n', 'r' => 'r', 'š' => 's', 't' => 't', 'u' => 'u',
		'ž' => 'z', 

		// Polish
		'A' => 'A', 'C' => 'C', 'E' => 'e', 'L' => 'L', 'N' => 'N', 'Ó' => 'o', 'S' => 'S', 'Z' => 'Z', 
		'Z' => 'Z', 
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'l' => 'l', 'n' => 'n', 'ó' => 'o', 's' => 's', 'z' => 'z',
		'z' => 'z',

		// Latvian
		'A' => 'A', 'C' => 'C', 'E' => 'E', 'G' => 'G', 'I' => 'i', 'K' => 'k', 'L' => 'L', 'N' => 'N', 
		'Š' => 'S', 'U' => 'u', 'Ž' => 'Z',
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'g' => 'g', 'i' => 'i', 'k' => 'k', 'l' => 'l', 'n' => 'n',
		'š' => 's', 'u' => 'u', 'ž' => 'z'
	);
	
	// Make custom replacements
	$str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
	
	// Transliterate characters to ASCII
	if ($options['transliterate']) {
		$str = str_replace(array_keys($char_map), $char_map, $str);
	}
	
	// Replace non-alphanumeric characters with our delimiter
	$str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
	
	// Remove duplicate delimiters
	$str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
	
	// Truncate slug to max. characters
	$str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
	
	// Remove delimiter from ends
	$str = trim($str, $options['delimiter']);
	
	return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
}

if($jsonconfig['https'] == 'https'){
	$pro 			= 'https';	
	$protocol       = true;
} elseif($jsonconfig['https'] == 'http') {
	$pro 			= 'http';
	$protocol       = false;
}

if($jsonconfig['www'] == 'www'){
	$www 			= true;
} else {
	$www 			= false;
}

$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;

$urlsite 		= $pro.'://'.$_SERVER['HTTP_HOST'];
$fullpatch 		= $urlsite.$_SERVER['REQUEST_URI'];

if($jam == 22 || $jam == 23 || $jam == 0 || $jam == 1 || $jam == 2 || $jam == 3 ||$jam == 4 ||$jam == 18 ||$jam == 19 ||$jam == 20 ||$jam == 21 || $jam == 10 ) {
$api = array("AIzaSyDYBH11WHaa2F4MZH1pl2Mw55g0T43V2ts", "AIzaSyAhFbBLJvYLFyzfm3a842CJGWgRAcrpOPo", "AIzaSyCpoxE1JBeR8vKIwG8jsu51LbSV6OxpUGg","AIzaSyA1EjXuo6UMOEQ2kPe_rpUM0pp3SnCqkLs","AIzaSyBzS_xgym-izywUUlAI0nFq6PMBrBV-j7I", "AIzaSyChDCEChu-AwDb_PdRZVWJCxOOElBeE-bQ", "AIzaSyAi9Bd_a17AcWxVmKgSXiZO_bl6tXTVWOU", "AIzaSyCi5YcvrmFwL28fCld2VlqrCWSUNdFBi28", "AIzaSyAk901wvVs6pgWzjOp9iYVoH-GeevREoKk", "AIzaSyAt7wWXnSpPLefUGCgYWqHuj4-1vsdMqDc", "AIzaSyBqHx8OHNk8k9wi-6y2vDN7TsbU7eKUYzQ", "AIzaSyB3l0FTl-0jTpmcHyPT31LdtVmlfOfpU64");	
	$yt = $api;
	$apikey  = $yt[array_rand($yt)];
	} else {
	 $api2 = array('AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA');
     // $apikey 		= 'AIzaSyCZfHRnq7tigC-COeQRmoa9Cxr0vbrK6xw';
	 // $apikey 		= 'AIzaSyA-dlBUjVQeuc4a6ZN4RkNUYDFddrVLxrA';
	// $apikey 		= 'AIzaSyD-a9IF8KKYgoC3cpgS-Al7hLQDbugrDcw';
		$apikey  = $api2[array_rand($api2)];

	}
     //$apikey 		= 'AIzaSyCZfHRnq7tigC-COeQRmoa9Cxr0vbrK6xw';

$stat		    = true;
$data['www']	= $www;
$data['https']	= $protocol;
$theme 			= $configcustom['themes'];
$sitetitle 		= $jsonconfig['sitetitle'];
$tagsite 		= $jsonconfig['sitetag'];
$ext 			= $jsonconfig['extension']; //ektensi permalink

$homedisplay 	= $jsonconfig['displayhome']; // choose playlist OR search
$playlistid 	= $jsonconfig['playlistid'];
$searchterm 	= $jsonconfig['searchterm'];

// print_r($jsonconfig);
$searchPermalink= $jsonconfig['searchPermalink'];
$singlePermalink= $jsonconfig['singlePermalink'];
$streamPermalink= $jsonconfig['streamPermalink'];
$authorPermalink= $jsonconfig['authorPermalink'];


$robotsearch 	= $jsonconfig['robotsearch'];
$robotsingle 	= $jsonconfig['singlerobot'];
$robotstreaming	= $jsonconfig['streamrobot'];
$robotauthor 	= $jsonconfig['authorrobot'];
if(isset($configcss['css']) && $configcss['css'] !=''){
$css  			= $configcss['css'];
}
$topmenu 		= 'menus';

//allow/disallow WWW
if($data['www'] === true) {
	if(stripos($_SERVER['HTTP_HOST'], 'www.') !== 0) {
		header('Location: http'.(isset($_SERVER['HTTPS'])?'s':'').'://www.'.$_SERVER['HTTP_HOST'].($data['openshift']?':80':'').$_SERVER['REQUEST_URI']);
		exit;
	}
} 
else {
	if(stripos($_SERVER['HTTP_HOST'], 'www.') === 0) {
		header('Location: http'.(isset($_SERVER['HTTPS'])?'s':'').'://'.str_ireplace('www.', '', $_SERVER['HTTP_HOST']).($data['openshift']?':80':'').$_SERVER['REQUEST_URI']);
		exit;
	}
}
//end of allow/disallow WWW

//HTTPS Redirect
if($data['https'] == true){
if(!empty($data['https']) && !(isset($_SERVER['HTTPS']) || (isset($_SERVER['HTTP_CF_VISITOR']) && strpos($_SERVER['HTTP_CF_VISITOR'], 'https')!==false))) {
	header('Location: https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	exit;
}
}
//end of HTTPS Redirect

function blocked($str) {
	return preg_match('/(bokep|Bokep|sex|adult|porn|mesum|bugil|bokong|Pijat|hot dance|18 plus|\+18|gambar hot|hot video|abg|adult|anak sma|smp|anak smp|anal|anus|arse|ass\s]|asses|assh|pantat|asu\s|ballsack|bastard|big bobs|boob|busty|bitch|biatch|bloody|blow j|blowjob|bokep|bollock|bollok|boner|bugger|nude|nake|naked|bikini|bodypaint|body paint|bugil|telanjang|butt[^oe]|buttplug|clitoris|cock[^r]|coon|crap|crot|cunt|damn|dick[^yi]|dildo|dyke|entot|fag|feck|fellate|fellatio|felching|foilla|.*fuck|f u c k|fudgepacker|fudge packer|flange|gay\s|girang|goddamn|god damn|what the hell|hentai|homo|jerk|jav |jizz|knobend|knob end|kontol|labia|lesbi|lmao|lmfao|masturba|binal|sange|mesum|memek|muff|muncrat|ngakang|ngangkang|ngentot|ngewe|nigger|nigga|nyepong|pejuh|mani\s|sperm|cum[s\s]|cumming|erecti|orgasm.*|ngaceng|boner|peli\s|penis|titit|pelacur|perek|perkosa|piss|poop|porn|prick|pube|pussy|queer|scrotum|seks|sex|esex|esek|shit|sh1t|slut|smegma|spunk|tamil|tante girang|hot.*tante|tante.*hot|desah|mendesah|ngintip|tempek|tempik|tetek|tits|togel|toket|montok|breastfeed|payudara|tosser|turd|twat|vagina|wank|whore|wtf|xxx|explicit|goyang.*hot|hot.*goyang|dangdut.*hot|hot.*dangdut|adegan.*panas|adegan.*hot|foto hot|gambar hot|film.*panas|video panas)/i',' '.preg_replace(array('/\+/u', '/[^\p{L}\p{N}\s]/u', '/\s+/'), array(' plus', ' ', ' '), $str).' ');
}



if(!function_exists('isMobile')) {
	function isMobile() {
		$useragent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
		return (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent, 0, 4)));
	}
}

function bot() {
  return (!empty($_SERVER['HTTP_USER_AGENT']) && preg_match('/googlebot|mediapartner|adsbot/i', $_SERVER['HTTP_USER_AGENT']));
}