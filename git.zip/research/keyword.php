<div style="max-width:750px;margin:0 auto;background:white">
<?php 
include '../setting.php';
$robot = 'noindex, nofollow';
$title = 'Hasil Inject keyword';
include '../contents/themes/fasthink/header.php';
?>
<div>
<?php 
include $domain.'.hasil.php';
?>
</div>
</div>
