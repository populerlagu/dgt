<?php 
include 'setting.php';
$robot = 'noindex, nofollow';
$title = 'MyWeb Datas ~ '.$urlsite;
include 'contents/themes/fasthink/header.php';
?>
<style>
#MusicLovers{max-width:900px}
</style>
<div id="sebar_lagu_contents">
 <div class="entry-body"> 
<?php // if(isset($_SESSION["username"])){
$dir = "config/*.config.json";
array_shift($dir);
?>
<div>
<h1 style="text-align:center">WEBSITE DATA</h1><hr>
<?php 
	foreach (glob($dir) as $v) {
		if(!preg_match('/4dgt/', $v)){
		$data = str_ireplace(array('config/','.config.json'),'', $v);
		$open [] = 'javascript:(function(){window.open(\'http://'.$data.'\');})();';
		}
	}
	?>
<?php 
include 'webdefan.dat';
$oenjan = $df; ?>
<div class="container-fluid">
		<div class="col-md-9">

			<h3>JAMIELCS</h3><hr>
				<?php 
					foreach (glob($dir) as $v) {
						if(!preg_match('/'.$oenjan.'/', $v)){
							$i++;
						$data = str_ireplace(array('config/','.config.json'),'', $v);
						echo "<div class='col-md-6' style='padding:5px 0; border-bottom:1px solid #ddd'>$i . <a rel='nofollow' href='//$data' target='_blank'>$data</a> <br />=> <a href='http://$data/ij/' target='_blank' style='color:red'><small>SUNTIK KEYWORD</small></a></div>";
						} 
					}
				?>
		</div>	
		
	<div class="col-md-3">
		<h3>OENJAN</h3><hr>
			<?php 
				foreach (glob($dir) as $v) {
					if(preg_match('/'.$oenjan.'/', $v)){
						$is++;
					$data = str_ireplace(array('config/','.config.json'),'', $v);
					echo "<div class='' style='padding:5px 0; border-bottom:1px solid #ddd'>$is . <a rel='nofollow' href='//$data' target='_blank'>$data</a> <br />=> <a href='http://$data/ij/' target='_blank' style='color:red'><small>SUNTIK KEYWORD</small></a></div>";
					} 
				}
			?>
			<div style="margin:10px 0">
			<a rel="nofollow" href="/defan.php"><button class="btn btn-danger">Tambah WEB / Edit DATA</button></a>
			</div>
	</div>
	
	
</div><div style="clear:both"></div><br/>

<div class="container">
	<a class="btn btn-success" href="<?php echo join('',$open);?>" >OPEN ALL <?php echo count($open);?> LINK WEBSITE on New TAB</a>
</div><br/>
</div>
<?php //} ?>