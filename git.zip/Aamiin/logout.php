<?php
session_start();
session_destroy();
if(!empty($_GET['return'])){
	// header('Location:'.$_GET['return']); exit;
}
?>
<div class="container-fluid">
You Have benn Logout <a href="login.php?return=<?php echo urlencode($_GET['return']);?>">login Again Bro</a> or <a rel="nofollow" href="/">Go TO HOME</a>
</div>