<?php
error_reporting(0);

echo $_SESSION['username'];
if(isset($_SESSION["username"])){ 
header('Location:/Aamiin/');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title>Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    /* Credit to bootsnipp.com for the css for the color graph */
.colorgraph {
  height: 5px;
  border-top: 0;
  background: #c4e17f;
  border-radius: 5px;
  background-image: -webkit-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -moz-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -o-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: linear-gradient(to right, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
}
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
</head>
<body style="background:#eee">
<div style="margin:0 auto;max-width:750px">
<div style="background:white;padding:10px">
<div class="container-fluid">
<div class="row" style="margin-top:20px">
    <div class="col-xs-12">
		<form role="form" method="post" >
		<?php if(isset($_GET["login_error"])){ ?>
		<h4 style="color: red; text-align: center;" >Username / Passwordmu Salah lo :/</h4>
		<?php } ?>
		
		<?php if(isset($_GET["blank"])){ ?>
		<h4 style="color: red; text-align: center;" >Data username / password ra entuk Kosong Des Bedes :D</h4>
		<?php } ?>
			<fieldset>
				<h2>Please Sign In</h2>
				<hr class="colorgraph">
				<div class="form-group">
                    <input type="text" name="username" id="username" value="" class="form-control input-lg" placeholder="username">
				</div>
				<div class="form-group">
                    <input type="password" name="password" id="password" value="" class="form-control input-lg" placeholder="Password">
				</div>
				<span class="button-checkbox">
					<button type="button" class="btn" data-color="info">Remember Me</button>
                    <input type="checkbox" name="remember_me" id="remember_me" checked="checked" class="hidden">
					<a href="" class="btn btn-link pull-right">Forgot Password?</a>
				</span>
				<hr class="colorgraph">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6">
                        <input type="submit" class="btn btn-lg btn-success btn-block" value="Sign In">
					</div>
					<?php //if(!is_file("/home/admin/web/empatdigit.tk/public_html/config/$domain.signup.json"){ ?> 
					
					<?php // } ?>
				</div>
			</fieldset>
		</form>
	</div>
</div>
</div>
<?php
if($_POST){
	$hostname   = strtolower($_SERVER['SERVER_NAME']);
	$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
	$cons	= fopen("../config/$domain.signup.json", "r");
	$configsign = json_decode(fgets($cons), true);
	session_start();
	$username = $_POST["username"];
	$password = $_POST["password"];

	if(!empty($username) && !empty($password)){
		if(isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] == 'uyeshare.bglweb.site')	{
			if($username == 'bgl' && $password == 'bglsaja') {
			$_SESSION["username"] = $username;
				if(!empty($_GET['return'])){
					header('location:'.$_GET['return']);
					exit;
				} else {
					header('location:/Aamiin/');
					exit;	
				}
			} else {
			  header("location:login.php?login_error");
			}
				
		} elseif(isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] == 'crosslagu.tk')	{
			if($username == 'admin' && $password == 'adminsaja') {
			$_SESSION["username"] = $username;
				if(!empty($_GET['return'])){
					header('location:'.$_GET['return']);
					exit;
				} else {
					header('location:/Aamiin/');
					exit;	
				}
			} else {
			  header("location:login.php?login_error");
			}
				
		} else {
			if($username == 'hambaalloh' && $password == 'Jamielcs45') {
			$_SESSION["username"] = $username;
				if(!empty($_GET['return'])){
					header('location:'.$_GET['return']);
					exit;
				} else {
					header('location:/Aamiin/');
					exit;	
				}
			} else {
			  header("location:login.php?login_error");
			}
		} 
	}	else {
			 header("location:login.php?blank");
		}
}
?>

<script>
$(function(){
    $('.button-checkbox').each(function(){
		var $widget = $(this),
			$button = $widget.find('button'),
			$checkbox = $widget.find('input:checkbox'),
			color = $button.data('color'),
			settings = {
					on: {
						icon: 'glyphicon glyphicon-check'
					},
					off: {
						icon: 'glyphicon glyphicon-unchecked'
					}
			};

		$button.on('click', function () {
			$checkbox.prop('checked', !$checkbox.is(':checked'));
			$checkbox.triggerHandler('change');
			updateDisplay();
		});

		$checkbox.on('change', function () {
			updateDisplay();
		});

		function updateDisplay() {
			var isChecked = $checkbox.is(':checked');
			// Set the button's state
			$button.data('state', (isChecked) ? "on" : "off");

			// Set the button's icon
			$button.find('.state-icon')
				.removeClass()
				.addClass('state-icon ' + settings[$button.data('state')].icon);

			// Update the button's color
			if (isChecked) {
				$button
					.removeClass('btn-default')
					.addClass('btn-' + color + ' active');
			}
			else
			{
				$button
					.removeClass('btn-' + color + ' active')
					.addClass('btn-default');
			}
		}
		function init() {
			updateDisplay();
			// Inject the icon if applicable
			if ($button.find('.state-icon').length == 0) {
				$button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i> ');
			}
		}
		init();
	});
});
</script>
<?php } ?>