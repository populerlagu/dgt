<div class="container-fixed">
<?php 
if($_POST['general']){ // set Data General
	if(empty($_POST['webtitle'])){ //bikin pengaman ?>
	<div class="news">You Must Field Website Title <a href="javascript:history.go(-1)">Go back</a></div>
	<?php }
	elseif(empty($_POST['setdisplay'])){ ?>
	<div class="news">You Must Field "search" or "playlist on display home"!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php }  
	elseif($_POST['setdisplay'] == 'playlist' && empty($_POST['plid'])){ ?>
	<div class="news">You've choosed playlist mode on home but you're Not field playlist id.. please field it..!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php } 
	elseif($_POST['setdisplay'] == 'search' && empty($_POST['searchterm'])){ ?>
	<div class="news">You've choosed SEARCH mode on HOME but you're Not field searchterm.. please field it..!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php }
	elseif(empty($_POST['searchPermalink'])){ ?>
	<div class="news">You Must SET search Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php }
	elseif(empty($_POST['singlePermalink'])){ ?>
	<div class="news">You Must SET single Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php } 
	elseif(empty($_POST['streamPermalink'])){ ?>
	<div class="news">You Must SET streaming Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php } 
	elseif(empty($_POST['authorPermalink'])){ ?>
	<div class="news">You Must SET AUTHOR Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php }
	elseif(empty($_POST['ext'])){ ?>
	<div class="news">You Must Field Permalink extension, you can use html, xhtml, slash, or extension want you like!! <a href="javascript:history.go(-1)">Go back</a></div>
	<?php } else {
	include 'putgeneraldata.php';
	  echo '<div class="alert alert-success"><strong>YOUR CONFIG HAS BEEN SAVED.....:</strong> Now You Must Setting CUSTOM.. <a href="/Aamiin/">Back To Main Setting</a> or  <a href="javascript:history.go(-1)">Go back to General Setting</a></div>'; ?>

  <p>
	<?php highlight_string(print_r($_POST, true)); ?>
  </p>
<?php 	}	
	// highlight_string(print_r($_POST, true));

} elseif($_POST['ads']){
	include 'putadsdata.php';
	echo '<div class="alert alert-success" style="margin-top:10px">
  <strong>YOUR CONFIG HAS BEEN SAVED.....:</strong> Now You Must Setting CUSTOM.. <a href="/Aamiin/">Back To Main Setting</a></div>';
  ?>
  <p>
	<?php highlight_string(print_r($_POST, true)); ?>
  </p>
<?php } elseif($_POST['custom']){
		include 'putcustomdata.php';		
		 echo '<div class="alert alert-success"><strong>YOUR CUSTOM DATA HAS BEEN SAVED.....:</strong><a href="/Aamiin/">Back To Main Setting</a></div>';
		 ?>		 
  <p>
	<?php highlight_string(print_r($_POST, true)); ?>
  </p>
<?php }	elseif($_POST['css']){
	include 'putcss.php';
		 echo '<div class="alert alert-success"><strong>Your Css DATA HAS BEEN SAVED.....:</strong><a href="/Aamiin/">Back To Main Setting</a> or  <a href="javascript:history.go(-1)">Go back</a></div>';
	
	highlight_string(print_r($_POST, true));		
	
}

?></div>