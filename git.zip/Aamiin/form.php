<?php 
$robocop	 = array('noindex,follow','index, follow','noindex, nofollow','noodp');
$ext   		 = array('.html','.xhtml','.asp','.aspx','/');
$delimiter   = array('-','_','~');
?>
<section>
<div class="tab-content">
<div id="home" class="tab-pane fade in active">
<form action="" id="search-form" method="POST" target="_top">
<div class="form-group">
<div class="col-sm-6">
<label>Website Title:</label>
<input class="form-control" placeholder="Website Title" type="text" name="webtitle" value="<?php echo $config['sitetitle'];?>" />
<label>Short Description (site Tag):</label>
<input class="form-control" placeholder="Tag Site" type="text" name="sitetag" value="<?php echo $config['sitetag'];?>" />

<label>Select www or Non www</label>
<select name="www" class="form-control" id="sel1">
	<?php 
	foreach(array('www','non www') as $val) { ?>
	<option <?php if($config['www'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?></select>
<label>Select https or non https</label>
<select name="https" class="form-control" id="sel1">
	<?php 
	foreach(array('https','http') as $val) { ?>
	<option <?php if($config['https'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Select Delimiter Permalink</label>
<select name="delimiter" class="form-control" id="sel1">
	<?php 
	foreach($delimiter as $val) { ?>
	<option <?php if($config['delimiter'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Set Display Home Page</label>
<select name="setdisplay" class="form-control" id="sel1">
	<?php 
	foreach(array('search','playlist') as $val) { ?>
	<option <?php if($config['displayhome'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Default Home Keyword</label>
<input class="form-control" placeholder="Search Term" type="text" name="searchterm" value="<?php echo $config['searchterm'];?>" />
<label>Default Playlist ID Home</label> 
<input class="form-control" placeholder="Playlist ID" type="text" name="plid" value="<?php echo $config['playlistid'];?>" />

<label>Select Extension</label>
<select name="ext" class="form-control" id="sel1">
   	<?php 
	foreach($ext as $val) { ?>
	<option <?php if($config['extension'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Search Page Robot:</label>
<select name="searchrobot" class="form-control" id="sel1">
	<?php 
	foreach($robocop as $val) { ?>
	<option <?php if($config['robotsearch'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Single Page Robot:</label>
<select name="singlerobot" class="form-control" id="sel1">
	<?php 
	foreach($robocop as $val) { ?>
	<option <?php if($config['singlerobot'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>
<label>Streaming Page Robot:</label>
<select name="streamrobot" class="form-control" id="sel1">
	<?php 
	foreach($robocop as $val) { ?>
	 <option <?php if($config['streamrobot'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
   
</select>
<label>Author Page Robot:</label>
<select name="authorrobot" class="form-control" id="sel1">
  	<?php 
	foreach($robocop as $val) { ?>
	 <option <?php if($config['authorrobot'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>   
</select>

<label>Custom Search Permalink:</label>
<input class="form-control" placeholder="Search Permalink" type="text" name="searchPermalink" value="<?php echo $config['searchPermalink'];?>" /> 
<label>Custom Single Permalink:</label>
<input class="form-control" placeholder="Single Permalink" type="text" name="singlePermalink" value="<?php echo $config['singlePermalink'];?>" /> 
<label>Custom Streaming Permalink:</label>
<input class="form-control" placeholder="Streaming Permalink" type="text" name="streamPermalink" value="<?php echo $config['streamPermalink'];?>" />
<label>Custom Author Permalink:</label> 
<input class="form-control" placeholder="Author Permalink" type="text" name="authorPermalink" value="<?php echo $config['authorPermalink'];?>" /> 
</div>

<div class="col-sm-6">
<label>Home Web Description:</label>
<textarea class="form-control" rows="5" id="comment" name="description" placeholder="Deskripsi Web untuk home. Ex: Welcome To Searchine music Mp3... Bla bla bla"><?php echo $config['description'];?></textarea>
<label>Block Keywords:</label>
<textarea Disabled class="form-control" rows="5" id="comment" placeholder="Block Keywrod di sini pishakan dengan tanda | E.G : ungu|vevo|judika|dawin dessert"><?php echo $config['keywords'];?>bokep|sex|adult|porn|mesum|bugil|bokong|Pijat|hot dance|18 plus|\+18|gambar hot|hot video|abg|adult|anak sma|sma[^lrds]|smp|anak smp|anal|anus|arse|ass\s]|asses|assh|pantat|asu\s|ballsack|bastard|big bobs|boob|busty|bitch|biatch|bloody|blow j|blowjob|bokep|bollock|bollok|boner|bugger|nude|nake|naked|bikini|bodypaint|body paint|bugil|telanjang|butt[^oe]|buttplug|clitoris|cock[^r]|coon|crap|crot|cunt|damn|dick[^yi]|dildo|dyke|entot|fag|feck|fellate|fellatio|felching|foilla|.*fuck|f u c k|fudgepacker|fudge packer|flange|gay\s|girang|goddamn|god damn|what the hell|hentai|homo|jerk|jav |jizz|kimcil|knobend|knob end|kontol|labia|lesbi|lmao|lmfao|masturba|binal|sange|mesum|memek|muff|muncrat|ngakang|ngangkang|ngentot|ngewe|nigger|nigga|nyepong|pejuh|mani\s|sperm|cum[s\s]|cumming|erecti|orgasm.*|ngaceng|boner|peli\s|penis|titit|pelacur|perek|perkosa|piss|poop|porn|prick|pube|pussy|queer|scrotum|seks|sex|esex|esek.*|shit|sh1t|slut|smegma|spunk|tamil|tante girang|hot.*tante|tante.*hot|desah|mendesah|ngintip|tai\s|tempek|tempik|tetek|tits|tit\s|toge\s|toket|montok|breastfeed|payudara|tosser|turd|twat|vagina|wank|whore|wtf|xxx|explicit|goyang.*hot|hot.*goyang|dangdut.*hot|hot.*dangdut|adegan.*panas|adegan.*hot|foto hot|gambar hot|film.*panas|video panas</textarea>
<label>Custom Menu:</label>
<textarea class="form-control" rows="5" id="comment"  name="menu" placeholder="Top nav Menu, E.G: pop indo, dangdut, new palalpa, lagu barat"><?php echo $config['menu'];?></textarea>


<label>Max Last View</label>
<select name="maxrecent" class="form-control" id="sel1">
   	<?php 
	foreach(array(5,10,15,20,25,30,35,40) as $val) { ?>
	<option <?php if($config['maxrecent'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Max Trending</label>
<select name="trends" class="form-control" id="sel1">
   	<?php 
	foreach(array(5,10,15,20,25,30,35,40) as $val) { ?>
	<option <?php if($config['trends'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
	<?php } ?>
</select>

<label>Email(Optional):</label>
<input class="form-control" placeholder="Email" type="text" name="email" value="<?php echo $config['email'];?>" /> 
<label>Author Name(Optional):</label>
<input class="form-control" placeholder="Author Name" type="text" name="authorName" value="<?php echo $config['authorName'];?>" /> 
<label>Histats ID (Optional):</label>
<input class="form-control" placeholder="Histats ID" type="text" name="histats" value="<?php echo $config['histats'];?>" /> 
<div class="checkbox">
<p style="margin:5px"><label>
<input name="suggestSearch" type="checkbox" <?php if(!empty($config['suggestSearch'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Suggest Search ON" data-off="<i class='fa fa-stop'></i> Suggest Search OFF"></label>
</p>

<p style="margin:5px"><label>
<input name="lyric" type="checkbox" <?php if(!empty($config['lyric'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Lyric ON" data-off="<i class='fa fa-stop'></i> Lyric OFF"></label>
</p>

<p style="margin:5px"><label>
<input name="latestDownload" type="checkbox" <?php if(!empty($config['latestDownload'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Latest View ON" data-off="<i class='fa fa-stop'></i> Latest View OFF"></label>
</p>

<p style="margin:5px"><label>
<input name="popular" type="checkbox" <?php if(!empty($config['popular'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Trending ON" data-off="<i class='fa fa-stop'></i> Trending OFF"></label>
</p>

</div>
<button <?php if(isset($config['histats'])){ ?><?php } ?> type="submit" name="general" class="btn btn-default" value="SAVE">SAVE</button>
 </div>
 </div>
</form>
</div><!--end tab 1-->
 <!--end tab menu active --> 

<div id="menu2" class="tab-pane fade">
<div class="container-fluid">
<div class="alert alert-success" style="margin-top:10px">
  <strong>AVAILABLE VARIABLE:</strong> %title% , %author% , %date% , %view% , %size% , %duration%
</div>
		<div style="margin:10px 0">

	<form action="" id="search-form" method="POST" target="_top">
		<div style="margin:10px 0">
		
				
		<label>Select Theme (only fasthink)</label>
		<select name="themes" class="form-control" id="sel1">
			<?php 
			foreach(array('fasthink','simplev1','simplev2','simplev3','musikasik') as $val) { ?>
			<option <?php if($configcustom['themes'] == $val){ ?>selected<?php } ?> value="<?php echo $val;?>"><?php echo $val;?></option>
			<?php } ?>
		</select>

		<label>Single Custom Title : </label>
		<textarea class="form-control" rows="2" id="comment" name="customSingleTitle"><?php if(isset($configcustom['customSingleTitle']) && $configcustom['customSingleTitle']  !=''){ ?><?php echo $configcustom['customSingleTitle'];?><?php } else { ?>%size% Download Lagu %title% by %author%<?php } ?></textarea>
		
		<label>Search Custom Title : </label>
		<textarea class="form-control" rows="2" id="comment" name="customSearchTitle"><?php if(isset($configcustom['customSearchTitle']) && $configcustom['customSearchTitle']  !=''){ ?><?php echo $configcustom['customSearchTitle'];?><?php } else { ?>Cari Lagu %title% Mp3<?php } ?></textarea>
		
		<label>Streaming Custom Title : </label>
		<textarea class="form-control" rows="2" id="comment" name="customStreamingTitle"><?php if(isset($configcustom['customStreamingTitle']) && $configcustom['customStreamingTitle']  !=''){ ?><?php echo $configcustom['customStreamingTitle'];?><?php } else { ?>Streaming Lagu %title% Durasi (%duration%)<?php } ?></textarea>
		
		<label>Author Custom Title : </label>
		<textarea class="form-control" rows="2" id="comment" name="customAuthorTitle"><?php if(isset($configcustom['customAuthorTitle']) && $configcustom['customAuthorTitle']  !=''){ ?><?php echo $configcustom['customAuthorTitle'];?><?php } else { ?>List Lagu By %author%<?php } ?></textarea>
		<!--START CUSTOM DESCRIPTION-->
		<label>Single Custom Description : </label>
		<textarea class="form-control" rows="3" id="comment" placeholder="Download %title% by %author% pada %tanggal%" name="customDes"><?php if(isset($configcustom['customDes']) && $configcustom['customDes']  !=''){ ?><?php echo $configcustom['customDes'];?><?php } else { ?>Download Lagu %title% dengan ukuran %size% upload by %author%<?php } ?></textarea>

		<label>Streaming Custom Description : </label>
		<textarea class="form-control" rows="3" id="comment" placeholder="Streaming %title% by %author% pada %tanggal%" name="customStreaming"><?php if(isset($configcustom['customStreaming']) && $configcustom['customStreaming']  !=''){ ?><?php echo $configcustom['customStreaming'];?><?php } else { ?>Streaming Lagu %title% dengan Durasi %duration% upload by %author%<?php } ?>
		</textarea>

		<label>Search Custom Description : </label>
		<textarea class="form-control" rows="3" id="comment" placeholder="Hasil Pencarian dari %title%, Last Link update by %author% on %tanggal%" name="customSearch"><?php if(isset($configcustom['customSearch']) && $configcustom['customSearch']  !=''){ ?><?php echo $configcustom['customSearch'];?><?php } else { ?>Daftar Kumpulan Link %title% Last Link update by %author%<?php } ?></textarea>

		<label>Author Custom Description : </label>
		<textarea class="form-control" rows="3" id="comment" placeholder="Kumpulan Lagu Upload by %author%" name="customAuthor"><?php if(isset($configcustom['customAuthor']) && $configcustom['customAuthor']  !=''){ ?><?php echo $configcustom['customAuthor'];?><?php } else { ?>Kumpulan Lagu Upload by %author%<?php } ?></textarea>

		<button type="submit" value="custom" name="custom" class="btn btn-default">Save</button>
		</div>
	</form>
</div>
</div>
</div><!--end tab 2-->
 <!--end tab menu2--> 

<div id="menu1" class="tab-pane fade">
<div class="container-fluid">
<form action="" id="search-form" method="POST" target="_top">
<div class="checkbox">
<label>
<input name="adGlobal" type="checkbox" <?php if(!empty($configs['adGlobal'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> AdGlobal ON" data-off="<i class='fa fa-stop'></i> Ad Global OFF">
</label>

<label>
<input name="adsense" type="checkbox" <?php if(!empty($configs['adsense'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Adsense On" data-off="<i class='fa fa-stop'></i> Adsense Off">
</label>
<label>
<input name="adreactor" type="checkbox" <?php if(!empty($configs['adreactor'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Adreactor On" data-off="<i class='fa fa-stop'></i> Adreactor Off">
</label>
<label>
<input name="safelink" type="checkbox" <?php if(!empty($configs['safelink'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Safelink On" data-off="<i class='fa fa-stop'></i> Safelink Off">
</label>
</div>
<label>Select Type</label>
<select name="adresponsive" class="form-control" id="sel1">
    <option value="on">Responsive Ad</option><option value="off">Standart Ad</option>
</select>
<label>Adcode For All (Responsive Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS RESPONSIVE CODE" name="adsResponsiveCode"><?php echo $configs['adsResponsiveCode'];?></textarea>

<label>JavaScriprt Adreactor (head code) : </label>
<textarea class="form-control" rows="3" id="comment" placeholder="JavaScriprt ADREACTOR" name="adrheadCode"><?php echo $configs['adrheadCode'];?></textarea>

<label>Adcode (Desktop Version) : </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS DESKTOP VERSION" name="adsDesktopCode"><?php echo $configs['adsDesktopCode'];?></textarea>
<label>Adceode (Mobile Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS MOBILE VERSION" name="adsMobileCode"><?php echo $configs['adsMobileCode'];?></textarea>

<label>Adreactor 1 (Desktop Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR DESKTOP 1" name="adr1pcCode"><?php echo $configs['adr1pcCode'];?></textarea>

<label>Adreactor 2 (Desktop Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR DESKTOP 2" name="adr2pcCode"><?php echo $configs['adr2pcCode'];?></textarea>

<label>Adreactor 1 (Mobile Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR MOBILE 1" name="adr1HpCode"><?php echo $configs['adr1HpCode'];?></textarea>

<label>Adreactor 2 (Mobile Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR MOBILE 2" name="adr2HpCode"><?php echo $configs['adr2HpCode'];?></textarea>

<label>Adreactor FAST DOWNLOAD :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR FAST DOWNLOAD LINK CODE" name="adrFastDownload"><?php echo $configs['adrFastDownload'];?></textarea>

<button type="submit" value="ads" name="ads" class="btn btn-default">Save</button>
</form>
</div>
</div><!--end tab 2-->
 <!--end tab menu1--> 
 
<div id="menu3" class="tab-pane fade">
<div class="container-fluid" style="margin-top:20px">
	<div class="form-group">
		<div class="col-sm-12">
		<form action="" id="search-form" method="POST" target="_top">
		<textarea class="form-control" rows="20" id="comment"  name="putcss"><?php if(!empty($css)){ echo $css;} else { include '../contents/themes/'.$configcustom['themes'].'/minify.css'; } ?></textarea><br/>
		<button type="submit" value="css" name="css" class="btn btn-default">Save</button>
		</form>
		</div>
	</div>
</div>
</div>
<!--end tab custom css / tab menu 3-->

</div><!--end tab kontent-->
</section>