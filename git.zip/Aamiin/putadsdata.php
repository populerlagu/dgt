<?php 
$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
$filenames = "../config/$domain.configads.json";
$recents = array(
	'adGlobal' => $_POST['adGlobal'], 
	'adsense' => $_POST['adsense'], 
	'adreactor' => $_POST['adreactor'], 
	'safelink' => $_POST['safelink'], 
	'adresponsive' => $_POST['adresponsive'],
	'adsResponsiveCode' => $_POST['adsResponsiveCode'],
	'adrheadCode' => $_POST['adrheadCode'],
	'adsDesktopCode' => $_POST['adsDesktopCode'], 
	'adsMobileCode' => $_POST['adsMobileCode'], 
	'adrheadCode' => $_POST['adrheadCode'], 
	'adr1pcCode' => $_POST['adr1pcCode'], 
	'adr2pcCode' => $_POST['adr2pcCode'], 
	'adr1HpCode' => $_POST['adr1HpCode'], 
	'adr2HpCode' => $_POST['adr2HpCode'], 
	'adrFastDownload' => $_POST['adrFastDownload'], 
);
file_put_contents($filenames, json_encode($recents));	
?>