<?php 
// highlight_string(print_r($_POST, true));
$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
$filename = "../config/$domain.config.json";
$recent = array(
	'sitetitle' => ucwords(strtolower($_POST['webtitle'])), 
	'sitetag' => $_POST['sitetag'], 
	'www' => $_POST['www'], 
	'https' => $_POST['https'], 
	'ytapi' => $_POST['ytapi'], 
	'delimiter' => $_POST['delimiter'], 
	'displayhome' => $_POST['setdisplay'], 
	'playlistid' => $_POST['plid'], 
	'searchterm' => $_POST['searchterm'], 
	'searchPermalink' => strtolower($_POST['searchPermalink']), 
	'singlePermalink' => strtolower($_POST['singlePermalink']), 
	'streamPermalink' => strtolower($_POST['streamPermalink']), 
	'authorPermalink' => strtolower($_POST['authorPermalink']), 
	'extension' => $_POST['ext'], 
	'robotsearch' => $_POST['searchrobot'], 
	'singlerobot' => $_POST['singlerobot'], 
	'streamrobot' => $_POST['streamrobot'], 
	'authorrobot' => $_POST['authorrobot'], 
	'description' => $_POST['description'], 
	'keywords' => $_POST['keywords'], 
	'fsearchpage' => $_POST['fsearchpage'], 
	'fsinglepage' => $_POST['fsinglepage'], 
	'fstreampage' => $_POST['fstreampage'], 
	'fauthorpage' => $_POST['fauthorpage'], 
	'email'     => $_POST['email'],
	'authorName' => $_POST['authorName'],
	'histats'     => $_POST['histats'],
	'latestDownload'  => $_POST['latestDownload'],
	'popular'     => $_POST['popular'], 
	'suggestSearch'     => $_POST['suggestSearch'], 
	'lyric'     => $_POST['lyric'], 
	'maxrecent'     => $_POST['maxrecent'], 
	'trends'     => $_POST['trends'], 
	'menu'     => $_POST['menu'], 
);	
file_put_contents($filename, json_encode($recent)); 
?>