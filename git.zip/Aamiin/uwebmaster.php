<div style="margin:20px"> 
<form enctype="multipart/form-data" action="uwebmaster.php" method="POST">
	<div>
		<label>Upload Your google Verification File</label>
	</div>
	<span class="btn btn-default btn-file"  for="my-file-selector"> 
		<input id="my-file-selector" type="file" name="uploaded_file"
		onchange="$('#upload-file-info').html(this.files[0].name)"></input>
	</span>
		<input class="btn btn-success" type="submit" value="Upload"></input>
</form>
<?PHP
include '../setting.php';
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "../webmasters/";
    $path = $path . $domain.'.'.basename( $_FILES['uploaded_file']['name']);

    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
		header('Location: /Aamiin/?webmaster=success&file='.basename( $_FILES['uploaded_file']['name']));
    } else {
        echo "There was an error uploading the file, please try again!";
    }
  }

?>
</div>