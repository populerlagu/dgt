<?php 
$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
$filenamesc = "../config/$domain.custom.json";
$recentsx = array(
	'customSingleTitle' => $_POST['customSingleTitle'], 
	'customSearchTitle' => $_POST['customSearchTitle'], 
	'customStreamingTitle' => $_POST['customStreamingTitle'], 
	'customAuthorTitle' => $_POST['customAuthorTitle'], 
	//des
	'customDes' 		=> $_POST['customDes'], 
	'customStreaming' 	=> $_POST['customStreaming'], 
	'customSearch'		=> $_POST['customSearch'], 
	'customAuthor'		=> $_POST['customAuthor'],
	'themes'		=> $_POST['themes'],
);
file_put_contents($filenamesc, json_encode($recentsx));	
?>