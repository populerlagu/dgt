<?php 
date_default_timezone_set('Asia/Jakarta');
$tanggal= mktime(date("m"),date("d"),date("Y"));
$jam=date("H:i:s");
$buildon = date("d-M-Y", $tanggal).' Pukul '.$jam;

$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
$filename = "../config/$domain.signup.json";
$recent = array(
	'first_name' => $_POST['first_name'], 
	'last_name' => $_POST['last_name'], 
	'user_name' => 'emapatdigit', 
	'user_email' => $_POST['user_email'], 
	// 'user_password' => $_POST['user_password'], 
	'user_password' => 'majubersama2017', 
	'user_password_c' => 'majubersama2017', 
	'buildon' => $buildon, 
);	
file_put_contents($filename, json_encode($recent)); 
?>