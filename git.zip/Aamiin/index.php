<?php
session_start();
error_reporting(0);
$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
if(isset($_SESSION["username"])){ ?>
<?php 
if(is_file("../config/$domain.config.json")){
$conf  	= fopen("../config/$domain.config.json","r");
$config = json_decode(fgets($conf),true);
}

if(is_file("../config/$domain.configads.json")){
$cons	= fopen("../config/$domain.configads.json", "r");
$configs = json_decode(fgets($cons), true);
}

if(is_file("../config/$domain.custom.json")){
$customdata 	= fopen("../config/$domain.custom.json","r");
$configcustom  = json_decode(fgets($customdata), true);
}

if(is_file("../config/$domain.customcss.json")){
$customcss 	= fopen("../config/$domain.customcss.json","r");
$configcss  = json_decode(fgets($customcss), true);
}

$css = $configcss['css'];
// echo $configcustom['themes'];
?>
<?php
$title = 'Website Configuration';
include '../contents/themes/fasthink/header.php'; 
?>
<style>
body{background:#ddd}
.toggle.btn {
    min-width: 159px;
    min-height: 34px;
}
</style>
<div class="container-fluid" style="max-width:750px;margin:0 auto;background:white;border:1px solid #ddd">
<div class="row">
<h1><center>Website Configuration</center></h1>
 <ul class="nav nav-tabs">
    <li><a href="/">HOME</a></li>
    <li class="active"><a data-toggle="tab" href="#home">General</a></li>
    <li><a data-toggle="tab" href="#menu2">Custom</a></li>
    <li><a data-toggle="tab" href="#menu3">Custom Css</a></li>
    <li><a data-toggle="tab" href="#menu1">Adsense</a></li>
    <li><a href="/Aamiin/?upload=1">Tools</a></li>
    <li><a href="/themes/edit.php?file=minify.css&theme=<?php echo $configcustom['themes'];?>">Theme Editor</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>

<?php 
if($_GET['upload']== 1){ ?>
<div class="container-fluid" style="padding:10px">
<a class="btn btn-default" href="/Aamiin/?upload=favicon">Change Favicon</a>
<a class="btn btn-default" href="/Aamiin/?upload=webmaster">Verifikasi Webmaster</a>
<p>
>>> <a href="/Aamiin/">BACK to MAIN SETTING</a> <<<
</p>
<div class="container-fluid">

<?php 
} elseif($_GET['upload'] == 'favicon'){
	include 'ufavicon.php';
} elseif($_GET['upload'] == 'webmaster'){
	include 'uwebmaster.php';
} elseif($_GET['favicon'] == 'success'){
   echo '<div style="margin:20px">
		<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
		<strong>Your Favicon Ico Has Been Set....!</strong> <a target="_blank" href="/favicon/'.$_GET['file'].'" >Clik Here for Check It</a></div></div>';
} elseif($_GET['webmaster'] == 'success'){
   echo '<div style="margin:20px"><div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
		<strong>Your Favicon Ico Has Been Set....!</strong> <a target="_blank" href="/'.$_GET['file'].'">Klik Here For Verifing '.$_GET['file'].'\'s File</a></div></div>';
} else {
	if(!$_POST){
		require('form.php');
	} else { //endi menampilkan form 
		require('senddata.php');
		// highlight_string(print_r($_POST, true));
	}
} ?>
<?php } else {
header('Location: /Aamiin/login.php'); 
 //end jika no session login?>
<?php } ?>