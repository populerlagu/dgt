<?php 
$hostname   = strtolower($_SERVER['SERVER_NAME']);
$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
$css = "../config/$domain.minify.css";
$filenamecss = "../config/$domain.customcss.json";
$recentcss = array(
	'css' => $_POST['putcss'], 
);
file_put_contents($filenamecss, json_encode($recentcss));	?>