<div style="margin:20px"> 
<form enctype="multipart/form-data" action="ufavicon.php" method="POST">
<div>
<label>Upload Your Favicon File</label>
</div>
   <span class="btn btn-default btn-file"> <input type="file" name="uploaded_file"></input></span>
    <input class="btn btn-success" type="submit" value="Upload"></input>
  </form>
<?PHP
if($_GET['status'] == 'success'){ 
echo 'uploaded';
}
include '../setting.php';
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "../favicon/";
    $path = $path . $domain.'.favicon.ico';

    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
		header('Location: /Aamiin/?favicon=success&file='.$domain.'.favicon.ico');
    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }

?>
</div>