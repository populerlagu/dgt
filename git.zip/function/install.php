<?php
require('../setting.php'); 

// echo 'xxxxxx'.$fullpatch;

$title = 'Website Configuration';
include '../contents/header.php'; 
$con	= 'config.json';
$config = json_decode(file_get_contents($con), true);

$cons	= 'configads.json';
$configs = json_decode(file_get_contents($cons), true);

// highlight_string(print_r($configs, true));
?>
<div class="container-fluid">
<div class="row">
<h1><center>Website Configuration</center></h1>
 <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">General</a></li>
    <li><a data-toggle="tab" href="#menu1">Adsense</a></li>
  </ul>

<section>
<div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	
<?php if(!$_POST){ ?>
<form action="" id="search-form" method="POST" target="_top">
<div class="form-group">
<div class="col-sm-6">
<label>Website Title:</label>
<input class="form-control" placeholder="Website Title" type="text" name="webtitle" value="<?php echo $config['sitetitle'];?>" />
<label>Short Description (site Tag):</label>
<input class="form-control" placeholder="Tag Site" type="text" name="sitetag" value="<?php echo $config['sitetag'];?>" />
<label>Youtube APi Key:</label>
<input class="form-control" placeholder="Youtube ApiKey" type="text" name="ytapi" value="<?php echo $config['ytapi'];?>" /> 
<label>Select www or Non www</label>
<select name="www" class="form-control" id="sel1">
    <option value="true">www</option><option value="false">Non WWW</option>
</select>
<label>Select https or non https</label>
<select name="https" class="form-control" id="sel1">
    <option value="true">https</option><option value="false">Non https</option>
</select>
<label>Select Delimiter Permalink</label>
<select name="delimiter" class="form-control" id="sel1">
    <option value="-">Select Delimiter -</option><option value="_">Select Delimiter _</option><option value="~">Select Delimiter ~</option>
</select>
<label>Set Display Home Page</label>
<select name="setdisplay" class="form-control" id="sel1">
    <option value="search">search</option><option value="playlist">playlist</option>
</select>
<label>Default Home Keyword</label>
<input class="form-control" placeholder="Search Term" type="text" name="searchterm" value="<?php echo $config['searchterm'];?>" />
<label>Default Playlist ID Home</label> 
<input class="form-control" placeholder="Playlist ID" type="text" name="plid" value="<?php echo $config['playlistid'];?>" />
<label>Select Extension</label>
<select name="ext" class="form-control" id="sel1">
    <option value=".html">.html</option><option value=".xhtml">.xhtml</option><option value=".asp">.asp</option><option value=".asp">.aspx</option>
	<option value="/">slash</option>
</select>
<label>Search Page Robot:</label>
<select name="searchrobot" class="form-control" id="sel1">
    <option value="noindex, follow">noindex, follow</option>
    <option value="index, follow">index, follow</option>
    <option value="noindex, nofollow">noindex, nofollow</option>
	<option value="noodp">noodp</option>
</select>
<label>Single Page Robot:</label>
<select name="singlerobot" class="form-control" id="sel1">
    <option value="noindex, follow">noindex, follow</option>
    <option value="index, follow">index, follow</option>
    <option value="noindex, nofollow">noindex, nofollow</option>
	<option value="noodp">noodp</option>
</select>
<label>Streaming Page Robot:</label>
<select name="streamrobot" class="form-control" id="sel1">
    <option value="noindex,follow">noindex,follow</option>
    <option value="index,follow">index,follow</option>
    <option value="noindex,nofollow">noindex,nofollow</option>
	<option value="noodp">noodp</option>
</select>
<label>Author Page Robot:</label>
<select name="authorrobot" class="form-control" id="sel1">
    <option value="noindex, follow">noindex,follow</option>
    <option value="index, follow">index,follow</option>
    <option value="noindex, nofollow">noindex,nofollow</option>
	<option value="noodp">noodp</option>
</select>
<label>Custom Search Permalink:</label>
<input class="form-control" placeholder="Search Permalink" type="text" name="searchPermalink" value="<?php echo $config['searchPermalink'];?>" /> 
<label>Custom Single Permalink:</label>
<input class="form-control" placeholder="Single Permalink" type="text" name="singlePermalink" value="<?php echo $config['singlePermalink'];?>" /> 
<label>Custom Streaming Permalink:</label>
<input class="form-control" placeholder="Streaming Permalink" type="text" name="streamPermalink" value="<?php echo $config['streamPermalink'];?>" />
<label>Custom Author Permalink:</label> 
<input class="form-control" placeholder="Author Permalink" type="text" name="authorPermalink" value="<?php echo $config['authorPermalink'];?>" /> 
</div>

<div class="col-sm-6">
<label>Home Web Description:</label>
<textarea class="form-control" rows="5" id="comment" name="description" placeholder="Deskripsi Web untuk home. Ex: Welcome To Searchine music Mp3... Bla bla bla"><?php echo $config['description'];?></textarea>
<label>Home Keywords:</label>
<textarea class="form-control" rows="5" id="comment"  name="keywords" placeholder="List Keyword for Homepage (Pisahkan dengan koma). E g: Download Lagu, Musik, Mp3, dangdut"><?php echo $config['keywords'];?></textarea>
<label>Front Search Page:</label>
<textarea class="form-control" rows="2" id="comment"  name="fsearchpage" placeholder="Front Words for search Page. E.g : Cari Lagu"><?php echo $config['fsearchpage'];?></textarea>
<label>Front Single Page:</label>
<textarea class="form-control" rows="2" id="comment"  name="fsinglepage" placeholder="Front Words for Single Page. E.g : Download Lagu"><?php echo $config['fsinglepage'];?></textarea>
<label>Front Streaming Page Page:</label>
<textarea class="form-control" rows="2" id="comment"  name="fstreampage" placeholder="Front Words for Streaming Page E.g : Streaming" ><?php echo $config['fstreampage'];?></textarea>
 <label>Front Author Page:</label>
<textarea class="form-control" rows="2" id="comment"  name="fauthorpage" placeholder="Front Words for Author Page E.G: List Lagu Dari "><?php echo $config['fauthorpage'];?></textarea>
 <input class="form-control" placeholder="Histats ID" type="text" name="histats" value="<?php echo $config['histats'];?>" /> 
 <button disabled class="btn btn-default" name="type" value="general" type="button">SUBMIT</button>
 </div>

 </div>
</form>
</div><!--end tab 1-->
<div id="menu1" class="tab-pane fade">
<div class="container-fluid">
<form action="" id="search-form" method="POST" target="_top">
<div class="checkbox">
<label>
<input name="adGlobal" type="checkbox" <?php if(!empty($configs['adGlobal'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> AdGlobal ON" data-off="<i class='fa fa-stop'></i> Ad Global OFF">
</label>

<label>
<input name="adsense" type="checkbox" <?php if(!empty($configs['adsense'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Adsense On" data-off="<i class='fa fa-stop'></i> Adsense Off">
</label>
<label>
<input name="adreactor" type="checkbox" <?php if(!empty($configs['adreactor'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Adreactor On" data-off="<i class='fa fa-stop'></i> Adreactor Off">
</label>
<label>
<input name="safelink" type="checkbox" <?php if(!empty($configs['safelink'] == 'on')){ ?>checked<?php } ?> data-toggle="toggle" data-on="<i class='fa fa-play'></i> Safelink On" data-off="<i class='fa fa-stop'></i> Safelink Off">
</label>
</div>
<label>Select Type</label>
<select name="adresponsive" class="form-control" id="sel1">
    <option value="on">Responsive Ad</option><option value="off">Standart Ad</option>
</select>
<label>Adcode For All (Responsive Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS RESPONSIVE CODE" name="adsResponsiveCode"><?php echo $configs['adsResponsiveCode'];?></textarea>

<label>JavaScriprt Adreactor (head code) : </label>
<textarea class="form-control" rows="3" id="comment" placeholder="JavaScriprt ADREACTOR" name="adrheadCode"><?php echo $configs['adrheadCode'];?></textarea>

<label>Adcode (Desktop Version) : </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS DESKTOP VERSION" name="adsDesktopCode"><?php echo $configs['adsDesktopCode'];?></textarea>
<label>Adceode (Mobile Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADS MOBILE VERSION" name="adsMobileCode"><?php echo $configs['adsMobileCode'];?></textarea>

<label>Adreactor 1 (Desktop Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR DESKTOP 1" name="adr1pcCode"><?php echo $configs['adr1pcCode'];?></textarea>

<label>Adreactor 2 (Desktop Version): </label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR DESKTOP 2" name="adr2pcCode"><?php echo $configs['adr2pcCode'];?></textarea>

<label>Adreactor 1 (Mobile Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR MOBILE 1" name="adr1HpCode"><?php echo $configs['adr1HpCode'];?></textarea>

<label>Adreactor 2 (Mobile Version) :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR MOBILE 2" name="adr2HpCode"><?php echo $configs['adr2HpCode'];?></textarea>

<label>Adreactor FAST DOWNLOAD :</label>
<textarea class="form-control" rows="3" id="comment" placeholder="ADREACTOR FAST DOWNLOAD LINK CODE" name="adrFastDownload"><?php echo $configs['adrFastDownload'];?></textarea>

<button type="adsense" value="adsense" class="btn btn-default">Save</button>

</form>
</div>
</div><!--end tab 2-->
  
</div>

</div>
</div><!--rnd row-->

</section>
<?php } else { ?>
<?
if(isset($_POST['type']) && $_POST['type'] =='general'){
	$filename = 'config.json';
	$recent = array(
		'sitetitle' => $_POST['webtitle'], 
		'sitetag' => $_POST['sitetag'], 
		'www' => $_POST['www'], 
		'https' => $_POST['https'], 
		'ytapi' => $_POST['ytapi'], 
		'delimiter' => $_POST['delimiter'], 
		'displayhome' => $_POST['setdisplay'], 
		'playlistid' => $_POST['plid'], 
		'searchterm' => $_POST['searchterm'], 
		'searchPermalink' => $_POST['searchPermalink'], 
		'singlePermalink' => $_POST['singlePermalink'], 
		'streamPermalink' => $_POST['streamPermalink'], 
		'authorPermalink' => $_POST['authorPermalink'], 
		'extension' => $_POST['ext'], 
		'robotsearch' => $_POST['searchrobot'], 
		'singlerobot' => $_POST['singlerobot'], 
		'streamrobot' => $_POST['streamrobot'], 
		'authorrobot' => $_POST['authorrobot'], 
		'description' => $_POST['description'], 
		'keywords' => $_POST['keywords'], 
		'fsearchpage' => $_POST['fsearchpage'], 
		'fsinglepage' => $_POST['fsinglepage'], 
		'fstreampage' => $_POST['fstreampage'], 
		'fauthorpage' => $_POST['fauthorpage'], 
		'histats'     => $_POST['histats'],
	);
	$recentlawas = @json_decode(@file_get_contents($filename), true);
	file_put_contents($filename, json_encode($recent));
	} else {
	$filenames = 'configads.json';
	$recents = array(
		'adGlobal' => $_POST['adGlobal'], 
		'adsense' => $_POST['adsense'], 
		'adreactor' => $_POST['adreactor'], 
		'safelink' => $_POST['safelink'], 
		'adresponsive' => $_POST['adresponsive'],
		'adsResponsiveCode' => $_POST['adsResponsiveCode'],
		'adrheadCode' => $_POST['adrheadCode'],
		'adsDesktopCode' => $_POST['adsDesktopCode'], 
		'adsMobileCode' => $_POST['adsMobileCode'], 
		'adrheadCode' => $_POST['adrheadCode'], 
		'adr1pcCode' => $_POST['adr1pcCode'], 
		'adr2pcCode' => $_POST['adr2pcCode'], 
		'adr1HpCode' => $_POST['adr1HpCode'], 
		'adr2HpCode' => $_POST['adr2HpCode'], 
		'adrFastDownload' => $_POST['adrFastDownload'], 
	);
	file_put_contents($filenames, json_encode($recents));
}
if(isset($_POST['type']) && $_POST['type'] =='general'){
if(empty($_POST['webtitle'])){ ?>
<div class="news">You Must Field Website Title <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
elseif(empty($_POST['ytapi'])){ ?>
<div class="news">You Must Field Youtube APIKEY!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
elseif(empty($_POST['setdisplay'])){ ?>
<div class="news">You Must Field "search" or "playlist on display home"!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php }  
elseif($_POST['setdisplay'] == 'playlist' && empty($_POST['plid'])){ ?>
<div class="news">You've choosed playlist mode on home but you're Not field playlist id.. please field it..!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
elseif($_POST['setdisplay'] == 'search' && empty($_POST['searchterm'])){ ?>
<div class="news">You've choosed SEARCH mode on HOME but you're Not field searchterm.. please field it..!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php }
elseif(empty($_POST['searchPermalink'])){ ?>
<div class="news">You Must SET search Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php }
elseif(empty($_POST['singlePermalink'])){ ?>
<div class="news">You Must SET single Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
elseif(empty($_POST['streamPermalink'])){ ?>
<div class="news">You Must SET streaming Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
elseif(empty($_POST['authorPermalink'])){ ?>
<div class="news">You Must SET AUTHOR Permalink.... Do it.!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php }
elseif(empty($_POST['ext'])){ ?>
<div class="news">You Must Field Permalink extension, you can use html, xhtml, slash, or extension want you like!! <a href="javascript:history.go(-1)">Go back</a></div>
<?php } 
 else {
	echo '<br/>Please CLICK HERE To GO to <a href="/">HOME</a> Or <a href="javascript:history.go(-1)">CLICK HERE FOR EDIT</a>';
} 

} else { ?>
	<div class="container-fluid">
	<?php highlight_string(print_r($_POST, true));
	echo '<p>Your Setting Has Been Saved, <a href="javascript:history.go(-1)">CLICK HERE FOR EDIT</a> or <a href="/">CLICK HERE FOR GO TO HOME</a></p>';
	?>
	</div>
	
<?php } ?>

<?php } ?>
