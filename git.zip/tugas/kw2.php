	<?php 
	include '../setting.php';
	$u = file_get_contents('http://stafaband7.id/');
		preg_match_all('/<a title="([^"]+)"/i', $u, $m);
			foreach($m[1] as $v){
			$val = $v;
				if(!preg_match('/Next|bokep|ngentot|kontol|sek|mesum|memek|bikini|porno/i', $val)){
					$val = str_ireplace(array('html','download', 'free','lagu'), '', $val);
					$kl2     = $urlsite.'/'.$searchPermalink.'/'.url_slug($val).$ext;
					$openkl2 [] = 'javascript:(function(){window.open(\''.$kl2.'\');})();'; 
					$k2++;
							echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$k2.'. '.$val.' <br> =>  <a href="'.$kl2.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a></div>';
				}
		}
	?>

	<a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openkl2);?>">Open Results on New Tab</a> 
