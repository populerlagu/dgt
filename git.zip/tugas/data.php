<?php 
foreach($datas as $key => $value){
	$all [] = $value['url']; 
}
$cekweb = join('|', $all);
?>
<div style="border: 2px solid #d6d2d2;padding: 10px;margin:10px 0;background:white;word-wrap: break-word;">
<p></p>
	<div class="container-fluid" style="margin:0;padding:0">
		<div class="row">
			<div class="col-md-6">
				<h4 style="border-bottom:1px solid brown">WEB SUDAH DIKERJAKAN <b>(<?php echo count($datas);?>)</b></h4>
				<ol style="padding: 1.3em;">
				<?php 
				foreach($semuaweb as $value){
					if(!preg_match('/empatdigit/', $value)){
						$data = str_ireplace(array('../config/','.config.json'),'', $value);
						if(preg_match('/'.$cekweb.'/', $data)){
							echo '<li style="padding:4px 0; color:#337ab7;border-bottom:1px dotted black"><small>'.strtoupper($data).'</small></li>';
						} 
					}
				}
				?>
				</ol>
			</div>

			<div class="col-md-6">
				<h4 style="border-bottom:1px solid brown">WEB BELUM DIKERJAKAN <b>(<?php echo count($semuaweb)- count($datas)-1;?>)</b></h4>
				<ol style="padding: 1.3em;">
				<?php
				foreach($semuaweb as $value){
					if(!preg_match('/4dgt/', $value)){
						// Global $cekweb;
						$data = str_ireplace(array('../config/','.config.json'),'', $value);
						if(!preg_match('/'.$cekweb.'/', $data)){
							echo '<small><li style="padding:4px 0;border-bottom:1px dotted black"><a style=" color:red" target="_blank" href="http://'.$data.'/ij/" rel="nofollow">'.strtoupper($data).'</a></li></small>';
						} 
					}
				}
				?>
				</ol>
			</div><div style="clear:both"></div>
		</div>
	</div>
</div>