<div class="col-md-4">
	<h3 style="font-size:16px"><u>Keyword NYOLONG 1</u></h3>
	<?php 
$file = file_get_contents('https://liriklagudewi.blogspot.co.id/feeds/posts/summary?max-results=20');
preg_match_all("/<title type=\'text\'>Lirik Lagu ([^>]+)<\/title>/i", $file, $match);
array_shift($match[1]);
		foreach($match[1] as $k => $v){
			$kl1     = $urlsite.'/'.$searchPermalink.'/'.url_slug($v).$ext;
			$openkl1 [] = 'javascript:(function(){window.open(\''.$kl1.'\');})();'; 
			$k1++;
				echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$k1.'. '.$v.' <br> =>  <a href="'.$kl1.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a></div>';
		}
		
	?><a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openkl1);?>">Open Results on New Tab</a> 

</div>
