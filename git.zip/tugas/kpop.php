<div class="col-md-12">
	<h3 style="font-size:16px"><u>K-POP UPDATED</u></h3>
	<?php 
// include '../setting.php';
$data = file_get_contents('http://anype.com/SURF/http://www.ilkpop.com/index.html');
$e = explode('New Updates', $data);
array_shift($e);
$data = $e[0];
// &amp;get-artist=Park Jae Jung&amp;get-title=악역 (The Villain)&
if(preg_match_all('/rel="dofollow">([^>]+)</i', $data, $match)){
	unset($match[0]);
	if(!empty($match[1])){
		foreach($match[1] as $v){
			$i++;
			$name = $v;
			echo '<div class="col-md-6" style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$i.'. <a rel="nofollow" target="_blank" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($name).$ext.'"> '.$name.'</a></div>';
		}	
	}
} else {
	echo 'Something Wrong';
} ?>
</div><div style="clear:both"></div>