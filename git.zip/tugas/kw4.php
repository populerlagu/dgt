<div class="col-md-12">
	<h3 style="font-size:16px"><u>K-POP</u></h3>
	<?php 
		// include '../setting.php';
		$data = file_get_contents('https://k2nblog.com/feed/');
		$e = explode('<link', $data);
		array_shift($e); 		array_shift($e);

		foreach($e as $v){
			$i++;
		$name = str_ireplace(array('single','mp3'),'', asd($v, 'https://k2nblog.com/','/'));
		echo '<div class="col-md-4" style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$i.'. <a rel="nofollow" target="_blank" href="'.$urlsite.'/'.$searchPermalink.'/'.$name.$ext.'"> '.fixed($name).'</a></div>';
		 // echo fixed($judul);
		}
	?>
</div><div style="clear:both"></div>