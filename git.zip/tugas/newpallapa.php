<div class="col-md-12">
	<h3 style="font-size:16px"><u>NEW PALLAPA UPDTAE</u></h3>
	<?php 
	// include '../setting.php';
// function asd($content,$start,$end){
  // if($content && $start && $end) {
    // $r = explode($start, $content);
    // if (isset($r[1])){
        // $r = explode($end, $r[1]);
        // return $r[0];
    // }
    // return '';
  // }
// }
$url = file_get_contents('http://anype.com/SURF/http://bursa-musik.wapka.mobi/site_new-pallapa.xhtml&ANYPE_SUBMIT=0');
$url = explode('<div class="indie-list1">', $url);
array_shift($url);
array(0);
foreach($url as $ur){
	$i++;
	$name = asd($ur, 'get-name=','"');	
	// $link = asd($ur,'href="/site_new-pallapa.xhtml?get-cid=','&amp');	
	echo '<div class="col-md-4" style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$i.'. <a rel="nofollow" target="_blank" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($name).$ext.'"> '.$name.'</a></div>';
}
?><div style="clear:both"></div>
</div><div style="clear:both"></div>