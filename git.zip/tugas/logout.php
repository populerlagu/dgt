<?php
session_start();
session_destroy();
?>
<div class="container-fluid">
You Have benn Logout <a href="login.php">login Again Bro</a>
</div>