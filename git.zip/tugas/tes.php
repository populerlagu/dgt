<?php 
$his1 = json_decode(file_get_contents("../contents/datasearch/zlaij.phpt.dat"), true);
$his2 = json_decode(file_get_contents("http://4dgt.club/contents/datasearch/zlaij.phpt.dat"), true);
	
	foreach ($his1 as $key => $value) {
	 //tujuanku njupuk keyword soko his1 his2 pak :D
	}

highlight_string(print_r(array_keys($his2 + $his1), true));		