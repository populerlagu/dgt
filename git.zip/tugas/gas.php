<?php 
include '../setting.php';
$robot = 'noindex, nofollow';
$title = 'Fast Simple Keyword Injector';
include '../contents/themes/fasthink/header.php';
?> 
<hr/>
<style>
body{background:#eee;background: url(http://assets.amung.us/images/header/headerback.png) 0 -19px repeat-x,url(http://assets.amung.us/images/backgrounds/default.png);}
#MusicLovers {
    background: white;
    border: 1px solid #ddd;
    max-width: 1080px;
} hr{margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
} .header{
	background:Black;
	margin:0
} .header h2 {
    margin: 0;
    font-size: 14px;
    padding: 0;
    font-weight: 400;
}
</style>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

<script type="text/javascript" >
(function($)
{
    $(document).ready(function()
    {
        $.ajaxSetup(
        {
            cache: false,
            beforeSend: function() {
                $('#ct').hide();
                $('#loading').show();
            },
            complete: function() {
                $('#loading').hide();
                $('#ct').show();
            },
            success: function() {
                $('#loading').hide();
                $('#ct').show();
            }
        });
        var $container = $("#ct");
        $container.load("<?php echo $urlsite;?>/tugas/kw2.php");
        var refreshId = setInterval(function()
        {
            $container.load('<?php echo $urlsite;?>/tugas/kw2.php');
        }, 50000);
    });
})(jQuery);

</script>

<div class="container-fluid">
	<div class="col-md-12"><h4><center>SIMPLE INJECTOR FOR US</center></h4></div><div style="clear:both"></div>
	<hr />
		<nav>	
			<?php 
			$gas = array('/gas/' => 'GAS UTAMA','/gas/?kw=kw1' => 'GAS KW 1 2 3','/gas/?newpallapa=1' => 'NEW PALLAPA UPDATE','/gas/?kpop=1' =>'K-POP','/gas/?ukpop=1' =>'K-POP UPDATED');
			?>
			<ul class="nav nav-tabs">
			<?php foreach($gas as $ke => $vew){ 
			?>			
				<li <?php if($_GET['kw']){ ?>class="active"<?php } ?>><a rel="nofollowe" href="<?php echo $ke;?>"><?php echo $vew;?></a> </li>
			<?php } ?>
			</ul>
		</nav>
	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div class="col-md-12">
			<div class="alert alert-success">
				<h6 style="font-size;15px">JIKA DATA TIDAK  MUNCUL SILAHKAN RELOAD HALAMAN INI</h6>
			</div>
		</div><div style="clear:both"></div>
	</div>


	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
	<?php if(isset($_GET) && $_GET['kw'] == 'kw1'){
		include 'kw1.php';
		?>
		<div class="col-md-4">
		<h3 style="font-size:16px"><u>Keyword NYOLONG 2</u></h3>
		<div id="ct"></div>
		<img src="https://www.sitepoint.com/demos/auto-refresh-div-content/loading.gif" id="loading" alt="loading" style="display:none;" />
		<div style="clear:both"></div>
		</div>
		
		<?php	
			include 'kw3.php';
		} elseif($_GET['newpallapa']){
			include 'newpallapa.php';
		} elseif($_GET['kpop']){
			include 'kw4.php';
		}  elseif($_GET['ukpop']){
			include 'kpop.php';
		} else { ?>
	
		<div class="col-md-3">
			<h3 style="font-size:16px"><u>Keyword Research 1</u></h3>
			<?php 
			$tren = file_get_contents('http://4dgt.club/tugas/hasil.php');
			$ex   = explode("\n", $tren);
			if($ex[0]){
					foreach(array_slice($ex,0,20) as $val){
						if($val){
						$ixe++;
							echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$ixe.'. '.fixed($val).' <br/> => <a rel="nofollow" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($val).$ext.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a> </div>';
							$openSearch1 []	= 'javascript:(function(){window.open(\''.$urlsite.'/'.$searchPermalink.'/'.url_slug($val).$ext.'\');})();';
						} 
					}					
				}
			// highlight_string(print_r($ex, true));
			?>
			<a target="_blank" href="http://4dgt.club/kirim/" rel="nofollow"><button class="btn ctn-default" style="margin:5px 0">EDIT / Tambah Data</button></a><br/>
			<a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openSearch1);?>">Open Results on New Tab</a> 
				<hr/>
		
		</div>
		
		<div class="col-md-3">
			<h3 style="font-size:16px"><u>Keyword Research 2</u></h3>
			<?php 
			// $tren = file_get_contents('http://4dgt.club/tugas/hasil.php');
			// $ex   = explode("\n", $tren);
			if($ex[20]){
					foreach(array_slice($ex,20,30) as $val){
						if($val){
						$ix2++;
							echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$ix2.'. '.fixed($val).' <br/> => <a rel="nofollow" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($val).$ext.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a> </div>';
							$openSearch1 []	= 'javascript:(function(){window.open(\''.$urlsite.'/'.$searchPermalink.'/'.url_slug($val).$ext.'\');})();';
						} 
					}					
				}
			// highlight_string(print_r($ex, true));
			?>
			<a target="_blank" href="http://4dgt.club/kirim/" rel="nofollow"><button class="btn ctn-default" style="margin:5px 0">EDIT / Tambah Data</button></a><br/>
			<a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openSearch1);?>">Open Results on New Tab</a> 
				<hr/>		
		</div>

		<div class="col-md-3">
			<h3 style="font-size:16px"><u>Keyword Web 1</u></h3>

			<?php 
			$data = file_get_contents('http://www.nella-kharisma.date/zlast.txt');
			$e 	  = explode('|#|', $data);
			if($e[0]){
				foreach(array_slice($e,0,20) as $v){
					$i++;
					echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;">'.$i.'. '.fixed($v).' <br/> => <a rel="nofollow" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($v).$ext.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a> </div>';
					$openSearch2 []	= 'javascript:(function(){window.open(\''.$urlsite.'/'.$searchPermalink.'/'.url_slug($v).$ext.'\');})();';
				} 
			} else {
				echo '<div>Data Sedang Di Perbarui.... Silahkan Reload Halaman Ini</div>';
			}
			?>
				<a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openSearch2);?>">Open Results on New Tab</a> 
				<hr/>
		</div>
		
		<div class="col-md-3">
			<h3 style="font-size:16px"><u>Keyword Web 2</u></h3>

			<?php 
			$datas = file_get_contents('http://www.arenalagu.co/zlast.txt');
			$es 	  = explode('|#|', $datas);
			if($es[0]){
				foreach(array_slice($es,0,20) as $ve){
					$ix++;
					echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;">'.$ix.'. '.fixed($ve).' <br/> => <a rel="nofollow" href="'.$urlsite.'/'.$searchPermalink.'/'.url_slug($ve).$ext.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a> </div>';
					$openSearch3 []	= 'javascript:(function(){window.open(\''.$urlsite.'/'.$searchPermalink.'/'.url_slug($ve).$ext.'\');})();';
				}
			} else {
				echo '<div>Data Sedang Di Perbarui.... Silahkan Reload Halaman Ini</div>';
			}
			?>
				<a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openSearch3);?>">Open Results on New Tab</a> 
				<hr/>
		</div><div style="clear:both"></div>
			
		<?php } 
		?>
	</div><div style="clear:both"></div>
	
<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div>
		<fieldset>
		 <legend>Daftar Website</legend>
		<?php 
			foreach(glob("../config/*.config.json")  as $v) {
				if(!preg_match('/4dgt/', $v)){
				$data = str_ireplace(array('../config/','.config.json'),'', $v);
				$arrs [] = "<a rel='nofollow' href='//$data/gas/' target='_blank'>$data</a>";
				}
			}
			echo join(' | ', $arrs);
		?>
		</fieldset>
		</div>	
	</div>
</div>
<?php
// highlight_string(print_r($e, true));