<?php 
if($_POST){
if(isset($_POST['jawaban']) && $_POST['jawab'] == 'hijau'){ ?>	
<?php } elseif($_POST['jawab'] != 'hijau') { ?>
<script>
alert('Jawabanmu Salah Coeg');
</script>
<?php } 
}?>
	
<?php 
$datas = json_decode(file_get_contents("/home/admin/web/empatdigit.tk/public_html/tugas/weblog.dat"),true);
$semuaweb = glob("../config/*.config.json");

?><!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo count($datas);?> - User Log Detail</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
		body{background:#eee;background: url(http://assets.amung.us/images/header/headerback.png) 0 -19px repeat-x,url(http://assets.amung.us/images/backgrounds/default.png);    font-size: 13px;
}
		#wrap{margin:0 auto;max-width:1200px}
		fieldset.datas {
		border: 1px groove #ddd !important;
		padding: 0 1.4em 1.4em 1.4em !important;
		margin: 0 0 1.5em 0 !important;
		-webkit-box-shadow:  0px 0px 0px 0px #000;
			box-shadow:  0px 0px 0px 0px #000;
		}
		legend.datas {
		width:inherit; /* Or auto */
		padding:0 10px; /* To give a bit of padding on the left and right */
		border-bottom:none;
		} 
		thead{color: white;
		background: black;
		border: 1px solid red;
		}
	</style>
	</head>
	<body>
	<div id="wrap">
		<div class="header">
		<h1 style=" padding: 20px;    color: white;    margin: 0;    background: black;"><center><?php echo count($datas);?> Websites Was Injected</center></h1>
		</div>
		<hr/>
	<div id="contents">
	<div class="container-fluid" style="margin:0;padding:0">
	<div class="row">
	<div class="col-md-8">
		<div class="container-fluid" style="margin:0;padding:0">
				<div style="border: 2px solid #d6d2d2;padding: 10px;margin:10px 0;background:white">
					<fieldset class="datas">
						<legend class="datas">TOTAL WEB (<?php echo count($semuaweb)-1;?>)</legend>
						<?php  
						foreach($datas as $ke => $val){
							$urls[]	= $val['user'];					
						}
						foreach(array_count_values($urls) as $k => $v){ 
						$i++; ?>
						<div class="col-md-4" style="padding:0 10px 10px 0 ;border-bottom:1px dotted #333">
							<?php echo '<b>'.$i.'. '.$k.'</b> => <span style="color:red;font-weight: bold;">'.$v;?></span> Website
						</div>
						<?php } ?>	
					</fieldset>
				</div>
			</div>	
		<div style="border: 2px solid #d6d2d2;padding: 10px;background:white">		
			<div class="table-responsive">          
				<table class="table">
					<?php if(is_file('weblog.dat')){ ?>
					<thead>
					<th>NO</th><th>NAME</th><th>DOMAIN</th><th>KEYWORD</th><th>SUBMIT ON</th>	
					</thead>
					<tbody style="font-style: italic;">
					<?php 
					foreach($datas as $key => $value){
					$user	= $value['user'];
					$kw		= $value['kw'];
					$domain	= $key;
					$date	= $value['date'];
					
					//hitung domain user 
					
					$urls [] = $user;
					if($user == 'Putri'){
						$bg = 'rgba(33, 150, 243, 0.14)';
					} elseif($user == 'Jamielcs'){
						$bg = 'rgba(76, 175, 80, 0.25)';
					} elseif($user == 'Zafa'){
						$bg = 'pink';
					} elseif($user == 'Ayunindya'){
						$bg = '#00bcd4';
					} elseif($user == 'Aslikh Maulana'){
						$bg = 'orange';
					} elseif($user == 'Jamielcs'){
						$bg = 'rgba(9, 0, 128, 0.38)';
					} elseif($user == 'Muh Habibi'){
						$bg = 'rgba(0, 128, 0, 0.58)';
					} elseif($user == 'Moh Asharudin'){
						$bg = 'rgba(255, 255, 0, 0.31)';
					} elseif($user == 'Fendi Lutfin'){
						$bg  = 'rgba(255, 0, 0, 0.38)';
					} elseif($user == 'Khairul Azmi'){
						$bg = 'rgba(0, 0, 255, 0.41)';
					} elseif($user == 'Defan'){
						$bg = 'white';
					}
					$x++;
						if($user && $kw && !preg_match('/4dgt/', $domain)){
						?>
							<tr style="background:<?php echo $bg;?>">
							<td><?php echo $x;?></td><td><?php echo $user;?></td><td><b><?php echo strtoupper($domain);?></b></td><td><?php echo $kw;?></td><td> <?php echo $date;?></td>
							</tr>
						<?php } 
					} ?>
					<?php } else { ?>
						<tr style="text-align: center;"><center><td width="100%"><img src ="http://chirang.gov.in/resources/administration/village_list/block_wise/sidli.jpg"/><p><a style="color:white" href="/tugas/" rel="nofollow"><button class="btn btn-default" style="background:orange;color:white">INPUT DATA NOW</button></a></td></center><tr> 

					<?php } ?>
						</tbody>

				</table>
				<?php	
				if(is_file("weblog.dat")){?>
				<center><button data-toggle="modal" data-target="#copyright" class="btn btn-default dl"><i class="fa fa-arrow-circle-o-down"></i> PERBARUHI DATA </button></center>
						<div class="modal fade" id="copyright" role="dialog" style="display: none;"> 
							<div class="modal-dialog"> 
								<div class="modal-content"> 
									<div class="modal-header"> 
										<button type="button" class="close" data-dismiss="modal">×</button> 
										<h4 class="modal-title">Protected</h4> 
									</div> 
									<div class="modal-body">
										<div class="form-group" style="text-align:center">
										Silahkan Jawab Pertanyaan Ini: 
										<b>Siapa Nama Presiden Kita????</b>
										<form method="POST" action=""><input class="form-control" type="text" name="jawab"><br/><input class="btn btn-danger" type="submit" name="jawaban" value="Jawab"></form>
	
										</div> 

									</div> 
									<div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> </div> 
								</div> 
							</div> 
						</div>
				<!--<a href="del.php?del"><button class="btn btn-default" style="background:orange;">PERBARUHI DATA</button></a></center>-->
				<?php } ?>	
			</div>		
		</div>
		
		
	
	
	
	</div><!--end 9 utama-->
	<div class="col-md-4">
	<?php include 'data.php';?>
	</div><!--end 3 utama-->
	</div>
	</div>
	
	<footer>
		<div class="footer" style="background:black">
			<div class="container">
				<div class="col-md-6">
				<p>
				Welcome Member Empat Digit...!!!!
				</p>
				</div>
				
				<div class="col-md-6">
				
				</div>
			</div>
		</div>
	</footer>
	<?php
	// echo count($dataJamielcs);
	// highlight_string(print_r(array_count_values($urls),true));
	// highlight_string(print_r(array_unique($nama), true));
	// highlight_string(print_r($datas, true));

