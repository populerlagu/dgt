<?php 
include '../setting.php';
	date_default_timezone_set('Asia/Jakarta');
	$tanggal 	= mktime(date("m"),date("d"),date("Y"));
	$jam		= date("H:i:s");
	$datelog    = date("d-M-Y", $tanggal).''.$jam;
	$lastlog 	= date("d-M-Y", $tanggal).' Pukul '.$jam;
?><html>
<head>
<meta charset="utf-8"> <meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" name="viewport">
<title>Inject Elek2an Coy</title>
<meta content="noindex, nofollow" name="robots" />
<style>
body{font-size:13px}
a,textarea{color:#03a9f4;text-decoration:none}
</style>
<link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css"> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script> 
<script type="text/javascript">
$(document).ready(function(){$('input[name="q"]').autocomplete({source:function(query,response){$.getJSON("https://suggestqueries.google.com/complete/search?callback=?",{"hl":"id","jsonp":"suggestCallBack","q":query.term,"ds":"yt","client":"youtube",});suggestCallBack=function(data){var suggestions=[];$.each(data[1],function(key,val){suggestions.push(val[0]);});suggestions.length=10;response(suggestions);};},delay:0,});});
</script>
</head>
<body>
<?php 
include '../function/token.php';
$dir = "../config/*.config.json";
	if($_GET['task'] == 1){
		$bagi = array_slice(glob($dir),0, -133,true);
	} elseif($_GET['task']== 2){
		$bagi = array_slice(glob($dir), -133, -119);
	} elseif($_GET['task']== 3){
		$bagi = array_slice(glob($dir),-119, -106,true);
	} elseif($_GET['task']== 4){
		$bagi = array_slice(glob($dir), -106, -93,true);
	} elseif($_GET['task']== 5){
		$bagi = array_slice(glob($dir), -93 , -80,true);
	} elseif($_GET['task']== 6){
		$bagi = array_slice(glob($dir),-80, -66,true);
	} elseif($_GET['task']== 7){
		$bagi = array_slice(glob($dir), -66,-54,true);
	}	elseif($_GET['task']== 8){
		$bagi = array_slice(glob($dir),-54,-40,true);
	}	elseif($_GET['task']== 9){
		$bagi = array_slice(glob($dir),-40,-27,true);
	}	elseif($_GET['task']== 10){
		$bagi = array_slice(glob($dir),-27,-14,true);
	}	elseif($_GET['task']== 11){
		$bagi = array_slice(glob($dir),-14, -1,true);
	}	else {
		$bagi = array_slice(glob($dir),0,146,true);
	}
	
	$term = $_GET['q'];	
	$page = range(1, 50);
	$max  = range(1, 5);
	
	if($_GET['page'] > 1){
	$_GET['page'] = $pageToken[$_GET['page']];
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&pageToken='.$_GET['page'].'&order='.$_GET['qs'].'&videoCategoryId=10&maxResults='.$_GET['max'].'&key='.$apikey;
	} else {
		$data ='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q='.urlencode($term).'&order='.$_GET['qs'].'&videoCategoryId=10&maxResults='.$_GET['max'].'&key='.$apikey;
	}
	
    // echo $data;
	
	$json = json_decode(file_get_contents($data));
	$artis = array('gerry mahesa','tasya rosmala','armada band','virgoun', 'Om Adella','new pallapa', 'om sera', 'om lagista', 'om monata','nella kharisma', 'via vallen');
	$short = array('date','viewCount','rating','title');
	//start
	session_start();
    if(isset($_SESSION["user"])){  
	?>
	
	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div style="text-align:left">
			<h1 style="text-align:left"><u><?php if($_GET){ echo strtoupper($term); } else { echo 'INJECT ELEK ELEKAN BRO';}?></u></h1>
			<div>
			<fieldset>
			<legend>Welcome <?php echo $_SESSION['user'];?></legend>
			<form method="GET" action="/ij/">
			<label><small>Masukkan Nama Artis Saja</small></label><br/><br/>
				<input type="text" name="q" value="<?php echo $_GET['q'];?>" placeholder="masukkan nama artist">
				<select name="qs">
					<?php foreach($short as $v){ ?>
						<option value="<?php echo $v;?>"><?php echo $v;?></option>
					<?php } ?>
				</select>
				
				<br><br>
				<label>max Results : </label>
				<select name="max">
					<?php foreach($max as $ve){ ?>
						<option value="<?php echo $ve*10;?>"><?php echo $ve*10; ?></option>
					<?php } ?>
				</select>
				
				
				<label>Page : </label>
				<select name="page">
					<?php foreach($page as $v){ ?>
						<option value="<?php echo $v;?>"><?php echo $v; ?></option>
					<?php } ?>
				</select> <br><br>
				
				<input type="submit" name="record" value="Go">			
			</form>
			</fieldset>
			</div>
		</div>
	</div>
	<?php if(!empty($json->items)){ ?>
	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div>
		<fieldset>
		<legend>Hy <?php echo $_SESSION['user'];?></legend>
		<?php 
		$save = 'anu.txt'
		?>
		<form method="post">
			<textarea name="bat" style="width:100%;height:300px" placeholder="List Result"><?php 
			file_put_contents($save, $_POST['bat']);
				if(!empty($json->items && $_GET)){
					foreach($json->items as $value){
						$videoid 	= strrev($value->id->videoId);
						$title 		= preg_replace('/\s+/', ' ', $value->snippet->title);
						$title 		= preg_replace('/[[:^print:]]/', '', $title);
						$link 		= url_slug($title);
						$lsearch	= $urlsite.'/'.$searchPermalink.'/'.url_slug($title).$ext;
						$lsingle 	= $urlsite.'/'.$singlePermalink.'/'.url_slug($title).'.'.$videoid.$ext;
						$opensearch []	= 'javascript:(function(){window.open(\''.$lsearch.'\');})();';
						$opensingle []	= 'javascript:(function(){window.open(\''.$lsingle.'\');})();';
						$pub 		= $value->publishedAt;
							if($link != url_slug($term)){
							?><?php echo "start chrome $urlsite/$searchPermalink/$link$ext\n"; ?><?php 
						}
					}
				}
				
			?></textarea><br/><br>			
			<input style="margin:2px" type="submit" name="saved" value="Save File">
			<button style="margin:2px">KLik Here For Copy LIst</button>
			<button style="margin:2px"><a style="color:black" rel="nofollow" href="<?php echo join('',$opensearch);?>">Open Results For Search Page on New Tab</a></button> 
			<button style="margin:2px"><a style="color:black" rel="nofollow" href="<?php echo join('',$opensingle);?>">Open Results For Single Page on New Tab</a></button> 
		</form>

			<?php if($_POST['saved']){ ?>
				<p>
				FILE SAVED => <a target="_blank" rel="nofollow" href="/anu.txt">klik for view File</a>
				</p>
			<?php }?>
		<script type="text/javascript">
		$("button").click(function(){
		$("textarea").select();
		document.execCommand('copy');
		});
		</script>
		</fieldset>
		</div>
	</div>
	<?php } ?>
	
	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div>
		<fieldset>
		 <legend>HIstory Research</legend>
		<?php 
		$his1 = json_decode(file_get_contents("../contents/datasearch/zlaij.phpt.dat"), true);
		$his2 = json_decode(file_get_contents("http://4dgt.club/contents/datasearch/zlaij.phpt.dat"), true);
		$hist = array_values($his1 + $his2);
		// $horder = array_values($his1 + $his2);		
		// highlight_string(print_r($hist, true));
			foreach($hist  as $val) {
				$l = $urlsite.'/ij/?q='.urlencode($val['kw']).'&qs='.$val['order'].'&max=10&page=1&record=Go';
				if(isset($val)){
					$arr [] = " <a rel='nofollow' href='$l'>$val[kw]</a>";
				}
			}
			
			echo join(' | ', $arr);
		?>
		</fieldset>
		</div>	
	</div>
	
	<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
		<div>
		<fieldset>
		 <legend>Daftar Website</legend>
		<?php 
			foreach($bagi  as $v) {
				if(!preg_match('/4dgt/', $v)){
				$data = str_ireplace(array('../config/','.config.json'),'', $v);
				$arrs [] = "<a rel='nofollow' href='//$data/ij/' target='_blank'>$data</a>";
				}
			}
			echo join(' | ', $arrs);
		?>
		</fieldset>
		</div>	
	</div>
	
	<?php } else { ?>
		<div style="border:2px solid #ddd;padding:10px;margin-bottom:10px">
			<a href="/tugas/login.php?return=<?php echo $fullpatch;?>">LOGIN DISEK</a>
		</div>
	<?php } ?>	
</body>
</html>
	

<?php //highlight_string(print_r($_GET, true));
if(!bot()){ 
	if($_GET['record']){
		$record = $_SESSION['user'].' Has been Submit >>> '.strtoupper($_GET['q']).'<<< on '.$domain;
		// file_get_contents('https://api.telegram.org/bot393756827:AAHa_fevEW1NbFV3kusZ0EyExnlxRZzFOcA/sendMessage?chat_id=254958933&text='.urlencode($record));
			if(isset($_GET['q']) && !empty($json->items)){
				$loged = "../tugas/weblog.dat";
					$max = 150;
					$recentlog [$domain] = array('user' => $_SESSION['user'],'date' => $lastlog, 'kw' =>  fixed($_GET['q']), 'order' => $_GET['qs'], 'url'=> $domain);
					$recentlawas = @json_decode(@file_get_contents($loged), true);
					if(is_array($recentlawas)) {
						$recentlawas = array_slice($recentlawas, 0, $max, true);
						$recentlog = $recentlog + $recentlawas;
					}
					// print_r($recent);
				file_put_contents($loged, json_encode($recentlog));
			}
	}

	if(isset($_GET['q']) && !empty($json->items)){
		$filenames = "../contents/datasearch/zlaij.phpt.dat";
		$max = 150;
		$recent [fixed($_GET['q'])] = array('kw' =>  fixed($_GET['q']), 'order' => $_GET['qs']);
		$recentlawas = @json_decode(@file_get_contents($filenames), true);
		if(is_array($recentlawas)) {
			$recentlawas = array_slice($recentlawas, 0, $max, true);
			$recent = $recent + $recentlawas;
		}
		// print_r($recent);
		file_put_contents($filenames, json_encode($recent));
	}
}