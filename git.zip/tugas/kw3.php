<div class="col-md-4">
	<h3 style="font-size:16px"><u>Keyword NYOLONG 3</u></h3>

<?php 
// include 'setting.php';
$file = json_decode(file_get_contents('http://whos.amung.us/stats/data/?j8879hvy&k=gh2k4ffwy4gr&list=recents&max=1'),true);
foreach($file['pages'] as $v){
	$titles []= str_ireplace(array('Lirik Lagu ',' | 2017'), '', $v['title']);
}
$data = array_unique($titles);

foreach($data as $v){
	$kl3	    = $urlsite.'/'.$searchPermalink.'/'.url_slug($v).$ext;
	$openkl3 [] = 'javascript:(function(){window.open(\''.$kl3.'\');})();'; 
	$kplus++;
		echo '<div style="border-bottom:1px solid #eee;padding:4px;text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" >'.$kplus.'. '.$v.' <br> =>  <a href="'.$kl3.'" target="_blank" style="color;red"><small>Klik For Inject This Keyword </small></a></div>';
} ?><a class="btn btn-success" style="color:black" rel="nofollow" href="<?php echo join('',$openkl3);?>">Open Results on New Tab</a> 
</div><div style="clear:both"></div>