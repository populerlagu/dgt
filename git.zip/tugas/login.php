<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// echo 'TES';
// exit;
include '../setting.php';
if($_POST['loginnow']){
	date_default_timezone_set('Asia/Jakarta');
		$tanggal 	= mktime(date("m"),date("d"),date("Y"));
		$jam		= date("H:i:s");
		$lastlog 	= date("d-M-Y", $tanggal).' Pukul '.$jam;

		$hostname   = strtolower($_SERVER['SERVER_NAME']);
		$domain     = substr($hostname, 0, 4) == 'www.' ? substr($hostname, 4) : $hostname;
		$files 	= "../tugas/log.dat";
		$most [$_POST[user]] = array('name'	  => $domain, 'lastLogin' => $lastlog);	
			$recentlawas = @json_decode(@file_get_contents($files), true);
			if(is_array($recentlawas)) {
				$recentlawas = array_slice($recentlawas, 0, $max, true);
				$most = $most + $recentlawas;
				
			}			
		file_put_contents($files, json_encode($most)); 
		
		//sendMessage to Telegram

			
	$user = $_POST["user"]; 
	// $pass = $_POST["pass"];

	if($user == $_POST["user"] && $_POST["user"] !='Select Your Name' && !empty($_POST["user"])) {
		$message = ''.$_POST['user'].' => '. $domain.' => date '.$lastlog;		
		// file_get_contents('https://api.telegram.org/bot393756827:AAHa_fevEW1NbFV3kusZ0EyExnlxRZzFOcA/sendMessage?chat_id=254958933&text='.urlencode($message));
		session_start();
		$_SESSION["user"] = $user;	
		if(!empty($_GET['return'])){
			header('location:'.$_GET['return']);
			exit;
		} else {
			header('location:index.php?login='.$user);
			exit;
		}
	} else {
		header('location:login.php?blank');
	}
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title>Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    /* Credit to bootsnipp.com for the css for the color graph */
.colorgraph {
  height: 5px;
  border-top: 0;
  background: #c4e17f;
  border-radius: 5px;
  background-image: -webkit-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -moz-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -o-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: linear-gradient(to right, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
}
    </style>
  
</head>
<body style="background:#eee">
<div style="margin:0 auto;max-width:750px">
<div style="background:white;padding:10px">
<div class="container-fluid">
<div class="row" style="margin-top:20px">
    <div class="col-xs-12">
		<form role="form" method="post" >
		<?php if(isset($_GET["login_error"])){ ?>
		<h4 style="color: red; text-align: center;" >Username / Passwordmu Salah lo :/</h4>
		<?php } ?>
		
		<?php if(isset($_GET["blank"])){ ?>
		<h4 style="color: red; text-align: center;" > Select Your Name</h4>
		<?php } ?>
			<fieldset>
				<h3><center>Sign in dulu dari pada kicked From Team</center></h3>
				<hr class="colorgraph">
					<div class="form-group">
						<label>Login As:</label>
						<select name="user" class="form-control" id="sel1">
							<?php 
							$use = array('Putri','Defan','Mjt');
							foreach($use as $val) { 
							$i++;?>
							<option value="<?php echo $val;?>"><?php echo  $val;?></option>
							<?php } ?>
						</select>
					</div>
					
					<div>
					<h3 style="text-align:center">LIST MEMBER</h3><hr />
						<?php foreach($use as $u){
							$s++;
							?>
							<div class="col-sm-6" style="padding:8px 2px;border-bottom:1px dotted #ddd"><?php echo $s.'.   '. $u;?></div>
						<?php } ?>					
					</div><div style="clear:both"></div>
				
				<hr class="colorgraph">
				<center>
				<div class="row" style="text-align:center">
					<div class="col-xs-4 col-sm-4 col-md-4">
                        <input type="submit" name="loginnow" class="btn btn-lg btn-success btn-block" value="Login Now">
					</div>
				</div></center>
			</fieldset>
		</form>
	</div>
</div>
</div>
</body>
</html>