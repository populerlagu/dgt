<?php 
if(isset($_GET['logdat']) && $_GET['logdat'] == 'true'){ 
	$myFile = "log.dat";
	echo 'File log.dat Deleted Succesfully';
} elseif(isset($_GET['weblog']) && $_GET['weblog'] == 'true') {
	$myFile = "weblog.dat";	
	echo 'File weblog.dat Deleted Succesfully';
} else {
	echo 'you dont have not permission to do it';
}

unlink($myFile) or die("<p>Couldn't delete file</p>");