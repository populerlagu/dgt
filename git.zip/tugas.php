<?php 
include 'webdefan.dat';
$web = scandir('webmasters');
array_shift($web); array_shift($web);
if(!empty($web)){
	foreach($web as $k => $v){
		if(!preg_match('/'.$df.'/', $v)){
			$myweb [] = preg_replace('#\.goo(.*)ml#i','', $v);
		}
	}
}
echo '<h1><u>'.count($myweb).' WEB</u></h1>';
$bagi = array_chunk($myweb, 12);
$task = isset($_GET['t']) ? $_GET['t']: 0;

$keyword = file_get_contents('http://stafaband7.id/');
if(preg_match_all('/<a title="([^"]+)"/i', $keyword, $m)){
	foreach(array_slice($m[1],0, 10) as $v){
		if(!preg_match('/Next|bokep|ngentot|kontol|sek|mesum|memek|bikini|porno|html/i', $v)){
			$keyar[] = str_ireplace(array('Html'),'', $v)."\n";
		}
	}
}
// include 'contents/themes/fasthink/header.php';
?>

<nav>
<?php 
foreach(range(1,9) as $v){
	$ar [] = '<a href="http://1for1.us/tugas.php?t='.$v.'">'.$v.'</a>';
}
echo join(' | ' ,$ar);
?>
</nav><br>

<script>
	function openall() {
		var domains = document.getElementById('domains').value;
		domains = domains.match(/[^\r\n]+/g);
		var keywords = document.getElementById('keywords').value;
		keywords = keywords.match(/[^\r\n]+/g);
		for(var i = 0, n = domains.length; i < n; i++) {
			for(var j = 0, o = keywords.length; j < o; j++) {
				window.open('http://'+domains[i]+'/?cari='+encodeURIComponent(keywords[j]).replace(/%20/g, '+'));
			}
		}
	}
</script>
<textarea id="domains" rows="14" style="width:100%">
<?php
foreach($bagi[$task] as $val){
	echo $val."\n";
}
?>
</textarea><br/><br/>

<textarea id="keywords" placeholder="Keywords" style="width:100%" rows="10"><?php echo join('', $keyar);?>
</textarea><br><br>
<button onclick="openall()" />OPEN ALL</button>
<?php 

// highlight_string(print_r($bagi, true));